define([
  "qlik",
  "jquery",
  "text!./template.html",
  "./ataccama",
  "css!./SOLAI.css"
], function (qlik, $, template, ataccama) {
  "use strict";

  var GRID_COLS = 24;
  var STORAGE_KEY = "solai_chat_history";
  var FEEDBACK_KEY = "solai_feedback_log";
  var RULE_COUNTS_KEY = "solai_rule_counts";
  var TRUSTED_KEY = "solai_trusted_examples";
  var TRUST_THRESHOLD = 5;
  var TRUSTED_INJECT_LIMIT = 10;

  function normalizeQuestion(q) {
    return (q || "")
      .toLowerCase()
      .replace(/[^\wа-яё\s]/gi, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function getTrustedExamples() {
    try { return JSON.parse(localStorage.getItem(TRUSTED_KEY) || "[]"); } catch(e) { return []; }
  }

  var SOLAI_COMPANY   = "Halyk bank";
  var SOLAI_SECTOR    = "banking";
  var SOLAI_USER_NAME = "Жумабай"; // имя в приветствии на welcome-экране
  // Версия сборки. Бампается каждый подтверждённый цикл изменений.
  // ВАЖНО: держать в синхроне с name/version в SOLAI.qext.
  var SOLAI_VERSION   = "2.1.45";

  // ── Ataccama ONE — бизнес-глоссарий (единый справочник определений) ──────────
  // Весь код подключения к Ataccama/Keycloak вынесен в ОТДЕЛЬНЫЙ модуль ataccama.js
  // и доступен здесь как `ataccama` (см. зависимость "./ataccama" в define выше).
  // Конфиг (URL токена/GraphQL, client_id/secret, флаг ENABLED) — внутри ataccama.js,
  // в объекте ataccama.config. SOLAI вызывает методы ataccama.* (см. ниже по тексту).

  // ── Отраслевые контексты для system prompt ───────────────────────────────
  // Каждый сектор содержит label, welcomeChips (подсказки в чате) и promptBlock
  // (отраслевые термины, подмешиваемые в system prompt).
  // Чтобы добавить новый сектор — добавь сюда ключ + опцию + используй в SOLAI_SECTOR.
  var SECTOR_CONTEXTS = {
    general: {
      label: "Общий",
      welcomeChips: ["Динамика по месяцам", "Доли по категориям", "Сводная таблица", "Список фильтров"],
      promptBlock: ""
    },
    banking: {
      label: "Банковский сектор",
      welcomeChips: ["Портфель по продуктам", "Динамика остатков", "NPL по сегментам", "Топ клиентов", "Доход по каналам"],
      promptBlock: [
        "ОТРАСЛЕВОЙ КОНТЕКСТ — БАНКОВСКИЙ СЕКТОР:",
        "• Типичные меры: остатки на счетах, объём кредитов, депозиты, доход (NII), комиссии, NPL.",
        "• Типичные измерения: продукт, сегмент клиента (розница/SME/корпорат), канал, регион, валюта, рейтинг, отрасль клиента.",
        "• Время: дата открытия, дата погашения, отчётный период.",
        "• Паттерны: NPL = просроченные >90 дней / общий портфель; ARPU; cost-of-risk; маржа.",
        "• Идентификаторы (только Count): IBAN, номер счёта, ID клиента, ИИН/БИН, номер договора."
      ].join("\n")
    },
    insurance: {
      label: "Страхование",
      welcomeChips: ["Премии по продуктам", "Убыточность", "Топ агентов", "Динамика выплат", "Портфель по регионам"],
      promptBlock: [
        "ОТРАСЛЕВОЙ КОНТЕКСТ — СТРАХОВАНИЕ:",
        "• Типичные меры: премии (начисленные/полученные), выплаты, резервы, комиссии, убыточность (Loss Ratio).",
        "• Типичные измерения: вид страхования (ОСАГО/КАСКО/имущество/жизнь), канал продаж, агент/брокер, регион, тип клиента.",
        "• Паттерны: Loss Ratio = выплаты / премии; средняя премия; число активных полисов.",
        "• Идентификаторы (только Count): номер полиса, ID клиента, ИИН/БИН."
      ].join("\n")
    },
    oil_gas: {
      label: "Нефтегаз",
      welcomeChips: ["Добыча по месторождениям", "Динамика переработки", "Затраты по статьям", "Топ скважин", "Экспорт vs внутренний"],
      promptBlock: [
        "ОТРАСЛЕВОЙ КОНТЕКСТ — НЕФТЕГАЗ:",
        "• Типичные меры: добыча (тонны/баррели), переработка, продажи (нетбэк), затраты (CAPEX/OPEX), запасы.",
        "• Типичные измерения: месторождение, скважина, продукт (нефть/газ/конденсат), направление (экспорт/внутр), контрагент, актив.",
        "• Паттерны: дебит скважины; коэффициент извлечения; нетбэк = выручка − налоги − транспорт.",
        "• Идентификаторы (только Count): номер скважины, ID партии, BL, контракт."
      ].join("\n")
    },
    pharma: {
      label: "Фармацевтика",
      welcomeChips: ["План поставки по МНН", "Остатки по регионам", "Недопоставки", "Топ препаратов", "Доля КТП"],
      promptBlock: [
        "ОТРАСЛЕВОЙ КОНТЕКСТ — ФАРМАЦЕВТИКА:",
        "• Типичные меры: план поставки, факт, остатки на складе, недопоставки, выручка.",
        "• Типичные измерения: МНН (международное непатентованное наименование), лот, лекарственная форма, ед.изм, регион, поставщик, способ закупа.",
        "• Возможные флаги: КТП (казахстанское товарное происхождение, 0/1) — использовать через Set Analysis {<КТП={1}>}.",
        "• Идентификаторы (только Count): СПП, СКП, номер договора, ИИН/БИН, ID лота.",
        "• Паттерны: процент дефицита = недопоставка / план; доля локального производства; покрытие потребности."
      ].join("\n")
    },
    retail: {
      label: "Ритейл",
      welcomeChips: ["Топ SKU", "Продажи по магазинам", "Средний чек", "Динамика по дням", "Доля категорий"],
      promptBlock: [
        "ОТРАСЛЕВОЙ КОНТЕКСТ — РИТЕЙЛ:",
        "• Типичные меры: выручка, число чеков, средний чек, маржа, остатки, оборачиваемость.",
        "• Типичные измерения: SKU, категория, бренд, магазин, регион, канал, программа лояльности.",
        "• Паттерны: средний чек = выручка / число чеков; конверсия; LFL рост; маржинальность категории.",
        "• Идентификаторы (только Count): SKU, артикул, номер чека, ID клиента."
      ].join("\n")
    },
    telecom: {
      label: "Телеком",
      welcomeChips: ["ARPU по тарифам", "Churn rate", "Топ регионов", "Трафик по услугам", "Динамика абонентов"],
      promptBlock: [
        "ОТРАСЛЕВОЙ КОНТЕКСТ — ТЕЛЕКОМ:",
        "• Типичные меры: выручка, ARPU, число абонентов, отток (churn), трафик (минуты/ГБ), MOU.",
        "• Типичные измерения: тариф, услуга, сегмент (B2C/B2B), регион, тип сети (2G/3G/4G/5G), устройство.",
        "• Паттерны: ARPU = выручка / число абонентов; Churn = ушедшие / база; MOU.",
        "• Идентификаторы (только Count): MSISDN, IMSI, ID абонента, номер договора."
      ].join("\n")
    },
    logistics: {
      label: "Логистика",
      welcomeChips: ["Объёмы по маршрутам", "Стоимость доставки", "Топ клиентов", "Динамика отправлений", "Загрузка транспорта"],
      promptBlock: [
        "ОТРАСЛЕВОЙ КОНТЕКСТ — ЛОГИСТИКА:",
        "• Типичные меры: число отправлений, вес/объём, стоимость доставки, простой, сроки.",
        "• Типичные измерения: маршрут, склад, транспорт, клиент, тип груза, регион отправки/назначения.",
        "• Паттерны: средний срок доставки; стоимость на тонну/км; OTIF; загрузка транспорта.",
        "• Идентификаторы (только Count): трек-номер, номер ТТН, ID транспорта, номер контейнера."
      ].join("\n")
    }
  };

  var CHART_TYPES = {
    barchart:      { title: "Столбчатая диаграмма", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#4ade80" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="12" width="4" height="9" rx="1"/><rect x="10" y="7" width="4" height="14" rx="1"/><rect x="17" y="3" width="4" height="18" rx="1"/></svg>' },
    piechart:      { title: "Круговая диаграмма", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f97316" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-9-9"/><path d="M21 12H12V3"/></svg>' },
    linechart:     { title: "Линейный график", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>' },
    scatterplot:   { title: "Точечная диаграмма", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="7.5" r="2"/><circle cx="16.5" cy="16.5" r="2"/><circle cx="17" cy="7" r="2"/><circle cx="7" cy="17" r="2"/><path d="M3 3v18h18"/></svg>' },
    treemap:       { title: "Карта дерева", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#4ade80" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="9" height="9" rx="1"/><rect x="13" y="2" width="9" height="5" rx="1"/><rect x="13" y="9" width="9" height="5" rx="1"/><rect x="2" y="13" width="5" height="9" rx="1"/><rect x="9" y="16" width="6" height="6" rx="1"/><rect x="17" y="16" width="5" height="6" rx="1"/></svg>' },
    "pivot-table": { title: "Сводная таблица", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fbbf24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/><line x1="9" y1="3" x2="9" y2="21"/><line x1="15" y1="3" x2="15" y2="21"/></svg>' },
    table:         { title: "Прямая таблица", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="3" x2="9" y2="21"/></svg>' },
    gauge:         { title: "Датчик", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fb7185" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>' },
    kpi:           { title: "KPI", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 3h5v5"/><path d="M8 3H3v5"/><path d="M12 22v-6"/><path d="m21 3-8.5 8.5"/><path d="M3 3l8.5 8.5"/><circle cx="12" cy="16" r="2"/></svg>' },
    combochart:    { title: "Комбо-диаграмма", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><rect x="7" y="13" width="3" height="5" rx="1"/><rect x="14" y="8" width="3" height="10" rx="1"/><path d="m6 7 4 4 4-4 5 5"/></svg>' },
    map:           { title: "Карта", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="10" r="3"/><path d="M12 2a8 8 0 0 0-8 8c0 5.4 7 11 8 12 1-1 8-6.6 8-12a8 8 0 0 0-8-8z"/></svg>' },
    listbox:       { title: "Фильтр", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>' }
  };

  // Маппинг типов → реальные имена объектов Qlik
  var QLIK_TYPE_MAP = {
    barchart:    "barchart",
    piechart:    "piechart",
    linechart:   "linechart",
    scatterplot: "scatterplot",
    treemap:     "treemap",
    "pivot-table": "pivot-table",
    table:       "table",
    gauge:       "gauge",
    kpi:         "kpi",
    combochart:  "combochart",
    map:         "map",
    listbox:     "listbox"
  };

  // ── Извлечение первого валидного JSON-объекта из произвольного текста ────
  // Идёт по строке посимвольно, считает баланс { и }, уважая строки в кавычках
  // и экранирование. Возвращает substring от первой { до соответствующей }.
  // Если AI вернул JSON + лишний текст после — берёт только JSON.
  function extractFirstJsonObject(text) {
    if (!text) return null;
    var start = text.indexOf("{");
    if (start === -1) return null;

    var depth = 0;
    var inString = false;
    var escapeNext = false;

    for (var i = start; i < text.length; i++) {
      var c = text.charAt(i);

      if (escapeNext) { escapeNext = false; continue; }
      if (c === "\\") { escapeNext = true; continue; }
      if (c === "\"") { inString = !inString; continue; }
      if (inString) continue;

      if (c === "{") depth++;
      else if (c === "}") {
        depth--;
        if (depth === 0) {
          return text.substring(start, i + 1);
        }
      }
    }
    // Дошли до конца строки, скобки не сбалансированы — JSON оборван
    return null;
  }

  // ── Утилиты полей ─────────────────────────────────────────────────────────
  function safeField(name) {
    if (/[ .()\u2116#\-\/\\]/.test(name)) return "[" + name + "]";
    return name;
  }
  // ── Авто-починка типичных ошибок AI ───────────────────────────────────────
  // Above([Sum([X])]) → Above(Sum([X]))  — стрипаем лишние [] вокруг функции.
  // То же для Below/Before/After/First/Last/Top/Bottom/Range*.
  function autoFixExpr(expr) {
    if (!expr) return expr;
    var LOOKBACKS = "Above|Below|Before|After|First|Last|Top|Bottom|RangeSum|RangeAvg|RangeMin|RangeMax|RangeCount|RangeStdev";
    var AGGS      = "Sum|Avg|Min|Max|Count|Only|Mode|Median|Stdev|Variance|Aggr|Concat|FirstSortedValue";
    var re = new RegExp(
      "\\b(" + LOOKBACKS + ")\\s*\\(\\s*\\[\\s*(" + AGGS + ")\\s*\\(([^()]*(?:\\([^()]*\\)[^()]*)*)\\)\\s*\\]\\s*\\)",
      "gi"
    );
    var iterations = 0;
    var prev;
    do {
      prev = expr;
      expr = expr.replace(re, function(m, lookback, agg, args) {
        return lookback + "(" + agg + "(" + args + "))";
      });
      iterations++;
    } while (prev !== expr && iterations < 5);
    return expr;
  }

  function safeMeasure(expr) {
    if (!expr) return expr;
    // 0. Чиним типичные ошибки AI до любых других преобразований
    expr = autoFixExpr(expr);
    // 1. Set Analysis ({...}) — не трогаем
    if (expr.indexOf("{") !== -1) return expr;
    // 2. Сложные выражения (lookback/Aggr/Rank/несколько агрегатов) — не трогаем,
    //    регекс ниже не понимает вложенность и сломает их.
    if (/\b(Above|Below|Before|After|First|Last|Top|Bottom|RangeSum|RangeAvg|RangeMin|RangeMax|If|Aggr|Rank|FirstSortedValue|RowNo|ColumnNo|Time|Date|Timestamp|MakeDate|MakeTime|MonthName|DayName|Year|Month|Day|Hour|Minute|Second)\b/i.test(expr)) {
      return expr;
    }
    var aggCount = (expr.match(/\b(Sum|Avg|Count|Min|Max|Median|Only|Mode|Stdev)\s*\(/gi) || []).length;
    if (aggCount > 1) return expr;

    // 3. Простая агрегация Sum(field)/Avg(field) — оборачиваем поле в [] если нужно
    return expr.replace(/([A-Za-z]+)\(((?:(?:total|all|distinct)\s+)?\[[^\]]+\]|[^)]+)\)/gi, function(m, fn, field) {
      var f = field.trim();
      if (f.charAt(0) === "[" && f.charAt(f.length - 1) === "]") return fn + "(" + f + ")";
      var qualMatch = f.match(/^((?:total|all|distinct)\s+)(.+)$/i);
      if (qualMatch) {
        var kw = qualMatch[1];
        var fieldName = qualMatch[2].trim();
        if (fieldName.charAt(0) === "[") return fn + "(" + kw + fieldName + ")";
        return fn + "(" + kw + safeField(fieldName) + ")";
      }
      return fn + "(" + safeField(f) + ")";
    });
  }

  // Генератор уникальных cId для Qlik property panel
  function qlikCid() { return "sk" + Math.random().toString(36).substr(2, 9); }

  // Похоже ли выражение на цветовое? Покрывает три режима раскраски:
  //  • по выражению/условию → '#HEX' внутри if/pick
  //  • по измерению         → Pick(...'#HEX'...)  (тоже содержит #)
  //  • по мере (градиент)   → ColorMix1(...ARGB/RGB...) — БЕЗ #, ловим по функциям
  function isColorExpr(s) {
    if (!s || typeof s !== "string") return false;
    return /#|argb\s*\(|rgb\s*\(|colormix|\bcolor\s*\(/i.test(s);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ── 1. УМНАЯ СХЕМА: определяем роль каждого поля + SAMPLE VALUES ────────
  // ══════════════════════════════════════════════════════════════════════════
  // Загрузка мастер‑элементов из библиотеки приложения (мастер‑меры + мастер‑измерения).
  // Идея: если пользователь явно говорит «<имя из библиотеки>» — использовать готовый
  // мастер‑элемент через qLibraryId, а не собирать выражение вручную.
  //
  // qData с qPath: "/qMetaDef/title" заставляет Engine скопировать значение из properties
  // в layout каждого элемента списка — без необходимости вызывать getProperties() поштучно.
  function loadMasterItems(enigmaApp, schema, onDone) {
    schema.masterMeasures = [];
    schema.masterDimensions = [];

    var partsDone = 0;
    function partDone() {
      if (++partsDone === 2) {
        console.log("[SOLAI Masters] loaded:",
          "measures=" + schema.masterMeasures.length,
          schema.masterMeasures.map(function(m){return "\"" + m.title + "\""}).join(", "),
          "| dimensions=" + schema.masterDimensions.length,
          schema.masterDimensions.map(function(d){return "\"" + d.title + "\""}).join(", "));
        onDone(schema);
      }
    }

    // ── Мастер‑меры (одношагово через qData‑пути) ───────────────────────────
    enigmaApp.createSessionObject({
      qInfo: { qType: "MeasureList" },
      qMeasureListDef: {
        qType: "measure",
        qData: {
          title:       "/qMetaDef/title",
          description: "/qMetaDef/description",
          tags:        "/qMetaDef/tags",
          expression:  "/qMeasure/qDef",
          label:       "/qMeasure/qLabel"
        }
      }
    }).then(function(listObj) {
      listObj.getLayout().then(function(layout) {
        var items = (layout.qMeasureList && layout.qMeasureList.qItems) || [];
        schema.masterMeasures = items.map(function(it) {
          var d = it.qData || {};
          return {
            id:    it.qInfo && it.qInfo.qId || "",
            title: d.title || d.label || (it.qMeta && it.qMeta.title) || "",
            expr:  d.expression || "",
            tags:  d.tags || []
          };
        }).filter(function(m){ return m.id; });
        try { enigmaApp.destroySessionObject(listObj.id); } catch(e) {}
        partDone();
      }).catch(function(e) {
        console.warn("[SOLAI Masters] MeasureList layout failed:", e && e.message);
        try { enigmaApp.destroySessionObject(listObj.id); } catch(e2) {}
        partDone();
      });
    }).catch(function(e) {
      console.warn("[SOLAI Masters] MeasureList create failed:", e && e.message);
      partDone();
    });

    // ── Мастер‑измерения ────────────────────────────────────────────────────
    enigmaApp.createSessionObject({
      qInfo: { qType: "DimensionList" },
      qDimensionListDef: {
        qType: "dimension",
        qData: {
          title:       "/qMetaDef/title",
          description: "/qMetaDef/description",
          tags:        "/qMetaDef/tags",
          fields:      "/qDim/qFieldDefs",
          labels:      "/qDim/qFieldLabels"
        }
      }
    }).then(function(listObj) {
      listObj.getLayout().then(function(layout) {
        var items = (layout.qDimensionList && layout.qDimensionList.qItems) || [];
        schema.masterDimensions = items.map(function(it) {
          var d = it.qData || {};
          return {
            id:     it.qInfo && it.qInfo.qId || "",
            title:  d.title || (it.qMeta && it.qMeta.title) || "",
            fields: d.fields || [],
            labels: d.labels || [],
            tags:   d.tags || []
          };
        }).filter(function(d){ return d.id; });
        try { enigmaApp.destroySessionObject(listObj.id); } catch(e) {}
        partDone();
      }).catch(function(e) {
        console.warn("[SOLAI Masters] DimensionList layout failed:", e && e.message);
        try { enigmaApp.destroySessionObject(listObj.id); } catch(e2) {}
        partDone();
      });
    }).catch(function(e) {
      console.warn("[SOLAI Masters] DimensionList create failed:", e && e.message);
      partDone();
    });
  }

  function loadAppSchema(app, onSuccess, onError) {
    var enigmaApp = app.model.enigmaModel;
    var schema = { tables: [], fields: [], masterMeasures: [], masterDimensions: [] };
    function finishWithMasters() { loadMasterItems(enigmaApp, schema, onSuccess); }

    enigmaApp.createSessionObject({
      qInfo: { qType: "TableList" },
      qTableListDef: {}
    }).then(function(obj) {
      obj.getLayout().then(function(layout) {
        schema.tables = ((layout.qTableList && layout.qTableList.qItems) || []).map(function(t) {
          return { name: t.qName, rows: t.qNoOfRows };
        });
        try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}

        enigmaApp.createSessionObject({
          qInfo: { qType: "FieldList" },
          qFieldListDef: { qShowSystem: false, qShowHidden: false, qShowSemantic: false, qShowDerivedFields: false }
        }).then(function(obj2) {
          obj2.getLayout().then(function(layout2) {
            schema.fields = ((layout2.qFieldList && layout2.qFieldList.qItems) || []).map(function(f) {
              var name  = f.qName;
              var tags  = f.qTags || [];
              // qnTotalDistinctValues — основное поле, qDistinctValues — fallback
              var card  = f.qnTotalDistinctValues || f.qDistinctValues || f.qCardinal || 0;
              var isNum = tags.indexOf("$numeric") !== -1 || tags.indexOf("$integer") !== -1 || tags.indexOf("$float") !== -1;
              var isDate = tags.indexOf("$date") !== -1 || tags.indexOf("$timestamp") !== -1;

              // Денежные/числовые-к-суммированию поля — по словам в имени → это МЕРА, не ID.
              // (расширять под номенклатуру банка — см. задание пользователю в памяти)
              var isAmountName = /(сумм|sum|saldo|сальдо|остат|ostat|amount|\bamt\b|balance|\bbal\b|оборот|oborot|turnover|выруч|revenue|доход|profit|прибыл|сальд)/i.test(name);
              var isFloat = tags.indexOf("$float") !== -1; // дробное → почти всегда мера, не ID
              // Явная маска идентификатора (номер/код/ИИН/счёт) — всегда ID.
              var isIdName = /(_id|id_|^id$|_key|^key$|iин|бин|bin|iin|\bcode\b|\bнмк\b|\bокпо\b|\bсчёт\b|\bсчет\b|account|polис|polic|msisdn|imsi)/i.test(name);
              // Поля-идентификаторы — никогда не суммируются, только Count.
              // Эвристику «числовое с огромной кардинальностью = ID» НЕ применяем к денежным
              // полям ($float или имя-сумма/остаток) — у суммы тоже много уникальных значений.
              var isId = isIdName || (isNum && card > 10000 && !isFloat && !isAmountName);

              // Дата/время
              var isDateDim = isDate
                || /year|месяц|month|quarter|дата|date|период|week|день|day/i.test(name);

              // Реальные меры — числа для суммирования
              // card=0 означает неизвестную кардинальность — даём benefit of the doubt числовым полям
              var isMeasure = isNum && !isId && !isDateDim && (card === 0 || card > 50);

              // Всё остальное — измерение
              var role = isId ? "id" : isDateDim ? "date" : isMeasure ? "measure" : "dimension";

              return {
                name: name,
                role: role,
                isNumeric: isNum,
                cardValues: card,
                tags: tags.filter(function(t) { return t.charAt(0) === "$"; }),
                sampleValues: [] // будет заполнено ниже
              };
            });
            try { enigmaApp.destroySessionObject(obj2.id); } catch(e) {}

            // ── Загрузка sample values для каждого поля (кроме ID) ──────────
            // Берём до 8 значений для каждого измерения/даты/меры
            // Это критично: модель ДОЛЖНА видеть реальные данные, а не только имена полей
            var fieldsToSample = schema.fields.filter(function(f) {
              return f.role !== "id" && f.cardValues > 0 && f.cardValues <= 50000;
            });

            if (!fieldsToSample.length) {
              finishWithMasters();
              return;
            }

            var sampleDone = 0;
            var sampleTotal = fieldsToSample.length;

            fieldsToSample.forEach(function(fieldInfo) {
              enigmaApp.createSessionObject({
                qInfo: { qType: "solai_sample" },
                qListObjectDef: {
                  qDef: { qFieldDefs: [fieldInfo.name] },
                  qShowAlternatives: false,
                  qInitialDataFetch: [{ qTop: 0, qLeft: 0, qHeight: 8, qWidth: 1 }]
                }
              }).then(function(listObj) {
                listObj.getLayout().then(function(listLayout) {
                  var items = (listLayout.qListObject &&
                               listLayout.qListObject.qDataPages &&
                               listLayout.qListObject.qDataPages[0] &&
                               listLayout.qListObject.qDataPages[0].qMatrix) || [];
                  fieldInfo.sampleValues = items.map(function(row) {
                    return row[0] ? (row[0].qText || "") : "";
                  }).filter(Boolean).slice(0, 8);
                  try { enigmaApp.destroySessionObject(listObj.id); } catch(e) {}
                  sampleDone++;
                  if (sampleDone === sampleTotal) {
                    console.log("[SOLAI Schema] loaded with samples for", sampleTotal, "fields");
                    finishWithMasters();
                  }
                }).catch(function() {
                  try { enigmaApp.destroySessionObject(listObj.id); } catch(e) {}
                  sampleDone++;
                  if (sampleDone === sampleTotal) finishWithMasters();
                });
              }).catch(function() {
                sampleDone++;
                if (sampleDone === sampleTotal) finishWithMasters();
              });
            });

          }).catch(function(e) { onError("FieldList: " + e.message); });
        }).catch(function(e) { onError("FieldList create: " + e.message); });
      }).catch(function(e) { onError("TableList: " + e.message); });
    }).catch(function(e) { onError("TableList create: " + e.message); });
  }

  function formatSchemaForLLM(schema) {
    var dims = [], meas = [], dates = [], ids = [];
    (schema.fields || []).forEach(function(f) {
      var samples = (f.sampleValues && f.sampleValues.length)
        ? " [примеры: " + f.sampleValues.join(", ") + "]"
        : "";
      // card:0 — кардинальность неизвестна из метаданных, но Count(Distinct) в queries даст точный ответ
      var cardStr = f.cardValues > 0 ? "(card:" + f.cardValues + ")" : "(card:неизвестно→используй Count(Distinct [" + f.name + "]) в queries)";
      if (f.role === "measure")   meas.push(f.name + cardStr + samples);
      else if (f.role === "date") dates.push(f.name + cardStr + samples);
      else if (f.role === "id")   ids.push(f.name + cardStr);
      else                        dims.push(f.name + cardStr + samples);
    });
    var lines = ["МОДЕЛЬ ДАННЫХ QLIK (ДИНАМИЧЕСКИ ОПРЕДЕЛЕНА):"];
    if (schema.tables.length) {
      lines.push("Таблицы: " + schema.tables.map(function(t){return t.name+"("+t.rows+" строк)";}).join(", "));
    }
    if (meas.length)  lines.push("МЕРЫ (суммируемые): " + meas.join(", "));
    if (dims.length)  lines.push("ИЗМЕРЕНИЯ (группировка): " + dims.join(", "));
    if (dates.length) lines.push("ДАТЫ/ПЕРИОДЫ: " + dates.join(", "));
    if (ids.length)   lines.push("ИДЕНТИФИКАТОРЫ (только Count): " + ids.join(", "));

    // ── Мастер‑элементы из библиотеки приложения ────────────────────────────
    // Если запрос пользователя совпадает с названием мастер‑меры/измерения —
    // AI обязан вернуть libraryId, а не собирать формулу самостоятельно.
    var mMeas = schema.masterMeasures || [];
    var mDims = schema.masterDimensions || [];
    if (mMeas.length || mDims.length) {
      lines.push("");
      lines.push("МАСТЕР‑ЭЛЕМЕНТЫ ИЗ БИБЛИОТЕКИ ПРИЛОЖЕНИЯ — приоритет над инлайн‑формулами!");
    }
    if (mMeas.length) {
      lines.push("МАСТЕР‑МЕРЫ (используй measureLibraryId, формулу НЕ переписывай):");
      mMeas.forEach(function(m) {
        var exprShort = (m.expr || "").length > 200 ? m.expr.slice(0, 200) + "…" : m.expr;
        lines.push("• \"" + m.title + "\" → measureLibraryId:\"" + m.id + "\" (formula: " + exprShort + ")");
      });
    }
    if (mDims.length) {
      lines.push("МАСТЕР‑ИЗМЕРЕНИЯ (используй dimensionLibraryId):");
      mDims.forEach(function(d) {
        var f = (d.fields && d.fields.length) ? d.fields.join(" / ") : "—";
        lines.push("• \"" + d.title + "\" → dimensionLibraryId:\"" + d.id + "\" (field: " + f + ")");
      });
    }
    return lines.join("\n");
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ── 2. ЗАГРУЗКА АГРЕГАТОВ ИЗ QLIK ENGINE ─────────────────────────────────
  // Отправляем несколько кубов по ключевым срезам, получаем готовые числа
  // ══════════════════════════════════════════════════════════════════════════
  function loadQlikData(app, schema, onSuccess, onError) {
    var enigmaApp = app.model.enigmaModel;
    if (!schema || !schema.fields || !schema.fields.length) { onSuccess({}, null, null); return; }

    var allFields = schema.fields;
    var dims  = allFields.filter(function(f){ return f.role === "dimension"; });
    var meas  = allFields.filter(function(f){ return f.role === "measure"; });
    var dates = allFields.filter(function(f){ return f.role === "date"; });

    // Если мер нет — всё равно строим кубы с Count() как мерой
    if (!meas.length) {
      // Попробуем использовать Count() как fallback меру
      var dimFallback = dims[0] || dates[0];
      if (!dimFallback) { onSuccess({}, null, null); return; }
      // Строим кубы Count по каждому измерению
      var fallbackMeas = [{ qDef: { qDef: "Count(1)", qLabel: "Кол-во записей" } }];
      var fallbackMainMeas = "Кол-во записей";
      var cubeListFallback = [];
      var seenFb = {};
      dims.concat(dates).forEach(function(f) {
        if (cubeListFallback.length < 8 && !seenFb[f.name]) {
          cubeListFallback.push([f.name, "dim_" + cubeListFallback.length]);
          seenFb[f.name] = 1;
        }
      });
      var cubeResultsFallback = {};
      var doneFb = 0;
      var totalFb = cubeListFallback.length;
      if (!totalFb) { onSuccess({}, null, null); return; }
      cubeListFallback.forEach(function(item) {
        var dimName = item[0], label = item[1];
        var maxRowsFb = Math.min(200, Math.floor(10000 / 2));
        enigmaApp.createSessionObject({
          qInfo: { qType: "solai_cube" },
          qHyperCubeDef: {
            qDimensions: [{ qDef: { qFieldDefs: [dimName] }, qNullSuppression: true }],
            qMeasures: fallbackMeas,
            qSortCriteria: [{ qSortByNumeric: -1 }],
            qInitialDataFetch: [{ qTop:0, qLeft:0, qHeight: maxRowsFb, qWidth: 2 }]
          }
        }).then(function(obj) {
          obj.getLayout().then(function(layout) {
            var rows = (layout.qHyperCube.qDataPages[0] && layout.qHyperCube.qDataPages[0].qMatrix) || [];
            var totalRows = layout.qHyperCube.qDimensionInfo[0] ? layout.qHyperCube.qDimensionInfo[0].qCardinal : rows.length;
            var hdrs = [dimName, fallbackMainMeas];
            var data = rows.map(function(r) {
              var o = {};
              hdrs.forEach(function(h, i) {
                var c = r[i];
                o[h] = (c.qText && c.qText !== "-") ? c.qText
                     : (c.qNum !== undefined && !isNaN(c.qNum) ? Math.round(c.qNum) : "-");
              });
              return o;
            });
            try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
            if (data.length) cubeResultsFallback[label] = { dim: dimName, headers: hdrs, data: data, totalDistinct: totalRows };
            doneFb++;
            if (doneFb === totalFb) onSuccess(cubeResultsFallback, fallbackMainMeas, null);
          }).catch(function() {
            try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
            doneFb++; if (doneFb === totalFb) onSuccess(cubeResultsFallback, fallbackMainMeas, null);
          });
        }).catch(function() { doneFb++; if (doneFb === totalFb) onSuccess(cubeResultsFallback, fallbackMainMeas, null); });
      });
      return;
    }

    // Определяем главные меры
    function find(fields, kwds) {
      for (var k=0; k<kwds.length; k++) {
        var kw = kwds[k].toLowerCase();
        for (var i=0; i<fields.length; i++)
          if (fields[i].name.toLowerCase().indexOf(kw)!==-1) return fields[i].name;
      }
      return fields[0] ? fields[0].name : null;
    }
    var mainMeas = find(meas, ["total_amount","totalamount","total","amount","сумма","revenue","выручка","продаж"])
                || meas[0].name;
    var secMeas  = find(meas, ["quantity","qty","кол","count","volume","объем"]);
    if (secMeas === mainMeas) secMeas = meas[1] ? meas[1].name : null;

    // Определяем ключевые измерения
    var dimProduct  = find(dims, ["productname","product_name","product","препарат","наименование","drug","товар"]);
    var dimRegion   = find(dims, ["region","регион","oblast","area","город","city"]);
    var dimCategory = find(dims, ["category","categor","категор","group","тип","вид","класс"]);
    var dimHospital = find(dims, ["hospital","больниц","clinic","мо_","facility","организ"]);
    var dimMonth    = find(dates, ["month_name","monthname","месяц","month"]);
    var dimYear     = find(dates, ["year","год"]);
    var dimDate     = find(dates, ["date","дата"]);

    // Берём ТОП-5 измерений для кубов (не дублируем)
    var cubeList = [];
    var seen = {};
    [
      [dimProduct,  "product"],
      [dimCategory, "category"],
      [dimRegion,   "region"],
      [dimHospital, "hospital"],
      [dimYear,     "year"],
      [dimMonth,    "month"],
    ].forEach(function(item) {
      if (item[0] && !seen[item[0]]) { cubeList.push(item); seen[item[0]]=1; }
    });
    // Добавляем любые неохваченные измерения (до 8 кубов)
    dims.forEach(function(f) {
      if (cubeList.length < 8 && !seen[f.name]) {
        cubeList.push([f.name, "dim_"+cubeList.length]);
        seen[f.name] = 1;
      }
    });

    var measDefs = [{ qDef: { qDef: "Sum(["+mainMeas+"])", qLabel: mainMeas } }];
    if (secMeas) measDefs.push({ qDef: { qDef: "Sum(["+secMeas+"])", qLabel: secMeas } });

    console.log("[SOLAI Cubes] mainMeas:", mainMeas, "secMeas:", secMeas,
                "cubes:", cubeList.map(function(c){return c[1]+":"+c[0];}).join(", "));

    var cubeResults = {};
    var done = 0;
    var total = cubeList.length;

    if (!total) { onSuccess({}, mainMeas, secMeas); return; }

    cubeList.forEach(function(item) {
      var dimName = item[0], label = item[1];
      var nCols = 1 + measDefs.length;
      // Лимит Qlik Engine: qHeight × qWidth ≤ 10000 ячеек
      // Загружаем до 200 строк — достаточно для полного охвата большинства измерений
      var maxRows = Math.min(200, Math.floor(10000 / nCols));
      enigmaApp.createSessionObject({
        qInfo: { qType: "solai_cube" },
        qHyperCubeDef: {
          qDimensions: [{ qDef: { qFieldDefs: [dimName] }, qNullSuppression: true }],
          qMeasures: measDefs,
          qSortCriteria: [{ qSortByNumeric: -1 }],
          qInitialDataFetch: [{ qTop:0, qLeft:0, qHeight: maxRows, qWidth:nCols }]
        }
      }).then(function(obj) {
        obj.getLayout().then(function(layout) {
          var rows = (layout.qHyperCube.qDataPages[0] && layout.qHyperCube.qDataPages[0].qMatrix) || [];
          var totalRows = layout.qHyperCube.qDimensionInfo[0] ? layout.qHyperCube.qDimensionInfo[0].qCardinal : rows.length;
          var hdrs = [dimName, mainMeas].concat(secMeas ? [secMeas] : []);
          var data = rows.map(function(r) {
            var o = {};
            hdrs.forEach(function(h, i) {
              var c = r[i];
              o[h] = (c.qText && c.qText !== "-") ? c.qText
                   : (c.qNum !== undefined && !isNaN(c.qNum) ? Math.round(c.qNum) : "-");
            });
            return o;
          });
          try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
          if (data.length) cubeResults[label] = { dim: dimName, headers: hdrs, data: data, totalDistinct: totalRows };
          console.log("[SOLAI Cube]", label, "(" + dimName + "):", data.length, "rows of", totalRows, "total");
          done++;
          if (done === total) onSuccess(cubeResults, mainMeas, secMeas);
        }).catch(function() {
          try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
          done++; if (done === total) onSuccess(cubeResults, mainMeas, secMeas);
        });
      }).catch(function() { done++; if (done === total) onSuccess(cubeResults, mainMeas, secMeas); });
    });
  }

  function formatDataForLLM(cubeResults, mainMeas, secMeas) {
    var keys = Object.keys(cubeResults || {});
    if (!keys.length) return "";
    // Динамический лимит: если уникальных ≤200 — показываем всё, иначе топ-200
    var lines = [
      "АГРЕГИРОВАННЫЕ ДАННЫЕ ИЗ QLIK ENGINE (посчитано по всем строкам, учтены выборки):",
      "Основная мера: " + mainMeas + (secMeas ? ", дополнительно: " + secMeas : ""),
      ""
    ];
    // Лимит строк для модели — не более 20 на куб (топы достаточны для аналитики)
    // Точные числа всегда можно получить через queries[]
    var MAX_ROWS_LLM = 20;
    // Порядок: product/category/region первыми, потом time, потом остальные
    var order = ["product","category","region","hospital","year","month"];
    var rendered = {};
    order.forEach(function(k) {
      if (!cubeResults[k]) return;
      rendered[k] = 1;
      var c = cubeResults[k];
      var total = c.totalDistinct || c.data.length;
      var showRows = c.data.slice(0, MAX_ROWS_LLM);
      var countInfo = total > MAX_ROWS_LLM
        ? " (всего уникальных: " + total + ", показано топ-" + showRows.length + ")"
        : " (всего: " + total + ")";
      lines.push("--- " + c.dim.toUpperCase() + countInfo + " ---");
      lines.push(c.headers.join("\t"));
      showRows.forEach(function(r) { lines.push(c.headers.map(function(h){return r[h];}).join("\t")); });
      lines.push("");
    });
    keys.forEach(function(k) {
      if (rendered[k]) return;
      var c = cubeResults[k];
      var total = c.totalDistinct || c.data.length;
      var showRows = c.data.slice(0, MAX_ROWS_LLM);
      var countInfo = total > MAX_ROWS_LLM
        ? " (всего уникальных: " + total + ", показано топ-" + showRows.length + ")"
        : " (всего: " + total + ")";
      lines.push("--- " + c.dim.toUpperCase() + countInfo + " ---");
      lines.push(c.headers.join("\t"));
      showRows.forEach(function(r) { lines.push(c.headers.map(function(h){return r[h];}).join("\t")); });
      lines.push("");
    });
    return lines.join("\n");
  }


  // ── Чтение выборок через enigma CurrentSelections ─────────────────────────
  // ── Снятие выборок (фильтров) в приложении через Qlik Engine ─────────────
  // spec: { all: bool, fields: ["Поле1", ...] }
  // Срабатывает ТОЛЬКО после явного согласия пользователя в диалоге.
  function clearQlikSelections(enigmaApp, spec, onDone, onFail) {
    if (!spec) { onDone([]); return; }

    // Снять все выборки разом
    if (spec.all) {
      enigmaApp.clearAll().then(function() {
        console.log("[SOLAI] Cleared ALL selections");
        onDone(["все выборки"]);
      }).catch(function(e) {
        console.warn("[SOLAI] clearAll failed:", e);
        onFail("clearAll: " + (e && e.message || e));
      });
      return;
    }

    // Снять конкретные поля
    var fields = (spec.fields || []).filter(Boolean);
    if (!fields.length) { onDone([]); return; }

    var done = 0, cleared = [], failed = [];
    fields.forEach(function(name) {
      enigmaApp.getField(name).then(function(field) {
        return field.clear();
      }).then(function() {
        console.log("[SOLAI] Cleared field:", name);
        cleared.push(name);
        done++;
        if (done === fields.length) finalize();
      }).catch(function(e) {
        console.warn("[SOLAI] clear field failed:", name, e);
        failed.push(name);
        done++;
        if (done === fields.length) finalize();
      });
    });

    function finalize() {
      if (cleared.length === 0) onFail("Не удалось снять выборки: " + failed.join(", "));
      else onDone(cleared);
    }
  }

  function loadSelections(enigmaApp, onSuccess) {
    enigmaApp.createSessionObject({
      qInfo: { qType: "SelectionObject" },
      qSelectionObjectDef: {}
    }).then(function(obj) {
      obj.getLayout().then(function(layout) {
        var sels = (layout.qSelectionObject && layout.qSelectionObject.qSelections) || [];
        try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
        if (!sels.length) { onSuccess(""); return; }
        var lines = ["\nАКТИВНЫЕ ВЫБОРКИ (данные уже отфильтрованы):"];
        sels.forEach(function(s) {
          var vals = (s.qSelectedFieldSelectionInfo || [])
            .map(function(v) { return v.qName; })
            .filter(Boolean).slice(0, 15).join(", ");
          if (!vals) vals = s.qSelected || ("выбрано " + (s.qSelectedCount || ""));
          lines.push("  " + s.qField + " = " + vals);
        });
        lines.push("Анализируй только выбранные данные, упоминай фильтры в ответе.");
        onSuccess(lines.join("\n"));
      }).catch(function() {
        try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
        onSuccess("");
      });
    }).catch(function() { onSuccess(""); });
  }




  // ── Извлечение строк из qMatrix ─────────────────────────────────────────
  function extractMatrixRows(matrix, maxRows) {
    var rows = [];
    var limit = Math.min(matrix.length, maxRows);
    for (var ri = 0; ri < limit; ri++) {
      var row = matrix[ri];
      var vals = [];
      for (var ci = 0; ci < row.length; ci++) {
        vals.push(row[ci].qText || (row[ci].qNum !== undefined ? String(row[ci].qNum) : "-"));
      }
      rows.push(vals);
    }
    return rows;
  }

  // ── Чтение объектов листа С ДАННЫМИ ────────────────────────────────────────
  // Читаем не только properties (что за поля), но и layout (реальные числа)
  // Это критично: пользователь видит данные на графике и спрашивает о них!
  function loadSheetObjects(app, sheetId, onSuccess) {
    if (!sheetId) { onSuccess([]); return; }
    var enigmaApp = app.model.enigmaModel;

    enigmaApp.getObject(sheetId).then(function(sheetObj) {
      sheetObj.getProperties().then(function(sheetProps) {
        var cells = sheetProps.cells || [];
        if (!cells.length) { onSuccess([]); return; }

        var results = [];
        var done = 0;

        cells.forEach(function(cell) {
          enigmaApp.getObject(cell.name).then(function(obj) {
            // Читаем И properties (определения полей) И layout (реальные данные)
            var propsPromise = obj.getProperties();
            var layoutPromise = obj.getLayout();

            Promise.all([propsPromise, layoutPromise]).then(function(both) {
              var props = both[0];
              var layout = both[1];

              var info = {
                id:    cell.name,
                type:  (props.qInfo && props.qInfo.qType) || cell.type || "unknown",
                title: props.title || (props.qMetaDef && props.qMetaDef.title) || ""
              };

              // Определения полей из properties
              var hcDef = props.qHyperCubeDef || {};
              var dimDefs = (hcDef.qDimensions || []).map(function(d) {
                return (d.qDef && d.qDef.qFieldDefs && d.qDef.qFieldDefs[0]) || "";
              }).filter(Boolean);
              // Метки мер из layout (qMeasureInfo.qFallbackTitle). У МАСТЕР‑мер qDef.qDef
              // пустой, поэтому метка критична — по ней мера ссылается в выражениях как
              // [Метка] (нужно для раскраски ColorMix, сортировки и т.п.).
              var measInfo = (layout.qHyperCube && layout.qHyperCube.qMeasureInfo) || [];
              var measDefs = (hcDef.qMeasures || []).map(function(m, mi) {
                var lbl  = (measInfo[mi] && measInfo[mi].qFallbackTitle) || (m.qDef && m.qDef.qLabel) || "";
                var expr = (m.qDef && m.qDef.qDef) || "";
                if (lbl)  return expr ? ("[" + lbl + "] = " + expr) : ("[" + lbl + "]");
                return expr;
              }).filter(Boolean);
              if (dimDefs.length) info.dimensions = dimDefs;
              if (measDefs.length) info.measures = measDefs;

              // РЕАЛЬНЫЕ ДАННЫЕ из layout (то что пользователь видит на графике)
              var hc = layout.qHyperCube;
              if (hc) {
                // Заголовки столбцов
                var colHeaders = [];
                (hc.qDimensionInfo || []).forEach(function(d) {
                  colHeaders.push(d.qFallbackTitle || (d.qGroupFieldDefs && d.qGroupFieldDefs[0]) || "dim");
                });
                (hc.qMeasureInfo || []).forEach(function(m) {
                  colHeaders.push(m.qFallbackTitle || "measure");
                });
                info.dataHeaders = colHeaders;
                info.totalRows = hc.qSize ? hc.qSize.qcy : 0;

                // Пробуем взять данные из layout.qDataPages
                var matrix = (hc.qDataPages && hc.qDataPages[0] && hc.qDataPages[0].qMatrix) || [];

                if (matrix.length > 0) {
                  // Данные есть в layout — берём до 100 строк
                  info.data = extractMatrixRows(matrix, 20);
                  results.push(info);
                  done++;
                  if (done === cells.length) onSuccess(results);

                } else if (info.totalRows > 0 && colHeaders.length > 0) {
                  // Данных нет в layout — запрашиваем явно через getHyperCubeData
                  // Это частая ситуация для sn-table и pivot-table
                  var fetchRows = Math.min(info.totalRows, 20);
                  obj.getHyperCubeData("/qHyperCubeDef", [
                    { qTop: 0, qLeft: 0, qHeight: fetchRows, qWidth: colHeaders.length }
                  ]).then(function(dataPages) {
                    var fetchedMatrix = (dataPages && dataPages[0] && dataPages[0].qMatrix) || [];
                    if (fetchedMatrix.length) {
                      info.data = extractMatrixRows(fetchedMatrix, 100);
                      console.log("[SOLAI SheetObj] fetched", info.data.length, "rows for", info.title || info.type);
                    }
                    results.push(info);
                    done++;
                    if (done === cells.length) onSuccess(results);
                  }).catch(function() {
                    results.push(info);
                    done++;
                    if (done === cells.length) onSuccess(results);
                  });

                } else {
                  results.push(info);
                  done++;
                  if (done === cells.length) onSuccess(results);
                }
              } else {
                results.push(info);
                done++;
                if (done === cells.length) onSuccess(results);
              }
            }).catch(function() {
              // Fallback: если layout не получился — хотя бы properties
              obj.getProperties().then(function(props) {
                var info = {
                  id:    cell.name,
                  type:  (props.qInfo && props.qInfo.qType) || cell.type || "unknown",
                  title: props.title || ""
                };
                var hcDef = props.qHyperCubeDef || {};
                var dimDefs = (hcDef.qDimensions || []).map(function(d) {
                  return (d.qDef && d.qDef.qFieldDefs && d.qDef.qFieldDefs[0]) || "";
                }).filter(Boolean);
                var measDefs = (hcDef.qMeasures || []).map(function(m) {
                  var lbl  = (m.qDef && m.qDef.qLabel) || "";
                  var expr = (m.qDef && m.qDef.qDef) || "";
                  if (lbl)  return expr ? ("[" + lbl + "] = " + expr) : ("[" + lbl + "]");
                  return expr;
                }).filter(Boolean);
                if (dimDefs.length) info.dimensions = dimDefs;
                if (measDefs.length) info.measures = measDefs;
                results.push(info);
                done++;
                if (done === cells.length) onSuccess(results);
              }).catch(function() { done++; if (done === cells.length) onSuccess(results); });
            });
          }).catch(function() { done++; if (done === cells.length) onSuccess(results); });
        });
      }).catch(function() { onSuccess([]); });
    }).catch(function() { onSuccess([]); });
  }

  function formatSheetForLLM(objects) {
    if (!objects || !objects.length) return "";
    var lines = [
      "",
      "ОБЪЕКТЫ НА ЛИСТЕ (" + objects.length + ") — все можно модифицировать через modify.objectId:"
    ];
    objects.forEach(function(o) {
      // КРИТИЧНО: objectId="<full-uuid>" — точный синтаксис для AI.
      // Без номеров строк, без префиксов, только однозначный ключ.
      var desc = "• objectId=\"" + (o.id || "") + "\" type=" + o.type;
      if (o.title) desc += " title=\"" + o.title + "\"";
      if (o.dimensions && o.dimensions.length) desc += " | dim: " + o.dimensions.join(", ");
      if (o.measures && o.measures.length) desc += " | meas: " + o.measures.join(", ");
      lines.push(desc);

      // Только заголовки + до 5 строк данных (экономия токенов)
      if (o.dataHeaders && o.data && o.data.length) {
        lines.push("    " + o.dataHeaders.join("\t"));
        var maxRows = Math.min(o.data.length, 5);
        for (var r = 0; r < maxRows; r++) {
          lines.push("    " + o.data[r].join("\t"));
        }
        if (o.data.length > 5) lines.push("    ...(+" + (o.data.length - 5) + " строк)");
      }
    });
    return lines.join("\n");
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ── ВАЛИДАЦИЯ ПОЛЕЙ ПО МОДЕЛИ ДАННЫХ ──────────────────────────────────────
  // Гарантия корректности (смысл интеграции с Ataccama): каждое поле [..] в формуле
  // ДОЛЖНО существовать в модели. Модель LLM иногда «обрезает»/путает имя
  // (saldo_out_sum_nat вместо saldo_out_sum_nat_end) → мера пустая/падает.
  // buildFieldIndex — индекс реальных имён полей; validateExprFields — проверяет
  // [скобочные] поля и АВТО-исправляет ОДНОЗНАЧНЫЕ совпадения (единственный кандидат
  // по префиксу/подстроке). Неоднозначные/отсутствующие → в unknown (НЕ выдаём число).
  function buildFieldIndex(schema) {
    var names = ((schema && schema.fields) || []).map(function(f){ return f.name; }).filter(Boolean);
    var lowerToExact = {};
    names.forEach(function(n){ lowerToExact[n.toLowerCase()] = n; });
    return { names: names, lowerToExact: lowerToExact };
  }
  function validateExprFields(expr, idx) {
    var corrections = [], unknown = [];
    if (!expr || !idx || !idx.names.length) return { expr: expr, corrections: corrections, unknown: unknown };
    var out = String(expr).replace(/\[([^\]]+)\]/g, function(m, inner) {
      var raw = inner.trim();
      var low = raw.toLowerCase();
      if (idx.lowerToExact[low]) {                       // точное совпадение (с поправкой регистра)
        var ex = idx.lowerToExact[low];
        if (ex !== raw) corrections.push({ from: raw, to: ex });
        return "[" + ex + "]";
      }
      if (raw.length < 3) { unknown.push(raw); return m; }
      var cands = idx.names.filter(function(n){ var nl = n.toLowerCase(); return nl.indexOf(low) !== -1 || low.indexOf(nl) !== -1; });
      var pref  = cands.filter(function(n){ var nl = n.toLowerCase(); return nl.indexOf(low) === 0 || low.indexOf(nl) === 0; });
      var pick  = (pref.length === 1) ? pref : (pref.length > 1 ? [] : cands); // префикс приоритетнее; >1 префикса = неоднозначно
      if (pick.length === 1) { corrections.push({ from: raw, to: pick[0] }); return "[" + pick[0] + "]"; }
      unknown.push(raw); return m;                       // 0 или >1 кандидатов — не угадываем
    });
    return { expr: out, corrections: corrections, unknown: unknown };
  }

  // ── ЗНАК (*-1) и интент «добавить поле» — детекторы по тексту пользователя ──
  // Модель самовольно лепит *-1 (часто из-за -1 в датах). Срезаем его кодом, если знак
  // НЕ просили в текущем сообщении (нажатие кнопки «Умножить на −1» шлёт текст со словами
  // про знак → тогда оставляем).
  // ВАЖНО: в JS \w НЕ матчит кириллицу — используем явные классы/комбинации слов.
  function userWantsSignFlip(text) {
    var t = text || "";
    return /(\*\s*-?\s*1|×\s*-?\s*1|на\s*-\s*1|на\s*минус\s*1|инвертир|по\s*модул|\bf?abs\b)/i.test(t)
        || (/умнож/i.test(t) && /(-\s*1|минус)/i.test(t))
        || (/(смен|поменя|инвертир)/i.test(t) && /знак/i.test(t))
        || (/(сделай|сделать|показ|отобраз|выведи)/i.test(t) && /(полож|отриц)/i.test(t));
  }
  // ОПРЕДЕЛЕНИЕ Ataccama ЯВНО требует смены знака (×(-1)) — тогда *-1 легитимен и срезать НЕЛЬЗЯ.
  // ВАЖНО: исключаем «-1» в датах (sysdate-1, add_months(...,-1)) — это период, не знак.
  function definitionWantsSignFlip(defText) {
    if (!defText) return false;
    var t = String(defText);
    if (/умнож\S*\s+на\s+(-?\s*1|минус\s*1)/i.test(t)) return true;          // «умножить на -1»
    if (/[*×]\s*\(?\s*-\s*1/i.test(t)) return true;                          // «*-1», «×(-1)» у суммы
    if (/(^|[^a-zа-я])-\s*sum\b/i.test(t)) return true;                      // «-SUM(...)»
    if (/обратн\S*\s+знак|обратным\s+знаком|смен\S*\s+знак|с\s+минусом/i.test(t)) return true;
    return false;
  }
  function userWantsAddField(text) {
    var t = text || "";
    return /(добав|дополнительн|ещё|еще|втор\S*\s|вторую|второе)/i.test(t)
        && /(поле|колон|столб|мер[аыуe]|меру|измерен)/i.test(t);
  }
  // Срезает множитель -1, добавленный к мере. Возврат {expr, stripped}.
  function stripSignMul(expr) {
    if (!expr) return { expr: expr, stripped: false };
    var s = String(expr), o = s;
    s = s.replace(/\s*\*\s*\(?\s*-\s*1\s*\)?\s*$/g, "");                                  // X*-1, X*(-1) в конце
    s = s.replace(/^\s*\(?\s*-\s*1\s*\)?\s*\*\s*/g, "");                                  // -1*X, (-1)*X в начале
    s = s.replace(/^\s*-\s*(?=(sum|count|avg|min|max|aggr|only|rangesum)\s*\()/i, "");    // -Sum(...)
    return { expr: s.trim(), stripped: s.trim() !== o.trim() };
  }
  // Вычищает упоминание умножения на -1 из ТЕКСТА ответа (analysis), когда знак не просили —
  // модель иногда пишет «...и умножением на -1 (так как ... обратным знаком...)», хотя в формуле
  // *-1 уже срезан и пользователь его не просил. Иначе текст вводит в заблуждение и тянется в историю.
  function scrubSignText(text) {
    if (!text) return text;
    var s = String(text);
    s = s.replace(/\s*[,;]?\s*(и|с|а\s+также)?\s*умнож\S*\s+(на|в)\s+(минус\s+)?-?\s*1\b\s*(\([^)]*\))?/gi, ""); // «умножением на -1 (…)»
    s = s.replace(/\s*[*×]\s*\(?\s*-\s*1\s*\)?/g, "");                                                          // «* -1» в инлайн-формуле
    s = s.replace(/\s*\((?=[^)]*(обратн|пассив|актив)[^)]*знак|[^)]*знак[^)]*(обратн|пассив|актив))[^)]*\)/gi, ""); // скобка про обратный знак
    s = s.replace(/\s{2,}/g, " ").replace(/\s+([.,;:])/g, "$1").replace(/,\s*\./g, ".").trim();
    return s;
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ── 5. ТОЧЕЧНЫЕ ЗАПРОСЫ: выполняем Set Analysis выражения в Qlik Engine ──
  // ══════════════════════════════════════════════════════════════════════════
  // Модель возвращает queries[] — массив {label, expr} с Set Analysis выражениями.
  // Мы создаём временный HyperCube для каждого, получаем точное значение из движка.
  // Поддерживаемые формы:
  //   Sum({<Field={'value'}>} Measure)          — фильтр по конкретному значению
  //   Sum({1<Field={'v1'}, Field2={'v2'}>} M)   — несколько фильтров без текущей выборки
  //   Sum({$<Year={2025}, Month={'март'}>} M)   — текущая выборка + уточнение
  //   Count(Distinct [Field])                   — количество уникальных значений
  //   Sum({<Date={">2025-01-01"}>} M)           — диапазон/сравнение: ДВОЙНЫЕ кавычки!
  function executeSetQueries(enigmaApp, queries, onSuccess) {
    if (!queries || !queries.length) { onSuccess([]); return; }
    var results = [];
    var done = 0;
    var total = queries.length;

    queries.forEach(function(q) {
      enigmaApp.createSessionObject({
        qInfo: { qType: "solai_setquery" },
        qHyperCubeDef: {
          qMeasures: [{ qDef: { qDef: q.expr, qLabel: q.label || "result" } }],
          qInitialDataFetch: [{ qTop: 0, qLeft: 0, qHeight: 1, qWidth: 1 }]
        }
      }).then(function(obj) {
        obj.getLayout().then(function(layout) {
          var val = "нет данных";
          var num = null;
          try {
            var cell = layout.qHyperCube.qDataPages[0].qMatrix[0][0];
            if (cell.qNum !== undefined && !isNaN(cell.qNum) && cell.qNum !== null) num = cell.qNum; // число для определения знака
            val = (cell.qText && cell.qText !== "-" && cell.qText !== "")
              ? cell.qText
              : (num !== null ? num : "нет данных");
          } catch(e) {}
          try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
          results.push({ label: q.label, expr: q.expr, value: val, num: num });
          console.log("[SOLAI SetQuery]", q.label, "=", val, " | expr:", q.expr);
          done++;
          if (done === total) onSuccess(results);
        }).catch(function(e) {
          try { enigmaApp.destroySessionObject(obj.id); } catch(e2) {}
          results.push({ label: q.label, expr: q.expr, value: "ошибка: " + (e.message || e) });
          done++;
          if (done === total) onSuccess(results);
        });
      }).catch(function(e) {
        results.push({ label: q.label, expr: q.expr, value: "ошибка создания объекта: " + (e.message || e) });
        done++;
        if (done === total) onSuccess(results);
      });
    });
  }

  // ── Ранжированные запросы (топ-N / «кто больше-меньше всего») ────────────────
  // Модель возвращает rankQueries[] — массив {label, dim, measure, order, n}.
  // Для каждого строим временный HyperCube «измерение + мера», ДВИЖОК сортирует по
  // мере (детерминированно, qInterColumnSortOrder=[1,0] + qSortByNumeric) и отдаёт
  // top-N строк [{entity, value}]. Это надёжнее, чем читать снапшот листа или просить
  // модель писать FirstSortedValue/Rank — нет шанса перепутать «больше/меньше».
  function executeRankQueries(enigmaApp, rankQueries, onSuccess) {
    if (!rankQueries || !rankQueries.length) { onSuccess([]); return; }
    var results = [];
    var done = 0;
    var total = rankQueries.length;

    rankQueries.forEach(function(q) {
      var n   = Math.max(1, Math.min(parseInt(q.n, 10) || 5, 100));
      var asc = (q.order === "asc");
      var dim = q.dim || "";
      var measure = q.measure || "";
      enigmaApp.createSessionObject({
        qInfo: { qType: "solai_rankquery" },
        qHyperCubeDef: {
          qDimensions: [{ qDef: { qFieldDefs: [dim] }, qNullSuppression: true }],
          qMeasures: [{
            qDef: { qDef: measure, qLabel: q.label || "value" },
            qSortBy: { qSortByNumeric: asc ? 1 : -1 }
          }],
          qInterColumnSortOrder: [1, 0],   // сортируем по столбцу-мере (индекс 1) первым
          qInitialDataFetch: [{ qTop: 0, qLeft: 0, qHeight: n, qWidth: 2 }]
        }
      }).then(function(obj) {
        obj.getLayout().then(function(layout) {
          var rows = [];
          try {
            var matrix = (layout.qHyperCube.qDataPages[0] || {}).qMatrix || [];
            matrix.forEach(function(r) {
              var d = r[0] || {}, m = r[1] || {};
              var entity = (d.qText && d.qText !== "-") ? d.qText : "(пусто)";
              var value  = (m.qNum !== undefined && !isNaN(m.qNum)) ? m.qNum
                         : (m.qText && m.qText !== "-" ? m.qText : null);
              rows.push({ entity: entity, value: value, valueText: m.qText });
            });
          } catch(e) {}
          try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
          results.push({ label: q.label, dim: dim, measure: measure, order: asc ? "asc" : "desc", n: n, rows: rows });
          console.log("[SOLAI RankQuery]", q.label, "| dim:", dim, "| строк:", rows.length, "| №1:", rows[0]);
          done++; if (done === total) onSuccess(results);
        }).catch(function(e) {
          try { enigmaApp.destroySessionObject(obj.id); } catch(e2) {}
          results.push({ label: q.label, dim: dim, measure: measure, order: asc ? "asc" : "desc", n: n, rows: [], error: (e.message || e) });
          done++; if (done === total) onSuccess(results);
        });
      }).catch(function(e) {
        results.push({ label: q.label, dim: dim, measure: measure, order: asc ? "asc" : "desc", n: n, rows: [], error: "создание объекта: " + (e.message || e) });
        done++; if (done === total) onSuccess(results);
      });
    });
  }

  // ── Ataccama ONE — бизнес-глоссарий ──────────────────────────────────────────
  // Код подключения вынесен в модуль ataccama.js (зависимость "./ataccama").
  // Здесь SOLAI пользуется его методами: ataccama.shouldUse / isDiagCommand /
  // errorHint / getToken / fetchGlossary / findTermInText (см. контроллер ниже).
  // Диагностика в консоли по-прежнему доступна как solaiTestAtaccama(...) —
  // модуль регистрирует её на window сам.

  // ── LLM API ────────────────────────────────────────────────────────────────
  // sectorKey — ключ из SECTOR_CONTEXTS ("general"/"banking"/...).
  // companyName — название компании пользователя (опционально), подставляется в prompt.
  function callLLM(apiKey, chatHistory, dataText, sectorKey, companyName, onSuccess, onError) {
    var sector = SECTOR_CONTEXTS[sectorKey] || SECTOR_CONTEXTS.general;
    var company = (companyName || "").trim();

    var systemPrompt = [
      "Ты — аналитик данных встроенный в Qlik Sense. Отвечай на РУССКОМ языке.",
      company ? ("КОМПАНИЯ ПОЛЬЗОВАТЕЛЯ: " + company + ". Учитывай это в формулировках ответа.") : "",
      "ИНДУСТРИЯ: " + sector.label + ".",
      "",
      "СТИЛЬ: отвечай строго по существу. Используй \\n для читаемости, • для списков, ЗАГЛАВНЫЕ для заголовков.",
      "Пример: 'дай измерения' → \"analysis\":\"ИЗМЕРЕНИЯ:\\n\\n• <Поле1>\\n• <Поле2>\\n• <Поле3>\" (используй реальные поля из модели)",
      "Пример: 'сколько регионов?' → одна строка с конкретным числом из агрегатов: 'В данных N регионов.'",
      "",
      "КОНТЕКСТ: тебе передаётся МОДЕЛЬ ДАННЫХ и АГРЕГАТЫ из Qlik Engine. Доверяй числам движка.",
      "",
      "МОДЕЛЬ ДАННЫХ:",
      "• МЕРЫ — числа для агрегации: Sum(), Avg(), Max(), Min()",
      "• ИЗМЕРЕНИЯ — категории для группировки (без агрегации)",
      "• ДАТЫ — Year, Month, Quarter для трендов",
      "• ИДЕНТИФИКАТОРЫ — коды, ID. НИКОГДА не суммируй. Только Count(Distinct [поле])",
      "  ВНИМАНИЕ: Count(Distinct [ID]) — правильно! Count([Distinct ID]) — ОШИБКА!",
      "",
      "АБСОЛЮТНЫЕ ЗАПРЕТЫ:",
      "• Поля помеченные как ИДЕНТИФИКАТОРЫ — только Count(Distinct [поле]). Sum() по ним — ЗАПРЕЩЕНО.",
      "• Поля-флаги (0/1, Y/N, true/false) — НЕ суммируй, используй как фильтр в Set Analysis: {<Флаг={1}>}.",
      "• Поля с 'номер','код','ID','ИИН','БИН','№' — только ИЗМЕРЕНИЕ.",
      "• ЗАПРЕЩЕНО писать Sum([X]) / Avg([X]) / Count([X]) / любое выражение содержащее [X], если 'X' есть в списке МАСТЕР‑МЕР. Используй measureLibraryId этого мастера — он уже содержит правильную агрегацию (Sum, Avg или сложную формулу). НЕ угадывай агрегацию, бери мастер целиком.",
      "• ЗАПРЕЩЕНО писать [X] как dimension, если 'X' есть в МАСТЕР‑ИЗМЕРЕНИЯХ. Используй dimensionLibraryId этого мастера.",
      "• ЗАПРЕЩЕНО использовать мастер‑меры только для одной из мер, а вторую писать инлайн, если для неё ТОЖЕ есть мастер. Если оба компонента есть в библиотеке — оба через libraryId.",
      "",
      "ТАБЛИЦЫ: поля по умолчанию = ИЗМЕРЕНИЕ. Мера только если пользователь написал 'сумма','посчитай','итого'.",
      "Если не уверен — спроси: 'Поле [X] — показать как значение или посчитать?'",
      "",
      "ПРИОРИТЕТ МАСТЕР‑ЭЛЕМЕНТОВ (КРИТИЧНО):",
      "Если в запросе пользователя название ТОЧНО совпадает (с учётом склонений/мн.ч., но смысл идентичен) с мастер‑мерой или мастер‑измерением из библиотеки — используй ИХ через libraryId:",
      "• Мастер‑мера → suggestion.measureLibraryId:\"<id>\" (НЕ пиши measure:\"Sum(...)\", вообще не задавай measure!)",
      "• Мастер‑измерение → suggestion.dimensionLibraryId:\"<id>\" (НЕ пиши dimension:\"...\", вообще не задавай dimension!)",
      "• В table/pivot — внутри dimensions/rowFields/colFields/measures можно класть объект {libraryId:\"<id>\"} вместо строки/выражения.",
      "• Для второй меры в combochart/kpi — measureLibraryId2.",
      "",
      "СЛОВАРЬ (важно):",
      "• «основные элементы» / «мастер‑элементы» / «библиотека» / «master items» — это блок МАСТЕР‑ЭЛЕМЕНТЫ ИЗ БИБЛИОТЕКИ выше. НЕ путай с объектами на листе!",
      "• Если пользователь сказал «возьми из основных элементов» / «используй мастер‑меры» / «из библиотеки» — пройди по своему предыдущему ответу и ЗАМЕНИ все инлайн‑формулы и имена полей на libraryId везде, где есть совпадение по имени.",
      "",
      "СУФФИКСЫ И ФОРМАТИРОВАНИЕ — НЕ ОСНОВАНИЕ ДЛЯ ИНЛАЙН‑ФОРМУЛЫ:",
      "• «Маржа, %», «Маржа %», «Маржа в процентах» — если в библиотеке есть мастер‑мера «Маржа», используй ЕЁ libraryId. «%» — это просьба о формате, не сигнал собирать ratio.",
      "• То же для «Продажи в KZT», «Продажи (млн)», «Выручка факт» и т.п. — отбрось суффикс/уточнение и проверь совпадение с мастером по корню названия.",
      "• ИСКЛЮЧЕНИЕ: если в библиотеке есть отдельная мастер‑мера с этим суффиксом (например мастер 'Маржа, %' или 'Маржинальность') — используй ЕЁ. Это всё равно libraryId, не инлайн.",
      "",
      "Пример: запрос 'Продажи по странам', в библиотеке есть мера 'Продажи' (id:abc) и измерение 'Страна' (id:def):",
      "  {\"chartType\":\"barchart\",\"dimensionLibraryId\":\"def\",\"measureLibraryId\":\"abc\",\"title\":\"Продажи по странам\"}",
      "Пример combochart с ДВУМЯ мастер‑мерами: запрос 'Продажи и Маржа, % по городам', в библиотеке Продажи (id:p) и Маржа (id:m):",
      "  {\"chartType\":\"combochart\",\"dimension\":\"Город\",\"measureLibraryId\":\"p\",\"measureLibraryId2\":\"m\",\"title\":\"Продажи и маржа по городам\"}",
      "  НЕ пиши \"measure2\":\"Sum([Маржа])/Sum([Продажи])\" — это ЗАПРЕЩЕНО при наличии мастера 'Маржа'.",
      "Если совпадает ТОЛЬКО мера — используй measureLibraryId + dimension (по полю). И наоборот.",
      "Если совпадения с библиотекой НЕТ — работай как раньше: dimension + measure инлайн.",
      "Для queries[] (расчёты через Set Analysis) — мастер‑элементы НЕ применимы, пиши выражение полностью.",
      "",
      "АНАЛИЗ: источник цифр — ТОЛЬКО агрегаты из кубов. Нет цифр → используй queries[].",
      "Данные объектов листа — только для контекста. НИКОГДА не говори 'данных нет'.",
      "Нет агрегатов → НЕ отказывай, а запроси через queries[].",
      "ВСЕГДА предлагай 2-3 визуализации + детальную таблицу.",
      "ФОРМАТ analysis (ЧИТАЕМОСТЬ): НЕ пиши всё одной строкой. Разбивай на короткие абзацы переносами \\n,",
      "между смысловыми блоками — пустая строка (\\n\\n). Перечисления — списком, каждый пункт с новой строки '• '.",
      "Формулу/меру и итоговое число выноси на ОТДЕЛЬНУЮ строку, оборачивай в `обратные кавычки`. Ключевое — **жирным**.",
      "Пример: \"Собрал «Остаток ОД» по определению Ataccama.\\n\\n**Формула:**\\n`Sum({<DWH_CODE={'CR_BAL'}>} [SALDO_OUT_SUM_NAT_END])`\\n\\n• Фильтр: DWH_CODE = CR_BAL\\n• Поле: SALDO_OUT_SUM_NAT_END\"",
      "",
      "ВИЗУАЛИЗАЦИИ:",
      "barchart — сравнение, топ N | linechart — тренды (Month/Year) | piechart/treemap — доли (Sum без деления, Qlik считает % сам)",
      "listbox — фильтр (одно поле, без мер) | table — dimensions[] + measures[{expr,label}] | gauge/kpi — одно число без измерений",
      "combochart — measure + measure2 (столбцы + линия) | scatterplot — связь двух мер",
      "Поля с пробелами → []. Set Analysis: Sum({<Поле={'значение'}>} Мера)",
      "КВАЛИФИКАТОРЫ total/all: пишутся ВНУТРИ функции ПЕРЕД полем, БЕЗ [] вокруг себя:",
      "  Sum(total [Поле]) — ПРАВИЛЬНО | Sum([total [Поле]]) — ОШИБКА!",
      "  Sum(total {<Set>} [Поле]) — ПРАВИЛЬНО | Sum([total Поле]) — ОШИБКА!",
      "",
      "TOP-N: 'топ 5' → topN:5. Точное число из запроса! >20 значений без указания → topN:10. linechart → без topN.",
      "TOP-N СВЕРХУ vs СНИЗУ: 'топ 10' / 'больше всего' / 'крупнейшие' → topN:10, sortDesc:true (по умолчанию, СВЕРХУ — наибольшие).",
      "  'наименьшие' / 'меньше всего' / 'топ 10 снизу' / 'самые маленькие' → topN:10 + ОБЯЗАТЕЛЬНО sortDesc:false.",
      "  (sortDesc:false переключает фиксированное число на 'снизу' — движок берёт N с НАИМЕНЬШИМ значением.)",
      "",
      "QUERIES[] — точечные запросы к Qlik Engine:",
      "Любой вопрос 'сколько X' → queries:[{label:'...', expr:'Count(Distinct [X])'}]",
      "Нет нужных цифр → queries:[{label:'...', expr:'Sum([мера])'}]",
      "card:0 у поля → ОБЯЗАТЕЛЬНО Count(Distinct) через queries[]",
      "Count() → ТОЛЬКО в queries[], НИКОГДА в suggestions.",
      "",
      "RANKQUERIES[] — РАНЖИРОВАНИЕ (кто больше/меньше всего, топ-N, лидер, максимум/минимум):",
      "Вопросы с превосходной степенью ('у кого больше всего X', 'кто лидер по X', 'топ N по X',",
      "'самый большой/маленький', 'у кого максимум/минимум', 'кто на первом месте') →",
      "ВСЕГДА rankQueries. НИКОГДА не читай снапшот листа и НЕ угадывай ответ по экрану.",
      "Формат: rankQueries:[{label:'...', dim:'[Измерение]', measure:'<выражение меры>', order:'desc'|'asc', n:5}]",
      "  dim     — сущность-измерение, по которой ранжируем ([Клиент], [Филиал], [Продукт]).",
      "  measure — выражение меры (Sum([Остаток на счетах]); можно с Set Analysis и фильтрами).",
      "  order   — 'desc' = больше всего сверху; 'asc' = меньше всего сверху.",
      "  n       — сколько вернуть (по умолчанию 5; 'топ 10' → 10).",
      "Движок САМ отсортирует и вернёт точный топ-N. Ответ давай ТОЛЬКО из этих чисел: явно назови",
      "№1 и приведи топ-5. И ОБЯЗАТЕЛЬНО добавь barchart (то же dim+measure, sortDesc по order, topN=n)",
      "— чтобы рейтинг можно было проверить глазами. rankQueries и queries можно возвращать вместе.",
      "",
      "═════════════════════════════════════════════════════════════════════",
      "SET ANALYSIS — РЕЖИМ SENIOR‑АНАЛИТИКА QLIK",
      "═════════════════════════════════════════════════════════════════════",
      "Ты должен писать выражения как senior‑аналитик Qlik 10 лет опыта. Знай и применяй ВСЁ ниже.",
      "",
      "БАЗА — модификаторы выборок:",
      "{1} — весь датасет, игнор выборок. {$} — текущая выборка (default).",
      "{1<Поле={'v'}>} — фильтр поверх ВСЕХ данных. {$<Поле={'v'}>} — фильтр поверх ТЕКУЩЕЙ выборки.",
      "{<Поле=>} — снимает фильтр по полю. {<Поле=, Год={2025}>} — снять Поле, оставить Год=2025.",
      "{1-$} — данные ИЗВНЕ выборки (антиселекция).",
      "{$<A={'v1'}, B={'v2'}>} — несколько условий через запятую (AND).",
      "Кавычки: '' (одинарные) — ТОЧНОЕ равенство конкретному значению ({'0'} = ровно 0).",
      "  \"\" (двойные) — ПОИСКОВОЕ выражение: сравнения и диапазоны (>, <, >=, <=) и wildcard.",
      "  🔴 ПРАВИЛО: любое сравнение/диапазон → ТОЛЬКО двойные кавычки. {\">0\"}, {\">=1000\"}, {\"<=100\"}.",
      "  {'0'} = ровно ноль (часто НЕ то, что нужно); {\">0\"} = больше нуля. {'Асп*'}=строка с *; {\"Асп*\"}=wildcard.",
      "Поля с пробелами/кириллицей — ВСЕГДА в []: Sum([Кредитный портфель в KZT]).",
      "",
      "ДИАПАЗОНЫ И СРАВНЕНИЯ (всегда ДВОЙНЫЕ кавычки!):",
      "{<Дата={\">2025-01-01\"}>} | {<Дата={\">=2025-01-01<=2025-12-31\"}>} — диапазон дат.",
      "{<Сумма={\">1000000\"}>} — числовое сравнение. {<[Остаток]={\">0\"}>} — только положительные.",
      "🔴 ОПЕРАТОР СТРОГО ПО СЛОВУ ПОЛЬЗОВАТЕЛЯ (не путай строгое и нестрогое!):",
      "  • 'больше X' / 'свыше X' / 'выше X' / 'более X' → СТРОГО \">X\"  (НЕ >=). Пример: 'больше 200000' → {\">200000\"}.",
      "  • 'меньше X' / 'ниже X' / 'менее X' → СТРОГО \"<X\"  (НЕ <=).",
      "  • 'от X' / 'не менее X' / 'X и более' / 'больше или равно X' / 'начиная с X' → \">=X\".",
      "  • 'до X' / 'не более X' / 'не больше X' / 'X и менее' / 'меньше или равно X' / 'по X включительно' → \"<=X\".",
      "  • 'от A до B' / 'в диапазоне A–B' / 'между A и B' → \">=A<=B\" (границы включаются).",
      "  • 'ровно X' / 'равно X' → точное значение {'X'} (одинарные кавычки, БЕЗ оператора).",
      "{<Год={$(=Max(Год))}>} — динамическое значение через $(=...). Только Max() — поможет ВСЕГДА брать актуальный год.",
      "{<Год={$(=Max(Год)-1)}>} — предыдущий год относительно макс.",
      "{<Месяц={$(=Max(Месяц))}>} — последний доступный месяц.",
      "",
      "КОМБИНАЦИИ МНОЖЕСТВ (продвинутое):",
      "{1<A={X}> + 1<B={Y}>} — объединение (union).",
      "{1<A={X}> * 1<B={Y}>} — пересечение (intersection).",
      "{1<A={X}> - 1<B={Y}>} — разность (минус).",
      "Sum({1<Год={2025}>} X) - Sum({1<Год={2024}>} X) — простая разница между периодами.",
      "",
      "ВРЕМЕННАЯ АНАЛИТИКА — паттерны senior‑уровня:",
      "• YoY рост (год к году) % :",
      "  (Sum({<Год={$(=Max(Год))}>}X) - Sum({<Год={$(=Max(Год)-1)}>}X)) / Sum({<Год={$(=Max(Год)-1)}>}X)",
      "",
      "• MoM рост (месяц к месяцу) через Above():",
      "  (Sum(X) - Above(Sum(X))) / Above(Sum(X))",
      "  ВАЖНО: работает ТОЛЬКО в визуализации с измерением (chart/table). Скобки [] вокруг Sum() — ОШИБКА: Above(Sum(X)), НЕ Above([Sum(X)]).",
      "",
      "• YTD (Year-To-Date):",
      "  Sum({<Год={$(=Max(Год))}, Месяц={\"<=$(=Max({<Год={$(=Max(Год))}>} Месяц))\"}>}X)",
      "",
      "• Same Period Last Year (SPLY):",
      "  Sum({<Год={$(=Max(Год)-1)}, Месяц=p({<Год={$(=Max(Год))}>}Месяц)>}X)",
      "  p() — possible/доступные значения из другого set'а.",
      "",
      "ФУНКЦИИ ИНТЕР-СТРОЧНЫЕ (только в chart/table с измерением):",
      "Above(expr, [n], [count]) — значение из ПРЕДЫДУЩЕЙ строки. Above(Sum(X)) — прошлая.",
      "Below(expr, [n], [count]) — из СЛЕДУЮЩЕЙ строки.",
      "Before(expr) / After(expr) — для pivot-table с горизонтальным измерением.",
      "First(expr) / Last(expr) — первая/последняя строка таблицы.",
      "RowNo() / ColumnNo() — текущая строка/столбец.",
      "Top(expr) / Bottom(expr) — относительно границ таблицы.",
      "",
      "Пример: % рост от предыдущей строки (для тренда по месяцам):",
      "(Sum([Продажи]) - Above(Sum([Продажи]))) / Above(Sum([Продажи]))",
      "Формат → процент через qNumFormat: PCT_FMT.",
      "",
      "AGGR — вложенные агрегации (мощный senior-инструмент):",
      "Aggr(Sum(X), Поле) — вычислить Sum(X) В РАЗРЕЗЕ Поля, отдать массив.",
      "Avg(Aggr(Sum([Продажи]), [Клиент])) — средние продажи на клиента.",
      "Max(Aggr(Sum([Доход]), [Регион])) — регион с максимальным доходом.",
      "Sum(Aggr(If(Sum(X)>1000, Sum(X)), Клиент)) — сумма по клиентам с продажами >1000.",
      "",
      "РАНКИНГ И ТОП-N через Set Analysis:",
      "{<Клиент={=Rank(Aggr(Sum([Продажи]),[Клиент]))<=10}>} — топ-10 клиентов по продажам.",
      "Внутри set'а — Rank() с Aggr() даёт мощный фильтр.",
      "",
      "Sum({<Клиент-={'X'}>}Y) — исключить значение (минус в фильтре).",
      "Sum({<Клиент=E({1<Сегмент={'VIP'}>}Клиент)>}Y) — клиенты В VIP сегменте (E = elements).",
      "Sum({<Клиент=P({1<Активный={1}>}Клиент)>}Y) — клиенты P (possible) при условии Активный=1.",
      "",
      "RANGE-функции (для накопительных и скользящих):",
      "RangeSum(Above(Sum(X), 0, RowNo())) — нарастающий итог.",
      "RangeAvg(Above(Sum(X), 1, 3)) — скользящее среднее за 3 предыдущих периода.",
      "RangeMax/RangeMin — максимум/минимум по диапазону.",
      "",
      "ДОЛЯ ОТ ОБЩЕГО (правильный paттерн):",
      "Sum([Продажи]) / Sum(TOTAL [Продажи]) — доля от всего датасета.",
      "Sum([Продажи]) / Sum(TOTAL <Регион> [Продажи]) — доля внутри региона.",
      "TOTAL <Поле1, Поле2> — суммировать по уровню Поле1+Поле2.",
      "",
      "ФИНАНСОВЫЕ ПАТТЕРНЫ (для банковского/корпоративного сектора):",
      "• NPL ratio: Sum({<СтатусКредита={'Просрочка'}>} [Сумма]) / Sum([Сумма])",
      "• Cost-to-Income: Sum([Расходы]) / Sum([Доходы])",
      "• ROE: Sum([ЧистаяПрибыль]) / Avg(Aggr(Sum([Капитал]),[Месяц]))",
      "• Средний чек: Sum([Сумма]) / Count(Distinct [ID транзакции])",
      "• Churn: 1 - Count({1<Активен={1}>} [КлиентID]) / Count({1} [КлиентID])",
      "",
      "ТИПИЧНЫЕ ОШИБКИ — НЕ ДОПУСКАТЬ:",
      "❌ Above([Sum(X)]) — лишние скобки [] вокруг функции",
      "✅ Above(Sum(X))",
      "",
      "❌ Sum([Year]={2025}, [Sales]) — путаница порядка",
      "✅ Sum({<Year={2025}>} [Sales])",
      "",
      "❌ Count(Distinct ID) — без квадратных скобок если поле с пробелами или кириллицей",
      "✅ Count(Distinct [ID Клиента])",
      "",
      "❌ Set Analysis в Count(): Sum({<X={1}>} Distinct Y) — синтаксическая ошибка",
      "✅ Count({<X={1}>} Distinct Y)",
      "",
      "❌ {<Date>='2025-01-01'>} — неправильный оператор",
      "✅ {<Date={\">=2025-01-01\"}>}",
      "",
      "❌ Sum(if(X>1000, Y)) внутри Set Analysis — медленно, неоптимально",
      "✅ Sum({<X={\">1000\"}>} Y)",
      "",
      "❌ {<[Остаток]={'>0'}>} или {<[Остаток]={'0'}>} — сравнение в ОДИНАРНЫХ кавычках НЕ работает",
      "   ({'>0'} ищет точное строковое значение «>0»; {'0'} = ровно ноль — фильтр пустой/неверный)",
      "✅ {<[Остаток]={\">0\"}>} — сравнение всегда в ДВОЙНЫХ кавычках",
      "",
      "ОПТИМИЗАЦИЯ — пиши как senior:",
      "1. Set Analysis ВСЕГДА предпочтительнее If() внутри Sum() — на порядок быстрее.",
      "2. {1} (игнор выборки) — только если ТОЧНО нужен полный датасет. Иначе {$} (текущая выборка).",
      "3. Aggr() — мощно, но дорого. Не вкладывай без необходимости.",
      "4. Динамические значения через $(=...) — для актуальных дат, последних значений.",
      "5. P() и E() — для каскадных условий между разными сетами.",
      "",
      "КОНСТРУКТОР ТАБЛИЦЫ (пошаговый диалог):",
      "Триггер: 'собери таблицу', 'создай таблицу', 'таблица', 'table'.",
      "ВАЖНО: НЕ генерируй поля сам! Строго спрашивай у пользователя, что он хочет.",
      "fieldChips — массив имён полей, отображаются как кликабельные кнопки (нажатие ДОБАВЛЯЕТ поле через запятую в поле ввода).",
      "",
      "ШАГ 1 — ИЗМЕРЕНИЯ:",
      "Спроси какие поля будут ИЗМЕРЕНИЯМИ. fieldChips = топ-10 измерений из переданной МОДЕЛИ ДАННЫХ (только реальные имена!).",
      "Пример (поля подставляй из своей модели):",
      "{\"analysis\":\"ТАБЛИЦА — шаг 1/3\\n\\nКакие поля добавить как измерения?\\nНажмите на нужные поля (они добавятся через запятую):\",",
      " \"fieldChips\":[\"<Измерение1>\",\"<Измерение2>\",\"<Дата>\",\"<Категория>\"],\"suggestions\":[]}",
      "",
      "ШАГ 2 — МЕРЫ:",
      "Запомни выбранные измерения. Спроси какие поля будут МЕРАМИ. fieldChips = все меры из модели.",
      "Пример:",
      "{\"analysis\":\"Измерения: <выбранные>\\n\\nШаг 2/3 — какие поля показать как меры?\\nВыберите одно или несколько:\",",
      " \"fieldChips\":[\"<Мера1>\",\"<Мера2>\",\"<Мера3>\"],\"suggestions\":[]}",
      "",
      "ШАГ 3 — АГРЕГАЦИЯ:",
      "Запомни выбранные меры. Спроси как агрегировать каждую меру.",
      "fieldChips = варианты агрегации.",
      "Пример:",
      "{\"analysis\":\"Измерения: <...>\\nМеры: <...>\\n\\nШаг 3/3 — как посчитать эти меры?\\nПо умолчанию Sum. Выберите другое или напишите 'готово':\",",
      " \"fieldChips\":[\"Sum\",\"Count\",\"Avg\",\"Min\",\"Max\",\"Готово\"],\"suggestions\":[]}",
      "",
      "ФИНАЛ — СОЗДАНИЕ:",
      "Собери suggestion с chartType:'table'. dimensions = выбранные измерения, measures = агрегированные меры.",
      "{\"analysis\":\"Таблица готова:\\n\\n- Измерения: <Изм1>, <Изм2>\\n- Меры: Sum(<Мера1>), Sum(<Мера2>)\\n\\nНажми + чтобы создать:\",",
      " \"fieldChips\":[],",
      " \"suggestions\":[{\"chartType\":\"table\",\"dimensions\":[\"<Изм1>\",\"<Изм2>\"],",
      "  \"measures\":[{\"expr\":\"Sum([<Мера1>])\",\"label\":\"<Мера1>\"},{\"expr\":\"Sum([<Мера2>])\",\"label\":\"<Мера2>\"}],",
      "  \"title\":\"<Изм1> × <Изм2>\",\"reason\":\"таблица по выбранным полям\"}]}",
      "",
      "ВАЖНО для конструктора таблицы:",
      "- Если пользователь пишет несколько полей через запятую — бери все.",
      "- По умолчанию агрегация = Sum. Если пользователь написал 'готово' или не указал — Sum для всех.",
      "- Если пользователь написал 'Count <Поле>' — используй Count([<Поле>]).",
      "- ПОМНИ контекст диалога — смотри историю сообщений чтобы знать что уже выбрано.",
      "",
      "КОНСТРУКТОР СВОДНОЙ ТАБЛИЦЫ (пошаговый диалог):",
      "Триггер: 'создай сводную таблицу', 'pivot таблица', 'сводная'.",
      "fieldChips — массив имён полей, отображаются как кликабельные кнопки (нажатие ДОБАВЛЯЕТ поле через запятую в поле ввода).",
      "",
      "ШАГ 1 — СТРОКИ:",
      "Спроси какие поля добавить в СТРОКИ. fieldChips = все измерения + id из переданной МОДЕЛИ ДАННЫХ (реальные имена!).",
      "Пример (поля подставляй из своей модели):",
      "{\"analysis\":\"СВОДНАЯ ТАБЛИЦА — шаг 1/4\\n\\nКакие поля добавить в СТРОКИ?\\nВыбери одно или несколько (через запятую):\",",
      " \"fieldChips\":[\"<Изм1>\",\"<Изм2>\",\"<Изм3>\"],\"suggestions\":[]}",
      "",
      "ШАГ 2 — СТОЛБЦЫ:",
      "Запомни rowFields. Спроси какие поля в СТОЛБЦЫ. fieldChips = оставшиеся измерения + даты.",
      "Пример:",
      "{\"analysis\":\"Строки: <Изм1> ✓\\n\\nШаг 2/4 — какие поля в СТОЛБЦЫ?\\nВыбери или 'пропустить':\",",
      " \"fieldChips\":[\"<Дата1>\",\"<Дата2>\",\"<Изм4>\"],\"suggestions\":[]}",
      "",
      "ШАГ 3 — ОБЩИЙ ИТОГ:",
      "Запомни colFields. Спроси нужен ли общий итог и по какому столбцу.",
      "fieldChips = выбранные столбцы + 'Нет итогов'.",
      "Если столбцов нет (пропустили) — пропусти этот шаг и иди к мере.",
      "Пример:",
      "{\"analysis\":\"Строки: <Изм1> ✓\\nСтолбцы: <Дата1>, <Дата2> ✓\\n\\nШаг 3/4 — Общий итог по какому столбцу?\\nВыбери столбец для итогов или 'нет итогов':\",",
      " \"fieldChips\":[\"<Дата1>\",\"<Дата2>\",\"Нет итогов\"],\"suggestions\":[]}",
      "",
      "Если пользователь выбрал столбец → totalDimension = имя поля.",
      "Если 'нет итогов' / 'пропустить' → totalDimension = null.",
      "",
      "ШАГ 4 — МЕРА:",
      "Спроси какую МЕРУ посчитать. fieldChips = все меры из модели.",
      "Пример:",
      "{\"analysis\":\"Строки: <Изм1> ✓\\nСтолбцы: <Дата1> ✓\\nИтог: по <Дата1> ✓\\n\\nШаг 4/4 — какую МЕРУ посчитать?\\nНапиши поле и агрегацию (Sum/Count/Avg):\",",
      " \"fieldChips\":[\"<Мера1>\",\"<Мера2>\",\"<Мера3>\"],\"suggestions\":[]}",
      "",
      "ФИНАЛ — СОЗДАНИЕ:",
      "Собери всё и выдай suggestion. Поле totalDimension — имя столбца для общего итога (или null).",
      "{\"analysis\":\"Сводная таблица готова:\\n\\n• Строки: <Изм1>\\n• Столбцы: <Дата1>\\n• Итог по: <Дата1>\\n• Мера: Sum(<Мера1>)\\n\\nНажми + чтобы создать:\",",
      " \"fieldChips\":[],",
      " \"suggestions\":[{\"chartType\":\"pivot-table\",\"rowFields\":[\"<Изм1>\"],\"colFields\":[\"<Дата1>\"],",
      "  \"totalDimension\":\"<Дата1>\",",
      "  \"measures\":[{\"expr\":\"Sum([<Мера1>])\",\"label\":\"<Мера1>\"}],",
      "  \"title\":\"Сводная: <Изм1> × <Дата1>\",\"icon\":\"📋\",\"reason\":\"сводная таблица\"}]}",
      "",
      "ВАЖНО для конструктора:",
      "• Если пользователь пишет несколько полей через запятую — бери все.",
      "• Если 'пропустить'/'нет'/'без столбцов' — colFields=[] пустой, пропусти шаг итогов.",
      "• По умолчанию агрегация = Sum. Пользователь может указать Count, Avg, Max, Min.",
      "• ПОМНИ контекст диалога — смотри историю сообщений чтобы знать что уже выбрано.",
      "",
      "━━━ ПЕРЕИСПОЛЬЗОВАНИЕ ФОРМУЛЫ vs НОВЫЙ ОБЪЕКТ (ПРЕЕМСТВЕННОСТЬ ДИАЛОГА) ━━━",
      "• ФОРМУЛУ показателя переиспользуй ВСЕГДА: если он уже собирался (история prior_built,",
      "  'СОЗДАННЫЕ ЧЕРЕЗ ЧАТ ОБЪЕКТЫ' или определён через Ataccama) — бери ТУ ЖЕ меру ДОСЛОВНО,",
      "  НЕ переизобретай выражение. НО переиспользование формулы ≠ обязательно менять старый объект.",
      "• НОВЫЙ показ/срез = НОВЫЙ объект (с той же мерой). Слова 'покажи / построй / дай / создай /",
      "  выведи / теперь ... топ-N / по клиентам / по филиалам / в разрезе ...' → СОЗДАЙ новый объект",
      "  (suggestions[...]) с переиспользованной формулой. НЕ переделывай предыдущий объект — это новый взгляд.",
      "  Можешь предложить 2-3 варианта визуализации (новые возможности).",
      "• ЕДИНАЯ МЕРА В ОТВЕТЕ (ВАЖНО): если в ОДНОМ ответе несколько визуализаций (напр. KPI + таблица + график)",
      "  для ОДНОГО показателя — во ВСЕХ suggestions мера ОДНА И ТА ЖЕ: идентичное выражение measure/measureLibraryId",
      "  и знак. НЕ смешивай разные меры в вариантах одного ответа (KPI по одной мере, таблица по другой — ОШИБКА).",
      "  Разные показатели в вариантах — ТОЛЬКО если пользователь ЯВНО попросил несколько мер.",
      "• МОДИФИКАЦИЯ существующего — ТОЛЬКО при ЯВНОЙ просьбе изменить ИМЕННО ТОТ объект:",
      "  'измени / поменяй / в этом же / в этой таблице / доработай этот / у этого графика' (цвет, сортировка,",
      "  топ-N, добавить/убрать поле) → modify:{objectId,...}, suggestions=[]. Без явной отсылки к существующему",
      "  объекту — НЕ модифицируй, а СОЗДАВАЙ новый.",
      "• Вопрос 'кто больше/меньше всего, топ-N' (нужно ЧИСЛО/рейтинг) → rankQueries с ТОЙ ЖЕ мерой (order asc/desc);",
      "  если при этом строишь визуализацию — это НОВЫЙ объект (sortDesc/topN), а не модификация старого.",
      "• objectId для модификации бери из 'СОЗДАННЫЕ ЧЕРЕЗ ЧАТ ОБЪЕКТЫ'/'ОБЪЕКТЫ НА ЛИСТЕ'; 'его/этот/тот же/последний'",
      "  без уточнения → 'ПОСЛЕДНИЙ созданный/изменённый объект'.",
      "",
      "МОДИФИКАЦИЯ ОБЪЕКТОВ:",
      "Если пользователь просит изменить СУЩЕСТВУЮЩИЙ объект (поле, меру, ЦВЕТ/раскраску, ориентацию, сортировку, топ-N) — это modify, НЕ новый график:",
      "1. Найди объект в списках 'ОБЪЕКТЫ НА ЛИСТЕ' ИЛИ 'СОЗДАННЫЕ ЧЕРЕЗ ЧАТ ОБЪЕКТЫ' по названию или смыслу.",
      "2. Если неоднозначно (несколько похожих) — перечисли их и спроси какой именно.",
      "3. В analysis кратко опиши текущий состав объекта и что изменяешь.",
      "4. Верни modify с objectId и нужными операциями. suggestions=[] при модификации.",
      "",
      "КРИТИЧНО про objectId:",
      "• objectId — это ПОЛНЫЙ Qlik UUID из значения objectId=\"...\" в списках выше.",
      "• Это НЕ номер по порядку (1, 2, 3) и НЕ короткое число.",
      "• Пример правильного objectId: \"abc12345-de67-89fg-hijk-lmnopqrstuvw\".",
      "• НИКОГДА не выдумывай objectId. Если объекта нет в списках — скажи пользователю что не нашёл.",
      "",
      "Формат modify (все поля опциональны, указывай только нужные):",
      "{\"modify\":{\"objectId\":\"<полный UUID из objectId=\\\"...\\\">\",",
      "  \"addDimensions\":[\"НовоеПоле\"],\"removeDimensions\":[\"Поле\"],",
      "  \"addMeasures\":[{\"expr\":\"Sum([X])\",\"label\":\"Метка\"}],\"removeMeasures\":[\"Sum([X])\"],",
      "  \"changeMeasures\":[{\"old\":\"Sum([X])\",\"new\":\"Avg([X])\",\"label\":\"Новая метка\"}],",
      "  \"title\":\"Новый заголовок\"}}",
      "",
      "Примеры запросов на модификацию:",
      "🔴 'ДОБАВЬ' = НОВАЯ колонка (addDimensions/addMeasures), НИКОГДА не замена (change*) и не новый объект.",
      "   Слова 'добавь / добавить / ещё поле / ещё колонку / дополнительно' → ТОЛЬКО add*, существующие колонки НЕ трогай.",
      "   'замени / поменяй / вместо' → changeMeasures/changeDimensions. Разделяй эти намерения чётко.",
      "• 'добавь поле <X> в таблицу' → modify: {objectId, addDimensions:['<X>']}  (НЕ changeDimensions!)",
      "• 'убери меру <Y>' → modify: {objectId, removeMeasures:['Sum([<Y>])']}",
      "• 'замени Sum на Avg для <Y>' → modify: {objectId, changeMeasures:[{old:'Sum([<Y>])',new:'Avg([<Y>])',label:'Средний <Y>'}]}",
      "• 'добавь колонку с суммой <Z>' → modify: {objectId, addMeasures:[{expr:'Sum([<Z>])',label:'<Z>'}]}",
      "",
      "РАСШИРЕННЫЕ ОПЕРАЦИИ МОДИФИКАЦИИ (топ-N, сортировка, формулы, измерения):",
      "• 'сделай топ 20' / 'покажи топ 5 вместо 10' → modify: {objectId, setTopN:20}",
      "• 'покажи топ 10 наименьших' / 'снизу 10' / 'самые маленькие 10' → modify: {objectId, setTopN:10, setSortDesc:false}",
      "  (setSortDesc:false вместе с setTopN ⇒ переключатель 'снизу' — отбираются N с наименьшим значением.)",
      "• 'убери ограничение топа' / 'покажи всё' → modify: {objectId, setTopN:0}",
      "• 'отсортируй по убыванию' / 'сначала большие' → modify: {objectId, setSortDesc:true}",
      "• 'хронологически' / 'по порядку загрузки' → modify: {objectId, setSortDesc:false}",
      "",
      "═════════════════════════════════════════════════════════════════════",
      "РАСШИРЕННАЯ СОРТИРОВКА (setSort) — ПО ПРИЗНАКАМ И ПРИОРИТЕТАМ",
      "═════════════════════════════════════════════════════════════════════",
      "Формат: setSort — массив критериев. Каждый описывает ОДИН уровень сортировки.",
      "В рамках одного измерения порядок критериев = ПРИОРИТЕТ (первый матчит первым).",
      "",
      "Поля критерия:",
      "• dim — индекс измерения (0 = первое, 1 = второе)",
      "• by — тип сортировки:",
      "    \"measure\"     — по значению меры (укажи measureIndex если не первая)",
      "    \"expression\"  — по произвольной формуле (укажи expr)",
      "    \"numeric\"     — по числовому значению поля",
      "    \"ascii\"       — по алфавиту (текстовое)",
      "    \"load\"        — по порядку загрузки (хронологически)",
      "    \"state\"       — выбранные сверху",
      "    \"frequency\"   — по частоте появления",
      "• direction — \"desc\" (по убыванию, default) или \"asc\" (по возрастанию)",
      "• expr — для by:\"expression\", произвольная формула",
      "• measureIndex — для by:\"measure\", индекс меры (default 0)",
      "",
      "ПРИМЕРЫ:",
      "• «сортируй по убыванию продаж» → setSort:[{dim:0, by:\"measure\", direction:\"desc\"}]",
      "• «по алфавиту» → setSort:[{dim:0, by:\"ascii\", direction:\"asc\"}]",
      "• «сначала числа возрастающие» → setSort:[{dim:0, by:\"numeric\", direction:\"asc\"}]",
      "• «хронологически» → setSort:[{dim:0, by:\"load\", direction:\"asc\"}]",
      "• «выбранные сверху, потом по убыванию меры» → setSort:[{dim:0, by:\"state\"}, {dim:0, by:\"measure\", direction:\"desc\"}]",
      "• «сортируй по второй мере» → setSort:[{dim:0, by:\"measure\", measureIndex:1, direction:\"desc\"}]",
      "• «по формуле Avg(X)» → setSort:[{dim:0, by:\"expression\", expr:\"Avg([X])\", direction:\"desc\"}]",
      "• Для pivot/таблицы с несколькими dim: «сначала Год убывая, потом Месяц по порядку»",
      "  → setSort:[{dim:0, by:\"ascii\", direction:\"desc\"}, {dim:1, by:\"load\", direction:\"asc\"}]",
      "",
      "ПРАВИЛА:",
      "1. По умолчанию для топ-N / убывающих списков → by:\"measure\", direction:\"desc\".",
      "2. Для трендов/линий по времени → by:\"load\", direction:\"asc\" (хронологически).",
      "3. Для фильтров (listbox) → by:\"state\" первым + by:\"ascii\" вторым.",
      "4. Можно дать НЕСКОЛЬКО критериев на один dim — будут применены в порядке приоритета.",
      "5. Если пользователь сказал «по убыванию» без уточнения по чему — по мере (by:\"measure\").",
      "6. Если сказал «А-Я» / «по алфавиту» / «по буквам» — by:\"ascii\".",
      "",
      "АНТИПАТТЕРНЫ:",
      "❌ setSort без явной просьбы пользователя — не лезь сам.",
      "❌ Сортировка по \"ascii\" для чисел — теряет смысл (1, 10, 11, 2, 20…).",
      "❌ Множественные конфликтующие критерии (по убыванию + по возрастанию того же типа).",
      "",
      "═════════════════════════════════════════════════════════════════════",
      "АВТО‑СОРТИРОВКА (setSortAuto) — КОГДА ЛОГИКУ ВЫБИРАЕТ РАСШИРЕНИЕ",
      "═════════════════════════════════════════════════════════════════════",
      "Если пользователь сказал «отсортируй» БЕЗ уточнения по чему и как — НЕ угадывай.",
      "Используй setSortAuto:true — расширение само разберётся:",
      "• Временная ось (Год/Месяц/Дата/Период) → хронологически (load order)",
      "• Категория + одна мера → по мере убывающе (топ‑паттерн)",
      "• Несколько мер → по первой мере убывающе",
      "• Только измерения без мер → по алфавиту",
      "",
      "Можно задать направление через setSortAutoDirection: \"desc\" (default) или \"asc\".",
      "",
      "ПРИМЕРЫ:",
      "• «Отсортируй этот график» → modify: {objectId, setSortAuto:true}",
      "• «Поменяй сортировку наоборот» → modify: {objectId, setSortAuto:true, setSortAutoDirection:\"asc\"}",
      "• «Сортируй как обычно» → modify: {objectId, setSortAuto:true}",
      "",
      "ПРИ СОЗДАНИИ объектов с мерой — ВСЕГДА задавай сортировку по контексту запроса:",
      "  • sortDesc — НАПРАВЛЕНИЕ по мере: true = по УБЫВАНИЮ (большие сверху), false = по ВОЗРАСТАНИЮ (маленькие сверху).",
      "  • sortChrono:true — ХРОНОЛОГИЧЕСКИ (для временных осей: Месяц/Год/Дата/Квартал), вместо сортировки по мере.",
      "ВЫБОР ПО СМЫСЛУ ЗАПРОСА:",
      "• «топ», «лидеры», «самые большие», «больше всего», «рейтинг» → sortDesc:true.",
      "• «худшие», «снизу», «меньше всего», «по возрастанию», «от меньшего» → sortDesc:false.",
      "• «динамика», «по месяцам», «тренд во времени», linechart по дате → sortChrono:true.",
      "• barchart/piechart/treemap с категориями без уточнения → sortDesc:true (топ-паттерн по умолчанию).",
      "• linechart с категориями (не время) → sortDesc:true.",
      "• Сортировка по мере работает и для МАСТЕР‑мер АВТОМАТИЧЕСКИ (расширение сортирует по метке меры).",
      "  Для мастер‑меры measure НЕ задавай — достаточно measureLibraryId. Просто ставь sortDesc/sortChrono по смыслу.",
      "• table только из измерений (0 мер) → сортировку не задавай.",
      "",
      "ПРАВИЛО ПРИОРИТЕТА:",
      "1. Явная просьба пользователя («по алфавиту», «убывающе», «по второй мере») → setSort с конкретикой.",
      "2. Невнятная просьба («отсортируй», «улучши порядок») → setSortAuto:true.",
      "3. При создании — sortDesc:true по умолчанию для категорий с мерой; sortChrono:true для временных осей.",
      "",
      "═════════════════════════════════════════════════════════════════════",
      "ОРИЕНТАЦИЯ BAR/COMBOCHART — ВЕРТИКАЛЬНАЯ vs ГОРИЗОНТАЛЬНАЯ",
      "═════════════════════════════════════════════════════════════════════",
      "Поле suggestion.orientation для barchart/combochart:",
      "• \"vertical\"   — столбцы ВВЕРХ (default, классический столбчатый график)",
      "• \"horizontal\" — бары ВПРАВО (горизонтальные полосы)",
      "",
      "ПРАВИЛО ВЫБОРА ПО УМОЛЧАНИЮ при создании:",
      "• По умолчанию ВСЕГДА vertical — это привычный столбчатый.",
      "• Используй horizontal ТОЛЬКО если:",
      "    - Пользователь явно сказал «горизонтальный»/«полосы»/«горизонтальные бары»",
      "    - Названия категорий ДЛИННЫЕ (>15 символов) — на верт. графике они не помещаются",
      "    - Категорий МНОГО (>15) — на верт. ось «загромождается»",
      "",
      "Триггеры распознавания:",
      "• «вертикальная гистограмма»/«столбцы»/«столбчатая»/«классическая» → vertical",
      "• «горизонтальные бары»/«полосы»/«горизонтальная»/«линии вправо» → horizontal",
      "",
      "ПРИМЕРЫ:",
      "• «Создай вертикальный график продаж по регионам» → {chartType:\"barchart\", orientation:\"vertical\", dimension:\"Регион\", measure:\"Sum([Продажи])\"}",
      "• «Сделай горизонтальные бары топ‑10 клиентов» → {chartType:\"barchart\", orientation:\"horizontal\", dimension:\"Клиент\", topN:10, measure:\"Sum([Продажи])\"}",
      "• «Просто график продаж» (без уточнения) → orientation:\"vertical\" (default)",
      "",
      "МОДИФИКАЦИЯ существующего графика:",
      "• «Поверни в горизонтальные» / «сделай горизонтальным» → modify: {objectId, setOrientation:\"horizontal\"}",
      "• «Верни в столбцы» / «поверни обратно» → modify: {objectId, setOrientation:\"vertical\"}",
      "",
      "═════════════════════════════════════════════════════════════════════",
      "РАСКРАШИВАНИЕ (colorExpression) — ТРИ РЕЖИМА",
      "═════════════════════════════════════════════════════════════════════",
      "Поле suggestion.colorExpression — Qlik‑выражение, возвращающее цвет (HEX или ARGB).",
      "Работает для bar/line/combo/pie/treemap/scatter. ВЫБЕРИ режим по запросу пользователя:",
      "  • ПО ВЫРАЖЕНИЮ / УСЛОВИЮ — раскраска по условию (знак, порог, конкретное значение).",
      "  • ПО ИЗМЕРЕНИЮ — каждому значению измерения свой цвет из палитры.",
      "  • ПО МЕРЕ — градиент: чем больше значение меры, тем насыщеннее цвет.",
      "ГЛАВНОЕ: пользователь говорит ГДЕ красить (по какому полю/мере/условию) — подставь",
      "именно ЭТО поле/меру в шаблон нужного режима (шаблоны ниже).",
      "",
      "━━━ ⚠️ ЦВЕТ У СУЩЕСТВУЮЩЕГО ГРАФИКА = MODIFY, А НЕ НОВЫЙ ГРАФИК ━━━",
      "Если пользователь просит изменить/добавить цвет СУЩЕСТВУЮЩЕМУ графику",
      "(«покрась его/этот», «сделай градиент», «перекрась», «цвет по…», «выдели цветом»)",
      "и НЕ описывает новый график (не называет новый тип/меру/измерение для нового) —",
      "это ВСЕГДА МОДИФИКАЦИЯ существующего, НЕ новый график:",
      "  → верни modify: {objectId:\"<полный UUID существующего>\", setColorExpression:\"…\"} и suggestions=[].",
      "  → objectId бери из списков 'СОЗДАННЫЕ ЧЕРЕЗ ЧАТ ОБЪЕКТЫ' / 'ОБЪЕКТЫ НА ЛИСТЕ'.",
      "  → «его / этот / график / последний / только что созданный» без уточнения →",
      "    бери objectId ПОСЛЕДНЕГО объекта из 'СОЗДАННЫЕ ЧЕРЕЗ ЧАТ ОБЪЕКТЫ'.",
      "  → 🚫 НЕ создавай новый график только ради смены цвета — это типичная ошибка, НЕ делай её.",
      "colorExpression ВНУТРИ suggestion ставь ТОЛЬКО когда реально создаёшь НОВЫЙ график",
      "(пользователь описал новый график И попросил покрасить в одном сообщении).",
      "",
      "ПРИЯТНАЯ ПАЛИТРА (используй ТОЛЬКО эти цвета — гармонично сочетаются):",
      "• #10b981 — изумрудный (рост, положительное, success)",
      "• #ef4444 — мягкий красный (падение, отрицательное, warning)",
      "• #f59e0b — тёплый янтарь (нейтральное, среднее, attention)",
      "• #3b82f6 — рояльный синий (основной, фокус)",
      "• #8b5cf6 — фиолетовый (второстепенное)",
      "• #ec4899 — розовый (выделение)",
      "• #14b8a6 — teal (свежий акцент)",
      "• #6366f1 — индиго (глубокий)",
      "• #94a3b8 — нейтральный серый (фон, остальное)",
      "",
      "❌ НЕ ИСПОЛЬЗУЙ: #ff0000 (ядовитый), #00ff00 (кислотный), яркие RGB без приглушения.",
      "",
      "ПАТТЕРНЫ ВЫРАЖЕНИЙ:",
      "",
      "1. РОСТ vs ПАДЕНИЕ (по знаку меры):",
      "   colorExpression: \"if(Sum([Продажи]) >= 0, '#10b981', '#ef4444')\"",
      "   → положительные зелёные, отрицательные красные.",
      "",
      "2. ТРЁХУРОВНЕВЫЙ (хорошо / средне / плохо):",
      "   colorExpression: \"if(Sum([Продажи]) > 1000000, '#10b981', if(Sum([Продажи]) > 0, '#f59e0b', '#ef4444'))\"",
      "",
      "3. ПО ЗНАЧЕНИЮ ИЗМЕРЕНИЯ (например, выделить год):",
      "   colorExpression: \"if([Год] = 2025, '#3b82f6', '#94a3b8')\"",
      "   → текущий год синим, остальные серым.",
      "",
      "4. РАЗНЫЕ ЦВЕТА НА ГОДЫ:",
      "   colorExpression: \"pick(match([Год], '2023','2024','2025'), '#94a3b8', '#3b82f6', '#10b981')\"",
      "",
      "5. ТОП vs ОСТАЛЬНЫЕ:",
      "   colorExpression: \"if(Rank(Sum([X])) <= 3, '#10b981', '#94a3b8')\"",
      "",
      "6. ПО КАТЕГОРИИ (VIP клиенты):",
      "   colorExpression: \"if([Сегмент] = 'VIP', '#3b82f6', '#94a3b8')\"",
      "",
      "━━━ РЕЖИМ «ПО ИЗМЕРЕНИЮ» (каждому значению — свой цвет из палитры) ━━━",
      "Запросы: «покрась по регионам», «разными цветами по категориям», «цвет по сегменту».",
      "ШАБЛОН (подставь имя поля‑измерения вместо [Поле] — В ОБОИХ местах одинаково):",
      "   colorExpression: \"Pick(Mod(FieldIndex('Поле',[Поле])-1,9)+1, '#10b981','#3b82f6','#f59e0b','#8b5cf6','#ec4899','#14b8a6','#6366f1','#ef4444','#94a3b8')\"",
      "   → стабильный отдельный цвет каждому значению [Поле]. FieldIndex('Поле',...) — имя поля строкой.",
      "",
      "━━━ РЕЖИМ «ПО МЕРЕ» (градиент по величине — через РАНГ) ━━━",
      "Запросы: «покрась по выручке», «градиент по сумме», «от светлого к тёмному».",
      "🔴🔴 МЕРУ БЕРИ ИЗ ОБЪЕКТА ПО ЕЁ МЕТКЕ В СКОБКАХ [...] — НИЧЕГО НЕ ВЫДУМЫВАЙ:",
      "  • В 'ОБЪЕКТЫ НА ЛИСТЕ' у объекта указана мера: meas: [Метка]  (например meas: [Кол-во опозданий]).",
      "  • Ссылайся на меру графика по МЕТКЕ В СКОБКАХ: Rank(TOTAL [Кол-во опозданий]) — это и есть ссылка на меру объекта.",
      "  • 🚫 НЕ переписывай формулу меры, НЕ добавляй Sum/Count/distinct/Set Analysis/новые поля — ТОЛЬКО [Метка] как есть.",
      "  • Менять можно ТОЛЬКО ЦВЕТА (ARGB/HEX) по запросу пользователя.",
      "ColorMix1(Value, ЦветПри0, ЦветПри1): Value 0..1 (вне диапазона авто-обрезается).",
      "ПРАВИЛО ПО УМОЛЧАНИЮ: БОЛЬШЕ значение = ТЕМНЕЕ цвет (тёмный 1-м ARGB, светлый 2-м):",
      "   colorExpression: \"ColorMix1(Rank(TOTAL [Кол-во опозданий])/NoOfRows(TOTAL), ARGB(255,8,48,107), ARGB(255,198,219,239))\"",
      "   • [Кол-во опозданий] — ЗАМЕНИ на МЕТКУ меры именно ЭТОГО графика (из meas: [...]). NoOfRows(TOTAL) — число строк.",
      "   • Rank: 1 = наибольшее → 1-й ARGB; Value→0 для большого. Поэтому 1-й ARGB ТЁМНЫЙ (большое=тёмное), 2-й СВЕТЛЫЙ (малое=светлое).",
      "   • Если пользователь просит ПОМЕНЯТЬ тёмное со светлым (инвертировать) → ПРОСТО поменяй два ARGB местами, больше ничего.",
      "   • Цвета: ARGB(a,r,g,b) / RGB(r,g,b) / '#hex'. % от плана: ColorMix1(Sum([Факт])/Sum([План]), RGB(255,0,0), RGB(0,255,0)).",
      "",
      "🟦 РАСКРАСКА ТАБЛИЦЫ (ФОН ЯЧЕЕК): colorExpression работает и для таблицы — красит ФОН ячеек,",
      "   и у МЕРЫ, и у ИЗМЕРЕНИЯ (движок применяет его как cellBackgroundColor к обеим колонкам).",
      "   «залей таблицу градиентом по остатку», «цвет фона по значению», «тепловая карта по мере» →",
      "   тот же ColorMix1(Rank(TOTAL [Метка меры])/NoOfRows(TOTAL), ARGB(тёмный), ARGB(светлый)).",
      "   Для существующей таблицы: modify:{objectId, setColorExpression:\"ColorMix1(...)\"}, suggestions=[].",
      "",
      "🔴🔴 ГЛАВНОЕ ДЛЯ ВСЕХ РЕЖИМОВ: подставляй РЕАЛЬНЫЕ имена ЭТОГО графика, НЕ плейсхолдеры.",
      "  • [Мера] → точная мера графика (например Sum(Продажи) — возьми из его существующей меры дословно).",
      "  • [Изм]  → реальное имя поля‑измерения графика (ось). FieldIndex('Поле',...) — то же поле в кавычках и в [].",
      "  • Выражение с буквальными [Мера]/[Изм] ссылается на несуществующие поля → график пустой. НЕ делай так.",
      "  • При модификации существующего графика его мера и измерение даны в 'ОБЪЕКТЫ НА ЛИСТЕ' — бери их оттуда.",
      "",
      "ПРИМЕРЫ ЗАПРОСОВ ПОЛЬЗОВАТЕЛЯ:",
      "• «Покрась минусовые красным, плюсовые зелёным» → colorExpression по знаку меры.",
      "• «Выдели 2025 год синим» → if([Год] = 2025, '#3b82f6', '#94a3b8').",
      "• «Дай разные цвета по годам» → pick(match([Год], ...), ...).",
      "• «Покрась VIP в синий» → if([Сегмент]='VIP', '#3b82f6', '#94a3b8').",
      "• «Подсвети топ-3 зелёным» → if(Rank(Sum([X])) <= 3, '#10b981', '#94a3b8').",
      "• «Покрась по регионам» / «разными цветами по категориям» → режим ПО ИЗМЕРЕНИЮ (Pick+FieldIndex по этому полю).",
      "• «Покрась по выручке» / «градиент по сумме продаж» → режим ПО МЕРЕ (ColorMix1 по этой мере).",
      "• Пользователь НАЗВАЛ поле/меру → бери ИМЕННО его и подставь в шаблон выбранного режима.",
      "",
      "═════════════════════════════════════════════════════════════════════",
      "🚨🚨🚨 АБСОЛЮТНЫЙ ЗАПРЕТ: ЦВЕТА БЕЗ ЯВНОЙ ПРОСЬБЫ 🚨🚨🚨",
      "═════════════════════════════════════════════════════════════════════",
      "",
      "ПРАВИЛО №1 ПРИ КАЖДОМ СОЗДАНИИ ГРАФИКА:",
      "  → Перед тем как написать colorExpression, проверь: в ТЕКУЩЕМ сообщении пользователя",
      "    (НЕ в предыдущих, НЕ в истории) есть слово про цвет?",
      "  → Если НЕТ → colorExpression НЕ должно быть в JSON. ВООБЩЕ. Не пустым, не дефолтным, ОТСУТСТВУЕТ.",
      "  → Если ДА → можно добавить colorExpression.",
      "",
      "СЛОВА, КОТОРЫЕ ДАЮТ ПРАВО НА ЦВЕТА (ТОЛЬКО ПРЯМЫЕ):",
      "  «покрась», «раскрась», «выдели цветом», «подсвети», «отмечай цветом»,",
      "  «зелёным/красным/синим/жёлтым», «цвет», «colorExpression», «расцветка»,",
      "  «разные цвета», «по знаку», «отрицательные красным», «положительные зелёным»,",
      "  «градиент», «по измерению», «по мере», «разными цветами», «закрась», «крась».",
      "",
      "СЛОВА, КОТОРЫЕ НЕ ДАЮТ ПРАВО:",
      "  «разница», «дельта», «MoM», «YoY», «рост», «падение», «снижение», «изменение»,",
      "  «динамика», «тренд», «сравни», «лучше», «улучши», «удобно».",
      "  ❌ Даже если ТЫ ДУМАЕШЬ что красить было бы полезно — НЕ ДЕЛАЙ.",
      "",
      "ПРОВЕРКА ДЛЯ КАЖДОГО ЗАПРОСА:",
      "  «Сделай разницу остатков 2025 vs 2024»     → НЕТ цветов (только разница, никаких слов про цвет)",
      "  «Δ остатки по филиалам»                    → НЕТ цветов",
      "  «динамика MoM, рост в %»                   → НЕТ цветов",
      "  «топ-10 клиентов»                          → НЕТ цветов",
      "  «топ-10 клиентов, выдели лидера зелёным»   → ДА цвета (есть «выдели зелёным»)",
      "  «разница 2025/2024, покрась по знаку»      → ДА цвета (есть «покрась»)",
      "",
      "❌ ИСТОРИЯ ДИАЛОГА — НЕ ОПРАВДАНИЕ:",
      "  Если пользователь раньше попросил покрасить ОДИН график, это НЕ значит",
      "  что следующий тоже надо красить. Каждый новый запрос — свежий лист.",
      "",
      "ФОРМАТ: если просьбы цветов нет в текущем запросе — поле colorExpression",
      "ОТСУТСТВУЕТ в JSON. Не «»; не null. ОТСУТСТВУЕТ.",
      "",
      "СТАРАЯ ШПАРГАЛКА (тоже верна):",
      "❌ НЕ ДЕЛАЙ: автоматически красить разницу/дельту/рост зелёным/красным.",
      "❌ НЕ ДЕЛАЙ: «улучшать» график цветами по своей инициативе.",
      "❌ НЕ ДЕЛАЙ: добавлять colorExpression для VIP/топов/категорий без явной просьбы.",
      "",
      "МОДИФИКАЦИЯ:",
      "• «Покрась отрицательные красным» → modify: {objectId, setColorExpression:\"if(<выражение_меры>>=0,'#10b981','#ef4444')\"}",
      "• «Убери покраску» / «верни автоцвет» → modify: {objectId, setColorExpression:null}",
      "• «Поменяй цвета на синий/жёлтый» → modify: {objectId, setColorExpression:\"if(<условие>,'#3b82f6','#f59e0b')\"}",
      "• «Покрась по измерению/регионам» → modify: {objectId, setColorExpression:\"Pick(Mod(FieldIndex('Поле',[Поле])-1,9)+1,'#10b981','#3b82f6','#f59e0b','#8b5cf6','#ec4899','#14b8a6','#6366f1','#ef4444','#94a3b8')\"}",
      "• «Сделай градиент по мере/выручке» → modify: {objectId, setColorExpression:\"ColorMix1(Rank(TOTAL [Метка меры объекта])/NoOfRows(TOTAL),ARGB(255,8,48,107),ARGB(255,198,219,239))\"} — по умолчанию БОЛЬШЕ=ТЕМНЕЕ (тёмный 1-м ARGB); метку меры бери из meas:[...]; НЕ выдумывай формулу.",
      "• «Поменяй тёмное со светлым» / «инвертируй градиент» → modify: {objectId, setColorExpression: то же выражение, но два ARGB ПОМЕНЯНЫ местами}.",
      "",
      "ПРАВИЛА:",
      "1. colorExpression ОБЯЗАТЕЛЬНО ВОЗВРАЩАЕТ строку с #HEX. Не число, не RGB-кортеж.",
      "2. Внутри if/pick используй кавычки одинарные: '#10b981', не \"#10b981\".",
      "3. Поля с пробелами/кириллицей оборачивай в []: [Год], [Тип бизнеса].",
      "4. Не комбинируй цвета с auto-режимом — colorExpression выключает авто.",
      "5. Если пользователь не уточнил цвета — бери из приятной палитры выше.",
      "• 'добавь разбивку по годам' / 'сделай линии по сегментам' → modify: {objectId, setDimension2:'Год'}",
      "• 'убери разбивку' / 'оставь одно измерение' → modify: {objectId, setDimension2:null}",
      "• 'поменяй ось на месяцы' / 'по неделям вместо месяцев' → modify: {objectId, setDimension:'Месяц'}",
      "• 'фильтруй только VIP' / 'добавь Set Analysis по сегменту' → modify: {objectId, setMeasureExpr:[{index:0, expr:\"Sum({<Сегмент={'VIP'}>}[Сумма])\", label:'Продажи VIP'}]}",
      "• 'возьми только 2025 год' → modify: {objectId, setMeasureExpr:[{index:0, expr:\"Sum({<Год={2025}>}[Сумма])\", label:'Продажи 2025'}]}",
      "",
      "ПРАВИЛА расширенной модификации:",
      "1. setTopN применяется к ПЕРВОМУ измерению (главная ось). 0 или null = снять ограничение.",
      "2. setSortDesc=true сортирует по убыванию первой меры. false = по порядку загрузки (для дат/трендов).",
      "3. setDimension2 на linechart = добавить серии (отдельные линии по категории).",
      "4. setMeasureExpr меняет ФОРМУЛУ существующей меры (index=0 — первая). Используй для Set Analysis модификаций.",
      "5. setDimension МЕНЯЕТ ось — старое измерение исчезнет, новое встанет на его место.",
      "6. Можно совмещать в одной модификации: {setTopN:20, setSortDesc:true, title:'Топ 20 по убыванию'}.",
      "",
      "ВАЖНО: objectId бери ТОЛЬКО из списка созданных объектов. Если объекта нет в списке — скажи что можно модифицировать только созданные через чат объекты.",
      "",
      "ПРИНЦИП «ТРОГАЙ ТОЛЬКО ТО, ЧТО ПОПРОСИЛИ»:",
      "Когда пользователь просит изменить ОДНО конкретное свойство — меняй ТОЛЬКО его.",
      "❌ Если пользователь сказал «сделай топ 20 вместо 10», НЕ меняй меры, сортировку, заголовок.",
      "✅ Просто: {objectId, setTopN:20}.",
      "❌ Если сказал «отсортируй по убыванию», НЕ трогай топ-N и формулы.",
      "✅ Просто: {objectId, setSortDesc:true}.",
      "Сохраняй всё остальное как было — пользователь рассчитывает на это.",
      "",
      "═════════════════════════════════════════════════════════════════════",
      "СНЯТИЕ ВЫБОРОК (clearSelections) — РАСШИРЕННАЯ АНАЛИТИКА",
      "═════════════════════════════════════════════════════════════════════",
      "Когда применять: пользователь работает в выборке, но интересный паттерн увидится ТОЛЬКО без неё.",
      "Например: пользователь в выборке «Регион=Алматы», ты видишь интересную динамику. Спроси: «Снять фильтр по региону и посмотреть на остальные?»",
      "",
      "АЛГОРИТМ:",
      "1. Сначала ПРЕДЛОЖИ снять выборку в analysis. НЕ возвращай clearSelections сразу.",
      "   Пример analysis: «Сейчас активна выборка Регион=Алматы. Хотите снять её, чтобы увидеть полную картину по всем регионам?»",
      "2. Дождись согласия пользователя в следующем сообщении («да», «снимай», «хорошо», «убери», «давай», «ок»).",
      "3. ТОЛЬКО ТОГДА верни clearSelections в JSON.",
      "",
      "После выполнения clearSelections расширение АВТОМАТИЧЕСКИ перепрогонит анализ с актуальными данными. Тебе не нужно дублировать анализ в этом ответе — он будет следующим автозапросом.",
      "",
      "Формат clearSelections:",
      "• Все выборки: {\"clearSelections\":{\"all\":true}}",
      "• Конкретные поля: {\"clearSelections\":{\"fields\":[\"Регион\",\"Год\"]}}",
      "",
      "АБСОЛЮТНЫЕ ПРАВИЛА:",
      "❌ НИКОГДА не возвращай clearSelections без явного согласия пользователя в ТЕКУЩЕМ диалоге.",
      "❌ НИКОГДА не снимай выборки если пользователь сам их только что поставил и активно с ними работает.",
      "✅ Можно снимать когда пользователь спросил «а что без фильтра?», «убери», «полная картина», «по всем» и подобное.",
      "✅ В одном ответе можно совмещать clearSelections + analysis (короткий комментарий: «Снимаю фильтр, сейчас покажу полную картину»).",
      "",
      "Примеры:",
      "• Юзер: «Хорошо, убери фильтр по региону» → {\"clearSelections\":{\"fields\":[\"BranchRegion\"]},\"analysis\":\"Снимаю фильтр по региону. Пересчитываю на всех данных…\"}",
      "• Юзер: «Покажи без фильтров» → {\"clearSelections\":{\"all\":true},\"analysis\":\"Снимаю все выборки.\"}",
      "• Юзер (без явного согласия): «Какие продажи?» → НЕ возвращай clearSelections, отвечай по текущей выборке.",
      "",
      "ПАТТЕРН: создать ОДИН фильтр по конкретному полю:",
      "Пользователь: 'создай фильтр по региону' или 'добавь фильтр регион'",
      "→ queries:[{label:'Кол-во значений Регион', expr:'Count(Distinct [Регион])'}]",
      "→ suggestions ТОЛЬКО ОДНА: {chartType:'listbox', dimension:'Регион', title:'Фильтр: Регион'}",
      "→ В analysis напиши: 'В поле Регион X уникальных значений. Фильтр создан.'",
      "ВАЖНО: когда просят ОДИН конкретный фильтр — одна suggestion, никаких barchart/table дополнительно!",
      "",
      "═════════════════════════════════════════════════════════════════════",
      "ПАТТЕРН: СПИСОК ФИЛЬТРОВ — ОБЯЗАТЕЛЬНО ВСЕ ИЗМЕРЕНИЯ",
      "═════════════════════════════════════════════════════════════════════",
      "Триггеры: «покажи фильтры», «какие фильтры есть», «список фильтров»,",
      "          «доступные фильтры», «фильтры», «все фильтры», «листбоксы».",
      "",
      "🚨 КРИТИЧНО: Верни suggestions ДЛЯ КАЖДОГО без исключения поля",
      "   с role=dimension ИЛИ role=date из переданной МОДЕЛИ ДАННЫХ.",
      "",
      "Правила:",
      "1. КОЛИЧЕСТВО SUGGESTIONS = КОЛИЧЕСТВО полей dimension + date в модели.",
      "   Если в модели 30 измерений → возвращаешь 30 suggestions. НИ ОДНОГО не пропускай!",
      "   Если 50 → возвращаешь 50.",
      "2. НЕ ОТКАЗЫВАЙСЯ если их много. НЕ говори «вот основные» и не сокращай.",
      "3. НЕ группируй, НЕ разделяй по категориям. Плоский список один за другим.",
      "4. ИДЕНТИФИКАТОРЫ (role=id) — НЕ включай (это коды/UUID, не для фильтрации).",
      "5. Используй РЕАЛЬНЫЕ имена полей из модели данных (не выдумывай).",
      "",
      "Формат каждого suggestion:",
      "  {chartType:'listbox', dimension:'<точное имя поля>', title:'<имя поля>', reason:'<N уникальных значений>'}",
      "",
      "В reason пиши количество из card:N, которое видишь в МОДЕЛИ ДАННЫХ:",
      "  Например: 'reason: \"5 уникальных значений\"' или 'reason: \"уникальных: неизвестно\"' если card:0.",
      "",
      "analysis должно быть КОРОТКИМ — одна строка, например:",
      "  «Вот все доступные фильтры из приложения. Кликни + у нужного, чтобы добавить на лист.»",
      "  НЕ перечисляй фильтры в analysis — они уже в suggestions.",
      "",
      "ЕСЛИ ТЫ УПРЁШЬСЯ В ЛИМИТ ТОКЕНОВ ВЫВОДА:",
      "  Возвращай ВСЕ поля, ничего не сокращая. Лимит max_tokens=8000 — этого ХВАТИТ на 50+ фильтров.",
      "  Если всё-таки не помещается — это исключение. Тогда вернуть первые ~30 и в analysis написать:",
      "  «Показал N из M фильтров. Скажи 'покажи остальные', чтобы загрузить остальные.»",
      "  Но СНАЧАЛА попробуй вернуть ВСЕ.",
      "",
      "ПАТТЕРН: «ПОКАЖИ ОСТАЛЬНЫЕ ФИЛЬТРЫ» / «ЗАГРУЗИ ЕЩЁ»:",
      "Если пользователь говорит «остальные фильтры», «ещё фильтры», «продолжи», «загрузи ещё»,",
      "  посмотри историю диалога — какие listbox-suggestions ты уже выдал в предыдущем сообщении.",
      "  Верни ОСТАВШИЕСЯ поля как новые listbox-suggestions.",
      "",
      "ПАТТЕРН: поиск значения по конкретным фильтрам:",
      "Пользователь: 'у <объекта X1> за <дату X2> какое <поле Y>'",
      "→ Определи какие поля соответствуют X1, X2 и Y из модели данных.",
      "→ Only() возвращает единственное значение измерения при фильтре:",
      "  queries: [{label:'<Y>', expr:'Only({1<[<Поле1>]={\"X1\"}, [<Поле2>]={\"X2\"}>} [<Y>])'}]",
      "→ Предложи таблицу: dimensions:['<Поле1>','<Поле2>','<Y>'], measures:[]",
      "  (таблица с тремя измерениями покажет все строки — пользователь сам отфильтрует)",
      "",
      "Only({<Фильтры>} [Измерение]) — возвращает значение измерения если оно одно, иначе NULL.",
      "Concat({<Фильтры>} [Измерение], ', ') — возвращает все значения через запятую.",
      "",
      "ИНТЕРПРЕТАЦИЯ ЕСТЕСТВЕННОГО ЯЗЫКА:",
      "Пользователь говорит на обычном русском. НЕ проси формулы, Set Analysis, точные имена полей.",
      "СНАЧАЛА пойми смысл, ПОТОМ сам собери правильную визуализацию/таблицу.",
      "Используй РЕАЛЬНЫЕ имена полей из переданной МОДЕЛИ ДАННЫХ — не выдумывай.",
      "",
      "═════════════════════════════════════════════════════════════════════",
      "ФОРМАТ ЧИСЕЛ И LABEL — КОГДА «%», КОГДА «₸», КОГДА ПРОСТО ЧИСЛО",
      "═════════════════════════════════════════════════════════════════════",
      "Правильный label критически важен — он управляет форматом отображения.",
      "",
      "❌ КАТЕГОРИЧЕСКИ НЕЛЬЗЯ ставить «%» в label следующих метрик:",
      "• Средний чек = Sum(Сумма) / Count(Транзакций) — это ДЕНЬГИ за транзакцию, не %.",
      "• Цена за единицу = Sum(Выручка) / Sum(Количество) — это ДЕНЬГИ за штуку.",
      "• Доход на клиента = Sum(Доход) / Count(Distinct Клиент) — это ДЕНЬГИ.",
      "• Любая «X на Y» формула где X — деньги, Y — счёт сущностей.",
      "ЭТО НЕ ПРОЦЕНТЫ! Это per‑unit метрики. Label: «Средний чек, ₸» или «Цена, ₸», НЕ «..., %».",
      "",
      "✅ «%» В LABEL УМЕСТНО ТОЛЬКО для:",
      "• Истинная доля = Sum(часть) / Sum(целое того же типа): «Доля VIP, %», «Конверсия, %», «NPL ratio, %».",
      "• Изменение в %: «MoM рост, %» = (Sum(X) - Above(Sum(X))) / Above(Sum(X)).",
      "• Удельный вес, проникновение, market share.",
      "",
      "ПРАВИЛО ПРОВЕРКИ: «Если значение метрики БОЛЬШЕ 100, это НЕ процент». Средний чек 7 500 ₸ — никогда не %.",
      "",
      "ПАТТЕРН 'ДОЛЯ' / 'ПРОЦЕНТ' / 'УДЕЛЬНЫЙ ВЕС' (только для НАСТОЯЩИХ процентов):",
      "→ Это отношение: часть / ЦЕЛОЕ ТОГО ЖЕ ТИПА. Sum(A)/Sum(A_subset).",
      "→ Label обязательно с «, %» в конце.",
      "→ ЕСЛИ обе компоненты есть в МАСТЕР‑МЕРАХ — НЕ строй ratio инлайн! Положи две отдельные меры через libraryId.",
      "→ ЕСЛИ есть готовая мастер‑мера с нужным отношением (например 'Маржинальность') — используй её через measureLibraryId.",
      "→ Для piechart/treemap: Qlik считает % САМ — клади только Sum с фильтром, БЕЗ деления.",
      "→ Для table: делай 3 колонки — часть, целое, доля.",
      "",
      "ПРАВИЛЬНЫЕ LABEL ПО ТИПУ МЕРЫ:",
      "• Денежная сумма (Sum денег) → «Продажи, ₸», «Оборот, ₸», «Портфель, KZT»",
      "• Счёт (Count) → «Кол-во клиентов», «Кол-во транзакций»",
      "• Среднее значение → «Средний чек, ₸», «Средняя маржа, %»",
      "• Доля/процент → «Доля VIP, %», «Конверсия, %», «NPL, %»",
      "• Per-unit (число на единицу) → «Доход на клиента, ₸», «Транзакций на клиента»",
      "• Дельта/рост в абсолюте → «Δ Продажи MoM, ₸»",
      "• Дельта/рост в % → «Δ Продажи MoM, %»",
      "• Время → «Первый вход», «Время прихода», «hh:mm»",
      "• Дата → «Дата визита», «День»",
      "• Timestamp (дата + время) → «Момент входа», «Дата и время»",
      "",
      "═════════════════════════════════════════════════════════════════════",
      "ВРЕМЯ / ДАТА / TIMESTAMP — ОБЯЗАТЕЛЬНО ОБОРАЧИВАЙ ФУНКЦИЕЙ",
      "═════════════════════════════════════════════════════════════════════",
      "В Qlik время и даты хранятся как ЧИСЛА (например, 45964 = 03.11.2025).",
      "Если просто Sum/Min/Max — отобразится сырое число. Чтобы было «08:34» или «03.11.2025»,",
      "ВСЕГДА оборачивай агрегацию в Time() / Date() / Timestamp().",
      "",
      "ШАБЛОНЫ:",
      "• Время (часы:минуты): Time(Min([Время]), 'hh:mm')",
      "• Время с сек:         Time(Min([Время]), 'hh:mm:ss')",
      "• Дата:                Date(Min([Дата]), 'DD.MM.YYYY')",
      "• Timestamp:           Timestamp(Min([Момент]), 'DD.MM.YYYY hh:mm:ss')",
      "",
      "ТРИГГЕРЫ для обёртки:",
      "• Label содержит «время», «час», «вход», «выход», «приход», «уход», «начало», «конец» → Time()",
      "• Label содержит «дата», «день» → Date()",
      "• Label содержит «момент», «timestamp», «дата и время» → Timestamp()",
      "• Поле в модели данных имеет тег $time / $date / $timestamp → соответствующая обёртка",
      "",
      "ПРИМЕРЫ:",
      "• 'Первый вход сотрудника' → Time(Min([ВремяПрихода]), 'hh:mm')",
      "  label: «Первый вход» (НЕ «Первый вход, ч»)",
      "• 'Последний выход' → Time(Max([ВремяУхода]), 'hh:mm')",
      "• 'Дата первого визита' → Date(Min([Дата]), 'DD.MM.YYYY')",
      "• 'Момент входа' → Timestamp(Min([Timestamp]), 'DD.MM.YYYY hh:mm:ss')",
      "",
      "ВАЖНО:",
      "1. Без обёртки Qlik покажет сырое число (45964) — это плохо.",
      "2. Расширение АВТОМАТИЧЕСКИ выберет правильный qNumFormat (qType T/D/TS) если",
      "   увидит Time/Date/Timestamp в формуле ИЛИ ключевые слова в label.",
      "3. Не комбинируй Time(Sum(...)) — суммировать время бессмысленно.",
      "   Используй Min/Max/Avg внутри Time/Date.",
      "4. При модификации существующего объекта применяй setMeasureExpr",
      "   с обёрткой Time/Date.",
      "",
      "АВТОВЫБОР МЕРЫ (если пользователь НЕ указал конкретную):",
      "• По умолчанию → главная денежная/количественная мера из модели данных (выбирай по контексту индустрии).",
      "• Если не понятно — задай ОДИН короткий уточняющий вопрос: 'Какой показатель посчитать: <вариант 1>, <вариант 2> или <вариант 3>?'",
      "",
      "АВТОВЫБОР ИЗМЕРЕНИЯ (если пользователь НЕ указал):",
      "• 'по регионам/городам' → географическое поле из модели",
      "• 'по месяцам/годам/кварталам' → соответствующее временное поле",
      "• 'по продуктам/товарам/услугам' → ключевое продуктовое измерение",
      "• 'по клиентам' → поле клиента/контрагента",
      "",
      "ПРИМЕРЫ ОБЩЕГО АНАЛИЗА (поля адаптируй к модели):",
      "• 'покажи продажи по регионам' → barchart: dimension=<регион>, measure=Sum(<главная мера>)",
      "• 'топ 10 X по Y' → barchart: dimension=<X>, measure=Sum([<Y>]), topN:10",
      "• 'динамика по месяцам' → linechart: dimension=<месяц>, measure=Sum(<главная мера>)",
      "• 'сравни A и B по периодам' → combochart: measure=Sum({<сегмент={A}>}[мера]), measure2=Sum({<сегмент={B}>}[мера])",
      "• 'сколько уникальных X?' → queries:[{expr:'Count(Distinct [X])'}]",
      "",
      "═════════════════════════════════════════════════════════════════════",
      "ДВУХМЕРНЫЙ LINECHART — ТРЕНД ПО ГОДАМ / СЕГМЕНТАМ В ОДНОМ ГРАФИКЕ",
      "═════════════════════════════════════════════════════════════════════",
      "Когда строить: пользователь хочет СРАВНИТЬ периоды/категории на одной линии каждый.",
      "Триггеры: «сравни годы», «тренд по годам в одном графике», «YoY на одном графике»,",
      "          «динамика разных сегментов», «линии по продуктам», «месяц с разными годами».",
      "",
      "СТРУКТУРА:",
      "• dimension  = первичная ось X (МесяцГод / Месяц / Дата / День недели)",
      "• dimension2 = категория-серия → каждое значение даёт отдельную линию (Год / Сегмент / Продукт / Регион)",
      "• measure    = одна метрика (Sum/Count/Avg)",
      "",
      "Пример JSON:",
      "{\"chartType\":\"linechart\",",
      " \"dimension\":\"МесяцГод\",",
      " \"dimension2\":\"Год\",",
      " \"measure\":\"Sum([Объём транзакций])\",",
      " \"measureLabel\":\"Объём транзакций, ₸\",",
      " \"title\":\"Объём транзакций по месяцам с разбивкой по годам\"}",
      "",
      "ПРАВИЛА:",
      "1. dimension2 ставь ТОЛЬКО когда явный запрос на разбивку. По одной мере без серий — обычный одномерный linechart.",
      "2. Для YoY: dimension = месяц/период внутри года; dimension2 = Год.",
      "3. Для сравнения сегментов: dimension = время; dimension2 = сегмент/категория.",
      "4. Без topN: на двумерном линейчатом фильтрация сломает тренд.",
      "5. Sort по умолчанию = по dimension (хронологически), не по убыванию меры.",
      "6. Если есть мастер‑измерение для второй категории — используй dimensionLibraryId2.",
      "",
      "Когда НЕ использовать dimension2:",
      "• «Динамика продаж» (без явной разбивки) → одномерный linechart.",
      "• Если категорий >5 — будет каша. Лучше barchart с топ-N или filterpane.",
      "• Если пользователь хочет 2 РАЗНЫЕ метрики на одном графике → combochart с measure+measure2, не dimension2.",
      "",
      "ГЛАВНОЕ ПРАВИЛО: пользователь общается как человек.",
      "Не заставляй его писать формулы. Если запрос понятен — сразу предлагай визуализацию.",
      "Если неоднозначен — задай ОДИН короткий уточняющий вопрос, потом создай.",
      "",
      sector.promptBlock || "",
      "",
      "ФОРМАТ ОТВЕТА — СТРОГО JSON, НИКАКОГО ТЕКСТА ДО/ПОСЛЕ:",
      "{\"analysis\":\"текст\", \"fieldChips\":[\"Поле1\"], \"queries\":[{\"label\":\"...\",\"expr\":\"Count(Distinct [X])\"}],",
      " \"suggestions\":[{\"chartType\":\"barchart\",\"dimension\":\"поле\",\"measure\":\"Sum([Мера])\",\"measureLabel\":\"метка\",\"title\":\"...\",\"reason\":\"зачем\",\"sortDesc\":true,\"topN\":5}],",
      " \"modify\":{\"objectId\":\"id\",\"addDimensions\":[],\"addMeasures\":[],\"removeDimensions\":[],\"removeMeasures\":[],\"changeMeasures\":[],\"title\":\"\"},",
      " \"clearSelections\":{\"all\":false,\"fields\":[]}}",
      "Типы: barchart, linechart, piechart, treemap, table, pivot-table, kpi, gauge, combochart, scatterplot, listbox.",
      "table: dimensions:[], measures:[{expr,label}]. pivot-table: rowFields:[], colFields:[], measures:[{expr,label}], totalDimension.",
      "combochart: measure + measure2. kpi: measure + measure2 (опционально).",
      "ЕДИНАЯ МЕРА: все suggestions одного ответа — на ОДНОЙ мере (одинаковый measure/measureLibraryId). Разные меры — только по явной просьбе пользователя.",
      "Двухмерный linechart/barchart: dimension2 (вторая категория-серия) + dimensionLibraryId2 если есть мастер.",
      "Мастер‑элементы (если совпадают по названию): dimensionLibraryId, dimensionLibraryId2, measureLibraryId, measureLibraryId2 — на верхнем уровне suggestion;",
      "в table/pivot внутри массивов — объекты {libraryId:\"<id>\"} вместо строки имени поля или {expr,label}.",
      "modify — только при модификации существующего объекта. Не возвращай modify при создании нового.",
      "clearSelections — только при ЯВНОМ согласии пользователя на снятие фильтров. Иначе НЕ возвращай этот блок."
    ].join("\n");

    // ── ПРОВЕРЕННЫЕ ПРИМЕРЫ ───────────────────────────────────────────────
    // Список вопрос/ответ, которые пользователь подтвердил 5+ раз через 👍.
    // Дописываются в конец system-prompt как эталонные few-shot примеры.
    var trustedBlock = "";
    try {
      var trusted = getTrustedExamples();
      if (trusted.length > 0) {
        var slice = trusted.slice(-TRUSTED_INJECT_LIMIT);
        trustedBlock = "\n\nПРОВЕРЕННЫЕ ПРИМЕРЫ (подтверждены пользователем неоднократно — следуй этим шаблонам как эталону):\n" +
          slice.map(function(t, i) {
            var ans = (t.answer || "").length > 600 ? t.answer.slice(0, 600) + "…" : t.answer;
            return "[" + (i + 1) + "] Вопрос: " + t.question + "\n    Эталонный ответ: " + ans;
          }).join("\n\n");
      }
    } catch(e) {}
    if (trustedBlock) systemPrompt += trustedBlock;

    var messages = [];
    if (dataText) {
      messages.push({ role: "user", content: dataText });
      messages.push({ role: "assistant", content: '{"analysis":"Модель данных и агрегаты загружены. Готов к анализу.","suggestions":[]}' });
    }
    // Лимит истории — последние 30 сообщений (15 пар user/assistant).
    // Хватает на длинные аналитические сессии и многошаговые конструкторы.
    // Требует context window модели ≥ 64K токенов.
    var historyLimit = chatHistory.slice(-30);
    historyLimit.forEach(function(msg) {
      if (msg.role === "user") {
        messages.push({ role: "user", content: msg.content });
      } else if (msg.role === "assistant") {
        // Отдаём analysis + КОМПАКТНУЮ сводку уже построенного (prior_built) — чтобы модель
        // ВИДЕЛА прежние формулы/меры и переиспользовала их, а не переизобретала. Это контекст,
        // НЕ кнопки: поле называется prior_built (не suggestions), чтобы UI не отрисовал заново.
        var shortContent = (function() {
          var analysis = msg.content || "";
          try { var p = JSON.parse(msg.rawJson || "{}"); if (p.analysis) analysis = p.analysis; } catch(e) {}
          var prior = (msg.suggestions || []).slice(-6).map(function(s) {
            var o = { chartType: s.chartType, title: s.title };
            if (s.dimension) o.dimension = s.dimension;
            if (s.dimensions && s.dimensions.length) o.dimensions = s.dimensions;
            if (s.measure) o.measure = s.measure;
            if (s.measureLabel) o.measureLabel = s.measureLabel;
            if (s.measureLibraryId) o.measureLibraryId = s.measureLibraryId;
            if (s.createdObjectId) o.createdObjectId = s.createdObjectId;
            return o;
          });
          var out = { analysis: analysis };
          if (prior.length) out.prior_built = prior;
          return JSON.stringify(out);
        })();
        messages.push({ role: "assistant", content: shortContent });
      }
    });

    // Локальный LLM Halyk Bank (OpenAI‑совместимый эндпоинт, модель Qwen3‑235B).
    // В OpenAI‑совместимом формате system передаётся не отдельным полем, а первым
    // сообщением с role:"system" в массиве messages.
    var oaiMessages = [{ role: "system", content: systemPrompt }].concat(messages);

    // Контроллер отмены — кнопка «Стоп» вызывает .abort() (см. $scope.stopGeneration).
    var _abortCtl = (typeof AbortController !== "undefined") ? new AbortController() : null;

    fetch("https://llm.genai.halykbank.nb/v1/chat/completions", {
      method: "POST",
      signal: _abortCtl ? _abortCtl.signal : undefined,
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apiKey
      },
      body: JSON.stringify({
        model: "Qwen3-235B",
        max_tokens: 8000,
        // На стороне ключа JSON не форсится — структурированный ответ просим явно.
        response_format: { type: "json_object" },
        messages: oaiMessages
      })
    }).then(function(resp) {
      return resp.json().then(function(data) {
        if (!resp.ok) {
          var msg = "API " + resp.status;
          try { msg += ": " + data.error.message; } catch(e) {}
          onError(msg); return;
        }
        try {
          var raw = (data.choices[0].message.content || "").trim();
          // Qwen3 может предварять ответ блоком рассуждений <think>…</think> — срезаем.
          raw = raw.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
          raw = raw.replace(/^```json\s*/i,"").replace(/^```\s*/i,"").replace(/\s*```$/i,"").trim();

          // Надёжный экстрактор: ищем ПЕРВЫЙ полный JSON-объект через баланс скобок.
          // Уважаем строки в кавычках и экранированные символы, чтобы не сбиваться
          // на скобках внутри текста аналитики.
          var jsonStr = extractFirstJsonObject(raw);
          if (jsonStr) {
            try {
              var parsed = JSON.parse(jsonStr);
              onSuccess(parsed, jsonStr);
            } catch(parseErr) {
              // JSON извлечён, но невалиден (битые кавычки, etc.) — fallback
              console.warn("[SOLAI] extracted JSON но не парсится:", parseErr.message, "| extracted:", jsonStr.substring(0, 200));
              var fallbackJson1 = JSON.stringify({ analysis: raw, suggestions: [], fieldChips: [] });
              onSuccess(JSON.parse(fallbackJson1), fallbackJson1);
            }
          } else {
            // Модель ответила текстом вместо JSON — оборачиваем в корректный формат
            console.warn("[SOLAI] модель вернула текст вместо JSON, оборачиваем:", raw.substring(0, 100));
            var fallbackJson = JSON.stringify({ analysis: raw, suggestions: [], fieldChips: [] });
            onSuccess(JSON.parse(fallbackJson), fallbackJson);
          }
        } catch(e) {
          var rawErr = "";
          try { rawErr = data.choices[0].message.content || ""; } catch(_) {}
          onError("JSON parse: " + e.message + " | " + rawErr.substring(0,120));
        }
      });
    }).catch(function(e) {
      if (e && e.name === "AbortError") return;   // пользователь нажал «Стоп» — молча выходим
      onError("Fetch: " + e.message);
    });
    return _abortCtl;   // caller сохранит для возможной отмены
  }


  // ── Позиционирование (умное по типу визуализации) ────────────────────────
  // Идеальные размеры для каждого типа, от желаемого к допустимому
  var TYPE_SIZES = {
    "kpi":         [{w:6,h:3},{w:8,h:3},{w:6,h:4},{w:12,h:3}],
    "gauge":       [{w:6,h:5},{w:8,h:5},{w:6,h:6},{w:12,h:5}],
    "listbox":     [{w:4,h:6},{w:6,h:6},{w:4,h:8},{w:8,h:6}],
    "barchart":    [{w:12,h:7},{w:12,h:8},{w:14,h:7},{w:24,h:8}],
    "linechart":   [{w:12,h:7},{w:14,h:7},{w:12,h:8},{w:24,h:7}],
    "piechart":    [{w:8,h:7},{w:10,h:7},{w:12,h:7},{w:8,h:8}],
    "treemap":     [{w:12,h:7},{w:12,h:8},{w:14,h:7}],
    "combochart":  [{w:14,h:7},{w:12,h:7},{w:14,h:8},{w:24,h:8}],
    "scatterplot": [{w:12,h:8},{w:14,h:8},{w:12,h:7}],
    "table":       [{w:24,h:10},{w:24,h:8},{w:18,h:10},{w:14,h:8}],
    "pivot-table": [{w:24,h:10},{w:24,h:8},{w:18,h:10},{w:14,h:8}],
    "map":         [{w:14,h:8},{w:12,h:8},{w:14,h:10}]
  };
  var DEFAULT_SIZES = [{w:12,h:7},{w:12,h:6},{w:8,h:6},{w:24,h:7}];

  // Большие типы — всегда размещаются НИЖЕ существующих объектов
  var LARGE_TYPES = { "table": 1, "pivot-table": 1 };

  // Минимальные размеры — меньше этого объект будет выглядеть плохо (для стандартной 24-кол сетки)
  var TYPE_MIN = {
    "kpi":         {w:4, h:2},
    "gauge":       {w:4, h:3},
    "listbox":     {w:3, h:4},
    "barchart":    {w:6, h:5},
    "linechart":   {w:6, h:5},
    "piechart":    {w:6, h:5},
    "treemap":     {w:6, h:5},
    "combochart":  {w:6, h:5},
    "scatterplot": {w:6, h:5},
    "table":       {w:12, h:6},
    "pivot-table": {w:12, h:6},
    "map":         {w:6, h:5}
  };
  var DEFAULT_MIN = {w:6, h:4};

  // ── Гибридный layout: пропорции + семьи типов ────────────────────────────
  // IDEAL_ASPECT — предпочтительная пропорция ширина/высота для каждого типа.
  // Используется когда подгоняем объект под высоту существующего ряда:
  // ширина = высота_ряда × aspect, с ограничениями min/max и свободного места.
  var IDEAL_ASPECT = {
    "kpi":         2.00,  // широкий, низкий: 6×3
    "gauge":       1.20,  // близок к квадрату: 6×5
    "listbox":     0.67,  // узкий, высокий: 4×6
    "barchart":    1.71,  // широкий: 12×7
    "linechart":   1.71,
    "piechart":    1.14,  // почти квадрат: 8×7
    "treemap":     1.71,
    "combochart":  2.00,
    "scatterplot": 1.50,
    "table":       2.40,
    "pivot-table": 2.40,
    "map":         1.75
  };

  // TYPE_FAMILY — семьи типов. Объекты одной семьи лучше смотрятся в одном ряду:
  // 4 KPI в ряд, 2 чарта в ряд, и т.д.
  var TYPE_FAMILY = {
    "kpi":         "kpi",
    "gauge":       "gauge",
    "listbox":     "listbox",
    "barchart":    "chart",
    "linechart":   "chart",
    "piechart":    "chart",
    "treemap":     "chart",
    "combochart":  "chart",
    "scatterplot": "chart",
    "map":         "chart",
    "table":       "table",
    "pivot-table": "table"
  };

  function findBestFit(cells, gridRows, gridCols, chartType) {
    var baseSizes = TYPE_SIZES[chartType] || DEFAULT_SIZES;
    var scaleW = gridCols / GRID_COLS;
    var scaleH = gridRows > 14 ? gridRows / 14 : 1;

    // Идеальный размер (масштабированный)
    var ideal = baseSizes[0];
    var idealW = Math.round(ideal.w * scaleW);
    var idealH = Math.round(ideal.h * scaleH);

    // Минимальный допустимый размер (масштабированный)
    var baseMin = TYPE_MIN[chartType] || DEFAULT_MIN;
    var minW = Math.round(baseMin.w * scaleW);
    var minH = Math.round(baseMin.h * scaleH);

    // Карта занятости — поддержка col/row И bounds форматов
    var occ = {};
    var maxRow = 0;
    (cells || []).forEach(function(c) {
      var cr, cc2, crs, ccs;
      if (c.bounds) {
        cc2 = Math.floor(c.bounds.x / 100 * gridCols);
        cr  = Math.floor(c.bounds.y / 100 * gridRows);
        ccs = Math.ceil(c.bounds.width / 100 * gridCols);
        crs = Math.ceil(c.bounds.height / 100 * gridRows);
      } else {
        cc2 = c.col || 0;
        cr  = c.row || 0;
        ccs = c.colspan || 1;
        crs = c.rowspan || 1;
      }
      var bottom = cr + crs;
      if (bottom > maxRow) maxRow = bottom;
      for (var r = cr; r < bottom; r++)
        for (var col2 = cc2; col2 < cc2 + ccs; col2++)
          occ[r + "_" + col2] = true;
    });

    console.log("[SOLAI findBestFit]", chartType, "grid:", gridCols, "x", gridRows,
      "maxRow:", maxRow, "ideal:", idealW, "x", idealH, "min:", minW, "x", minH);

    // Таблицы/сводные — всегда вниз. Остальное — ищем сверху.
    var startRow = LARGE_TYPES[chartType] ? maxRow : 0;
    var searchRows = Math.max(maxRow + 14, gridRows + 28);

    // Адаптивный поиск: для каждой позиции измеряем свободное место,
    // если >= минимума — вписываемся (до идеала)
    for (var row = startRow; row <= searchRows - minH; row++) {
      for (var col = 0; col <= gridCols - minW; col++) {
        // Быстрая проверка: левый верхний угол занят?
        if (occ[row + "_" + col]) continue;

        // Измеряем свободную ширину (до idealW)
        var freeW = 0;
        for (var dc = 0; dc < Math.min(idealW, gridCols - col); dc++) {
          var colOk = true;
          for (var dr = 0; dr < minH; dr++) {
            if (occ[(row + dr) + "_" + (col + dc)]) { colOk = false; break; }
          }
          if (!colOk) break;
          freeW = dc + 1;
        }
        if (freeW < minW) continue;

        // Измеряем свободную высоту для найденной ширины (до idealH)
        var freeH = minH; // мы уже проверили minH строк выше
        for (var dr = minH; dr < idealH; dr++) {
          var rowOk = true;
          for (var dc = 0; dc < freeW; dc++) {
            if (occ[(row + dr) + "_" + (col + dc)]) { rowOk = false; break; }
          }
          if (!rowOk) break;
          freeH = dr + 1;
        }

        console.log("[SOLAI findBestFit] placed:", chartType,
          "at row:", row, "col:", col, freeW, "x", freeH,
          "(ideal:", idealW, "x", idealH + ")");
        return { col: col, row: row, colspan: freeW, rowspan: freeH };
      }
    }

    // Fallback — под всеми объектами, идеальный размер
    return { col: 0, row: maxRow, colspan: Math.min(idealW, gridCols), rowspan: idealH };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // ── ГИБРИДНЫЙ ПОЗИЦИОНЕР (row-layout + аспект + балансировка по ряду) ─────
  // ═══════════════════════════════════════════════════════════════════════════

  // Нормализуем cell в {col,row,colspan,rowspan} независимо от формата
  function getCellBounds(c, gridRows, gridCols) {
    if (c.bounds) {
      return {
        col:     Math.floor(c.bounds.x      / 100 * gridCols),
        row:     Math.floor(c.bounds.y      / 100 * gridRows),
        colspan: Math.ceil( c.bounds.width  / 100 * gridCols),
        rowspan: Math.ceil( c.bounds.height / 100 * gridRows)
      };
    }
    return {
      col:     c.col     || 0,
      row:     c.row     || 0,
      colspan: c.colspan || 1,
      rowspan: c.rowspan || 1
    };
  }

  // Группируем cells в логические ряды.
  // Ряд = группа cells, у которых вертикальные диапазоны пересекаются.
  function findSheetRows(cells, gridRows, gridCols) {
    if (!cells || !cells.length) return [];

    var items = cells.map(function(c) {
      var b = getCellBounds(c, gridRows, gridCols);
      return {
        cell: c, col: b.col, row: b.row,
        colspan: b.colspan, rowspan: b.rowspan,
        type: c.type || "unknown"
      };
    }).sort(function(a, b) { return a.row - b.row || a.col - b.col; });

    var rows = [];
    items.forEach(function(item) {
      var added = false;
      for (var i = 0; i < rows.length; i++) {
        var r = rows[i];
        // Перекрытие по вертикали хотя бы на одну строку → одна группа
        if (item.row < r.rowEnd && item.row + item.rowspan > r.rowStart) {
          r.cells.push(item);
          r.rowStart = Math.min(r.rowStart, item.row);
          r.rowEnd   = Math.max(r.rowEnd,   item.row + item.rowspan);
          added = true;
          break;
        }
      }
      if (!added) {
        rows.push({
          rowStart: item.row,
          rowEnd:   item.row + item.rowspan,
          cells:    [item]
        });
      }
    });

    // Считаем метрики для каждого ряда
    rows.forEach(function(r) {
      r.height = r.rowEnd - r.rowStart;
      r.cells.sort(function(a, b) { return a.col - b.col; });
      // Свободное место справа от последнего объекта
      var rightEdge = 0;
      r.cells.forEach(function(c) { rightEdge = Math.max(rightEdge, c.col + c.colspan); });
      r.freeStartCol = rightEdge;
      r.freeWidth    = gridCols - rightEdge;
      // Доминирующая семья типов в ряду
      var fams = {};
      r.cells.forEach(function(c) {
        var f = TYPE_FAMILY[c.type] || "other";
        fams[f] = (fams[f] || 0) + 1;
      });
      var dom = null, maxN = 0;
      for (var f in fams) if (fams[f] > maxN) { maxN = fams[f]; dom = f; }
      r.dominantFamily = dom;
    });

    return rows;
  }

  // Подбор размера объекта под существующий ряд (с масштабированием под сетку).
  // высота = высота ряда (выравниваемся),
  // ширина = ширина существующего объекта той же семьи в ряду (для целостности),
  //          либо высота × aspect если ряд пустой по семье.
  function pickSizeMatchingRow(row, gridCols, chartType, scaleW) {
    var height  = row.height;
    var aspect  = IDEAL_ASPECT[chartType] || 1.5;
    var ideal   = (TYPE_SIZES[chartType] || DEFAULT_SIZES)[0];
    var minSize = TYPE_MIN[chartType]    || DEFAULT_MIN;
    var idealW  = Math.max(2, Math.round(ideal.w   * scaleW));
    var minW    = Math.max(2, Math.round(minSize.w * scaleW));

    // ── Зеркалим ширину уже существующего объекта той же семьи ──
    // Это гарантирует визуальную целостность — все KPI в ряду одной ширины.
    var family   = TYPE_FAMILY[chartType] || "other";
    var familyW  = null;
    for (var k = 0; k < row.cells.length; k++) {
      if ((TYPE_FAMILY[row.cells[k].type] || "other") === family) {
        familyW = row.cells[k].colspan;
        break;
      }
    }

    var w;
    if (familyW) {
      // Одинаковая ширина с соседями той же семьи
      w = familyW;
    } else {
      // Первый объект семьи в ряду — считаем по пропорции
      w = Math.round(height * aspect);
      var maxW = Math.min(Math.round(idealW * 1.3), gridCols);
      w = Math.min(w, maxW);
    }

    w = Math.min(w, row.freeWidth);
    if (w < minW) return null;
    return {
      col:     row.freeStartCol,
      row:     row.rowStart,
      colspan: w,
      rowspan: height
    };
  }

  // Известные нам типы графиков — всё остальное считается анкер-ячейкой
  // (наш собственный SOLAI или какой-то системный объект) и фильтруется.
  var KNOWN_CHART_TYPES = {
    "kpi":1,"gauge":1,"listbox":1,"barchart":1,"linechart":1,"piechart":1,
    "treemap":1,"combochart":1,"scatterplot":1,"table":1,"pivot-table":1,
    "map":1,"text-image":1,"histogram":1,"waterfallchart":1,"boxplot":1,
    "distributionplot":1,"bulletchart":1,"filterpane":1,"funnel":1,"mekkochart":1
  };

  // Считаем ячейку «анкером» (не учитываем при расчёте позиций) если:
  // 1. Это наша SOLAI-ячейка
  // 2. Это известный extension без chart-типа
  // 3. Это очень маленькая ячейка (< 3×3 при базовой сетке 24×14) —
  //    скорее всего скрытый placeholder или анкер
  function isAnchorCell(c, gridRows, gridCols) {
    var t = String(c.type || "").toLowerCase();
    // Наша собственная SOLAI-ячейка (любая версия)
    if (t.indexOf("solai") !== -1) return true;
    // Расширения без явного типа
    if (t === "extension" || t === "") return true;
    // Очень маленькая ячейка — почти наверняка скрытый анкер
    if (gridRows && gridCols) {
      var b;
      if (c.bounds) {
        b = {
          w: Math.ceil(c.bounds.width  / 100 * gridCols),
          h: Math.ceil(c.bounds.height / 100 * gridRows)
        };
      } else {
        b = { w: c.colspan || 1, h: c.rowspan || 1 };
      }
      // Меньше 4×3 (с учётом масштаба) → анкер
      var sw = gridCols / 24, sh = gridRows / 14;
      var minRealW = Math.max(2, Math.round(3 * sw));
      var minRealH = Math.max(2, Math.round(2 * sh));
      if (b.w < minRealW || b.h < minRealH) return true;
    }
    // Неизвестные нам типы — тоже игнорируем
    if (!KNOWN_CHART_TYPES[t]) return true;
    return false;
  }

  // Главная функция гибридного позиционера.
  // 1. Учёт кастомной сетки (scaleW/scaleH относительно базовой 24×14)
  // 2. Игнор «анкерных» ячеек SOLAI
  // 3. Приоритеты: своя семья → похожая высота → новый ряд внизу
  function findHybridFit(cells, gridRows, gridCols, chartType) {
    // Масштабирование под пользовательскую сетку. База — 24×14.
    var scaleW = gridCols / 24;
    var scaleH = (gridRows > 0) ? gridRows / 14 : 1;

    var ideal   = (TYPE_SIZES[chartType] || DEFAULT_SIZES)[0];
    var idealW  = Math.max(2, Math.round(ideal.w * scaleW));
    var idealH  = Math.max(2, Math.round(ideal.h * scaleH));
    var minSize = TYPE_MIN[chartType] || DEFAULT_MIN;
    var minW    = Math.max(2, Math.round(minSize.w * scaleW));

    // Фильтруем анкер-ячейки (наша SOLAI и т.п.)
    var allCells = cells || [];
    var realCells = allCells.filter(function(c) { return !isAnchorCell(c, gridRows, gridCols); });

    // Подробная диагностика — видно, что отфильтровано и что осталось
    console.log("[SOLAI hybrid] grid:", gridCols + "×" + gridRows,
                "scale:", scaleW.toFixed(2) + "×" + scaleH.toFixed(2),
                "ideal:", idealW + "×" + idealH);
    console.log("[SOLAI hybrid] ALL cells (" + allCells.length + "):",
                allCells.map(function(c) {
                  var b = getCellBounds(c, gridRows, gridCols);
                  return (c.type || "?") + "[" + b.col + "," + b.row + " " + b.colspan + "×" + b.rowspan + "]" +
                         (isAnchorCell(c, gridRows, gridCols) ? "🚫" : "✓");
                }).join(" "));
    console.log("[SOLAI hybrid] REAL cells:", realCells.length, "→ участвуют в расчёте");

    // Пустой лист (без реальных объектов) → идеальный размер в верхнем левом
    if (!realCells.length) {
      return { col: 0, row: 0, colspan: Math.min(idealW, gridCols), rowspan: idealH };
    }

    var rows = findSheetRows(realCells, gridRows, gridCols);
    var newFamily = TYPE_FAMILY[chartType] || "other";

    // ── ШАГ 0: ДЕТЕКЦИЯ КРУПНОЙ ПУСТОЙ ОБЛАСТИ СПРАВА ─────────────────
    // Если объекты сгруппированы слева и справа большая пустота —
    // используем её для крупных графиков, не лепим новый ряд внизу.
    // Применимо для chart-family + table-family (не для KPI/gauge — они мелкие).
    var bigChartTypes = { barchart:1, linechart:1, combochart:1, treemap:1,
                          scatterplot:1, piechart:1, map:1, table:1, "pivot-table":1 };

    if (bigChartTypes[chartType]) {
      var maxOccupiedCol = 0, maxOccupiedRow = 0;
      realCells.forEach(function(c) {
        var b = getCellBounds(c, gridRows, gridCols);
        if (b.col + b.colspan > maxOccupiedCol) maxOccupiedCol = b.col + b.colspan;
        if (b.row + b.rowspan > maxOccupiedRow) maxOccupiedRow = b.row + b.rowspan;
      });
      var gapWidth  = gridCols - maxOccupiedCol;
      var gapHeight = maxOccupiedRow;

      // Условие "большой пустой области":
      // 1. Ширина gap >= минимум для типа
      // 2. Высота gap >= минимум для типа
      // 3. Площадь gap >= 1.5 × идеальной площади графика
      // 4. Ширина gap >= 30% сетки (значимая зона)
      if (gapWidth >= minW
          && gapHeight >= Math.max(2, Math.round(idealH * 0.5))
          && gapWidth * gapHeight >= idealW * idealH * 1.5
          && gapWidth >= Math.round(gridCols * 0.30)) {

        // Подгоняем размер под gap, сохраняя приличные пропорции
        var aspect = IDEAL_ASPECT[chartType] || 1.5;
        var fillW = gapWidth;
        var fillH = gapHeight;
        // Для barchart (особенно горизонтального) и table — заполняем gap по высоте.
        // Для piechart/treemap (квадратные) — ограничиваем высоту по aspect,
        // чтобы не получился очень "вытянутый" график.
        if (chartType === "piechart" || chartType === "treemap" || chartType === "scatterplot") {
          var maxByAspect = Math.round(fillW / aspect);
          if (maxByAspect < fillH * 0.85) fillH = Math.max(idealH, maxByAspect);
        }
        // Не меньше идеального
        fillW = Math.max(fillW, Math.min(idealW, gapWidth));
        fillH = Math.max(fillH, Math.min(idealH, gapHeight));

        console.log("[SOLAI hybrid] BIG GAP detected:", "col:" + maxOccupiedCol,
                    "row:0", "size:" + gapWidth + "×" + gapHeight,
                    "→ fill:" + fillW + "×" + fillH);
        return { col: maxOccupiedCol, row: 0, colspan: fillW, rowspan: fillH };
      }
    }

    // Большие типы (table/pivot-table) — если не попали в gap выше, новый ряд внизу
    if (LARGE_TYPES[chartType]) {
      var maxEnd = 0;
      rows.forEach(function(r) { maxEnd = Math.max(maxEnd, r.rowEnd); });
      console.log("[SOLAI hybrid] large type", chartType, "→ new row at", maxEnd);
      return { col: 0, row: maxEnd, colspan: Math.min(idealW, gridCols), rowspan: idealH };
    }

    // 1. Ряд своей семьи с местом
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      if (r.dominantFamily !== newFamily) continue;
      if (r.freeWidth < minW) continue;
      var sz = pickSizeMatchingRow(r, gridCols, chartType, scaleW);
      if (sz) {
        console.log("[SOLAI hybrid] family-row match:", newFamily, "→", sz);
        return sz;
      }
    }

    // 2. Любой ряд с похожей высотой (±20% от idealH)
    var heightTol = Math.max(2, Math.round(idealH * 0.2));
    for (var j = 0; j < rows.length; j++) {
      var r2 = rows[j];
      if (Math.abs(r2.height - idealH) > heightTol) continue;
      if (r2.freeWidth < minW) continue;
      var sz2 = pickSizeMatchingRow(r2, gridCols, chartType, scaleW);
      if (sz2) {
        console.log("[SOLAI hybrid] height-row match (h=" + r2.height + ")", "→", sz2);
        return sz2;
      }
    }

    // 3. Новый ряд ниже всех
    var maxRowEnd = 0;
    rows.forEach(function(r3) { maxRowEnd = Math.max(maxRowEnd, r3.rowEnd); });
    console.log("[SOLAI hybrid] new row at", maxRowEnd, "size:", idealW + "×" + idealH);
    return {
      col: 0, row: maxRowEnd,
      colspan: Math.min(idealW, gridCols),
      rowspan: idealH
    };
  }

  function getSheetId() {
    var m = window.location.href.match(/\/sheet\/([A-Za-z0-9_-]+)/);
    return m ? m[1] : null;
  }

  function loadSheetTitle(app, onSuccess) {
    var sheetId = getSheetId();
    if (!sheetId || !app || !app.model || !app.model.enigmaModel) {
      onSuccess(""); return;
    }
    app.model.enigmaModel.getObject(sheetId).then(function(sheetObj) {
      return sheetObj.getProperties();
    }).then(function(props) {
      var title = (props && props.qMetaDef && props.qMetaDef.title) || "";
      onSuccess(title);
    }).catch(function() { onSuccess(""); });
  }

  function isEditMode() {
    try { if (document.querySelector(".qv-sheet-edit-mode")) return true; } catch(e) {}
    try { if (window.location.href.indexOf("/state/edit") !== -1) return true; } catch(e) {}
    return false;
  }

  // ── Очередь создания — предотвращает наложение объектов при быстрых кликах ─
  var _createQueue = Promise.resolve();

  // ── Создание графика ──────────────────────────────────────────────────────
  function doCreate(app, enigmaApp, sheetId, suggestion, onSuccess, onFail) {
    _createQueue = _createQueue.then(function() {
      return new Promise(function(resolve) {
        _doCreateInner(app, enigmaApp, sheetId, suggestion,
          function(id, pos) { onSuccess(id, pos); resolve(); },
          function(e) { onFail(e); resolve(); }
        );
      });
    }).catch(function() {});
  }

  function _doCreateInner(app, enigmaApp, sheetId, suggestion, onSuccess, onFail) {
    // Превращает enigma/Qlik-ошибку (объект {code,parameter,message}) в читаемую строку,
    // иначе "+ e" даёт бесполезное "[object Object]".
    function fmtErr(e) {
      if (e == null) return "unknown";
      if (typeof e === "string") return e;
      var parts = [];
      if (e.message) parts.push(e.message);
      if (e.code !== undefined && e.code !== null) parts.push("code=" + e.code);
      if (e.parameter) parts.push("param=" + e.parameter);
      if (!parts.length) { try { parts.push(JSON.stringify(e)); } catch(_) { parts.push(String(e)); } }
      return parts.join(" ");
    }
    enigmaApp.getObject(sheetId).then(function(sheetObj) {
      sheetObj.getProperties().then(function(sheetProps) {
        if (!Array.isArray(sheetProps.cells)) sheetProps.cells = [];
        var grid = { cols: sheetProps.columns || GRID_COLS, rows: sheetProps.rows || 14 };
        var qlikType = QLIK_TYPE_MAP[suggestion.chartType] || "barchart";
        // Гибридный позиционер: row-layout + аспект-ratio + поиск семьи.
        // Если что-то пойдёт не так — fallback на старый findBestFit.
        var pos = findHybridFit(sheetProps.cells, grid.rows, grid.cols, qlikType)
               || findBestFit  (sheetProps.cells, grid.rows, grid.cols, qlikType);
        if (!pos) { onFail("Нет места на листе"); return; }

        // ── Хелперы для мастер‑элементов (qLibraryId) ────────────────────────
        // Нормализуем элемент массива dimensions/rowFields/colFields:
        // строка → {name}; объект → {libraryId,name}
        function normDimEntry(entry) {
          if (entry && typeof entry === "object") {
            return {
              libraryId: entry.libraryId || entry.qLibraryId || entry.dimensionLibraryId || "",
              name:      entry.name || entry.field || ""
            };
          }
          return { libraryId: "", name: entry || "" };
        }
        function normMeasEntry(entry) {
          if (entry && typeof entry === "object") {
            return {
              libraryId: entry.libraryId || entry.qLibraryId || entry.measureLibraryId || "",
              expr:      entry.expr || entry.measure || "",
              label:     entry.label || entry.measureLabel || ""
            };
          }
          return { libraryId: "", expr: entry || "", label: entry || "" };
        }
        // Собираем dimension‑колонку: если libraryId — qLibraryId + пустой qDef
        function buildDimCol(libId, fieldName, extra) {
          var c = { qNullSuppression: true };
          if (libId) {
            c.qLibraryId = libId;
            c.qDef = { qFieldDefs: [] };
          } else {
            c.qDef = { qFieldDefs: [fieldName], qFieldLabels: [fieldName], qSortCriterias: [{ qSortByLoadOrder: 1 }] };
          }
          if (extra) for (var k in extra) if (extra.hasOwnProperty(k)) c[k] = extra[k];
          return c;
        }
        // Собираем measure‑колонку: если libraryId — qLibraryId + плейсхолдер‑qDef
        // (visualization.create требует qDef.qDef ИЛИ qFieldDefs, иначе ошибка
        // "Devhub.Cols.QdefOrQfielddefs"; реальную привязку к мастеру ставит forceMeasLib).
        // Функция ИТОГОВОЙ строки таблицы: аддитивные меры (Sum/Count) суммируем по строкам
        // (qAggrFunc:"Sum"), иначе авто — у долей/средних/Avg сумма итога некорректна.
        function totalsAggrFunc(expr) {
          return /^\s*(sum|count)\s*\(/i.test(String(expr || "")) ? "Sum" : "Auto";
        }
        function buildMeasCol(libId, expr, label, numFormat) {
          if (libId) return { qLibraryId: libId, qDef: { qDef: "1" } };
          return { qDef: { qDef: expr, qLabel: label || expr, qNumFormat: numFormat, qAggrFunc: totalsAggrFunc(expr) } };
        }

        // ── Фильтр (listbox) — особый путь, без мер ──────────────────────────
        if (qlikType === "listbox") {
          var filterDimLib = suggestion.dimensionLibraryId || "";
          var filterField  = suggestion.dimension || "";
          var filterListDef = filterDimLib
            ? {
                qLibraryId: filterDimLib,
                qDef: {
                  qFieldDefs: [],
                  qSortCriterias: [{ qSortByState: 1, qSortByAscii: 1, qSortByNumeric: 1 }],
                  autoSort: true
                },
                qShowAlternatives: true
              }
            : {
                qDef: {
                  qFieldDefs: [filterField],
                  qSortCriterias: [{ qSortByState: 1, qSortByAscii: 1, qSortByNumeric: 1 }],
                  autoSort: true
                },
                qShowAlternatives: true
              };
          var filterProps = {
            qInfo: { qType: "listbox" },
            qListObjectDef: filterListDef,
            title: suggestion.title || filterField,
            showTitles: true
          };
          enigmaApp.createObject(filterProps).then(function(persistObj) {
            sheetProps.cells.push({ name: persistObj.id, type: "listbox", col: pos.col, row: pos.row, colspan: pos.colspan, rowspan: pos.rowspan });
            sheetObj.setProperties(sheetProps).then(
              function() { onSuccess(persistObj.id, pos); },
              function(e) { onFail("setProperties: " + e); }
            );
          }, function(e) { onFail("createObject listbox: " + e); });
          return;
        }

        // ── Распознаём ссылки на мастер‑элементы ─────────────────────────
        var dimLibId  = suggestion.dimensionLibraryId || "";
        var measLibId = suggestion.measureLibraryId   || "";
        var measLibId2 = suggestion.measureLibraryId2 || "";

        var rawMeasure = suggestion.measure || "";
        // Для piechart/treemap убираем деление — Qlik сам считает доли
        if ((qlikType === "piechart" || qlikType === "treemap") && rawMeasure.indexOf("/") !== -1) {
          rawMeasure = rawMeasure.split("/")[0].trim();
        }
        var meas = safeMeasure(rawMeasure);
        var sortDesc = suggestion.sortDesc !== false; // по умолчанию сортировка по убыванию

        // ── TOP-N через qOtherTotalSpec (Engine-level limiting) ──────────
        var topN = parseInt(suggestion.topN, 10);
        var otherSpec = {};
        if (topN > 0) {
          // Направление отбора N («сверху/снизу» в Qlik): при сортировке по ВОЗРАСТАНИЮ
          // (наименьшие, sortDesc:false) берём «СНИЗУ» (ASCENDING), иначе «СВЕРХУ» (DESCENDING).
          var topAsc = !sortDesc;
          otherSpec = {
            qOtherMode: "OTHER_COUNTED",
            qOtherCounted: { qv: String(topN) },
            qOtherLabel: { qv: "Остальные" },
            qOtherSortMode: topAsc ? "OTHER_SORT_ASCENDING" : "OTHER_SORT_DESCENDING",
            qSuppressOther: true  // скрыть "Остальные" — чистый TOP-N
          };
          console.log("[SOLAI] TOP-" + topN + (topAsc ? " (СНИЗУ/наименьшие)" : " (СВЕРХУ/наибольшие)") + " via qOtherTotalSpec");
        } else {
          console.log("[SOLAI] No topN, creating without limitation");
        }

        // Процентный формат только для barchart/linechart с делением
        // Формат: Число / Простой / 1 000,12
        var NUM_FMT      = { qType: "F", qnDec: 2, qUseThou: 1, qFmt: "# ##0,00",   qDec: ",", qThou: " " };
        // Целое число с разделителями тысяч (для Sum/Count сумм) — "1 234 567"
        var INT_FMT      = { qType: "F", qnDec: 0, qUseThou: 1, qFmt: "# ##0",      qDec: ",", qThou: " " };
        // Авто-формат — Qlik сам решает (млн/млрд/тыс при необходимости)
        var NUM_FMT_AUTO = { qType: "U", qnDec: 1, qUseThou: 1, qFmt: "",            qDec: ",", qThou: " " };
        // Процент: 12,3 % (с пробелом перед знаком)
        var PCT_FMT      = { qType: "F", qnDec: 1, qUseThou: 0, qFmt: "# ##0,0 %",  qDec: ",", qThou: " " };
        // Время: 08:34 (часы:минуты)
        var TIME_FMT     = { qType: "T",  qnDec: 0, qUseThou: 0, qFmt: "hh:mm",                qDec: ":", qThou: "" };
        // Время с секундами: 08:34:25
        var TIME_SEC_FMT = { qType: "T",  qnDec: 0, qUseThou: 0, qFmt: "hh:mm:ss",             qDec: ":", qThou: "" };
        // Дата: 03.11.2025
        var DATE_FMT     = { qType: "D",  qnDec: 0, qUseThou: 0, qFmt: "DD.MM.YYYY",           qDec: ".", qThou: "" };
        // Timestamp: 03.11.2025 08:34:25
        var TS_FMT       = { qType: "TS", qnDec: 0, qUseThou: 0, qFmt: "DD.MM.YYYY hh:mm:ss",  qDec: ":", qThou: "" };
        // Определяет формат по выражению и лейблу
        function pickFmt(expr, label) {
          var l = String(label || "");
          var e = String(expr || "").trim();
          var lL = l.toLowerCase();
          var eL = e.toLowerCase();
          var why = "INT-default"; var fmt = INT_FMT;

          // ─────────────────────────────────────────────────────────────────
          // 0. ВРЕМЯ / ДАТА / TIMESTAMP — приоритет (по выражению и label)
          // ─────────────────────────────────────────────────────────────────
          if (/^\s*timestamp\s*\(/i.test(e) || /\btimestamp\b|\bмомент\b|дата\s+и\s+время/.test(lL)) {
            why = "TS-format"; fmt = TS_FMT;
          }
          else if (/^\s*time\s*\(/i.test(e) || /\b(время|час[аыов]?|вход|выход|приход|уход|начал[оа]|конец)\b|hh:mm/.test(lL)) {
            if (/секунд|:ss/.test(lL + " " + eL)) { why = "TIME-sec"; fmt = TIME_SEC_FMT; }
            else                                  { why = "TIME-hhmm"; fmt = TIME_FMT; }
          }
          else if (/^\s*date\s*\(/i.test(e) || /\b(дата|day\b|date\b|число\s+месяц)\b/.test(lL)) {
            why = "DATE-format"; fmt = DATE_FMT;
          }
          // ─────────────────────────────────────────────────────────────────
          // 1. PCT_FMT — ТОЛЬКО при АБСОЛЮТНО ЯВНОМ проценте в label.
          // ─────────────────────────────────────────────────────────────────
          else if (/[,\s\(]\s*%\s*\)?\s*$/.test(l))                          { why = "PCT-suffix-%";   fmt = PCT_FMT; }
          else if (/^\s*%/.test(l))                                          { why = "PCT-prefix-%";   fmt = PCT_FMT; }
          else if (/\b(доля|процент|share|ratio|percent|удельн)\b/.test(lL)) { why = "PCT-keyword";    fmt = PCT_FMT; }

          // ─────────────────────────────────────────────────────────────────
          // 2. NUM_FMT — десятичные числа для per-unit, средних, аналитики.
          // ─────────────────────────────────────────────────────────────────
          else if (/^(avg|median|stdev|variance)\s*\(/i.test(e))         { why = "NUM-avg-func";   fmt = NUM_FMT; }
          else if (/средн|average|\bavg\b|чек|цен[аы]|per\s|на\s+(одного|клиента|транзакц|пользоват|сотрудн)/.test(lL)) {
            why = "NUM-per-unit-label"; fmt = NUM_FMT;
          }
          else if (/sum\s*\([^)]*\)\s*\/\s*count\s*\(/i.test(eL))        { why = "NUM-sum/count";  fmt = NUM_FMT; }

          // ─────────────────────────────────────────────────────────────────
          // 3. Иначе → INT_FMT (целое с пробелами: 1 234 567).
          // ─────────────────────────────────────────────────────────────────

          console.log("[SOLAI pickFmt]", why, "| expr:", e.substring(0, 80), "| label:", l, "→", fmt.qFmt || ("qType:" + fmt.qType));
          return fmt;
        }
        // piechart и treemap сами умеют показывать доли
        var isRatio = meas.indexOf("/") !== -1;
        var autoPercentTypes = { piechart: 1, treemap: 1 };
        var numFormat = (isRatio && !autoPercentTypes[qlikType]) ? PCT_FMT : NUM_FMT;

        // ── Главное измерение + СОРТИРОВКА ──────────────────────────────
        // Порядок значений измерения:
        //  • временная ось (sortChrono или имя‑дата) → хронологически (по значению).
        //  • есть выражение меры → ПО МЕРЕ: sortDesc=true убыв(-1), false возр(+1).
        //    Работает И для МАСТЕР‑меры — сортируем по эквивалентному выражению meas, а не по ссылке.
        //  • выражения меры нет (только measureLibraryId без формулы) → критерий не задаём,
        //    Qlik сам авто‑сортирует по мере (по убыванию).
        var _dimName = suggestion.dimension || "";
        var _isDateDim = /год|year|месяц|month|квартал|quarter|дата|\bdate\b|период|недел|week|день|\bday\b/i.test(_dimName);
        function buildDimSort() {
          if (suggestion.sortChrono || _isDateDim) return [{ qSortByNumeric: 1, qSortByLoadOrder: 1 }];
          // По мере: инлайн‑выражение meas, иначе ссылка на меру по её МЕТКЕ [Метка]
          // (для МАСТЕР‑мер — measureLabel подтянут из схемы в autoLinkMasters).
          var sortExpr = meas || (suggestion.measureLabel ? ("[" + suggestion.measureLabel + "]") : "");
          if (sortExpr) return [{ qSortByExpression: (sortDesc ? -1 : 1), qExpression: { qv: sortExpr } }];
          return null;
        }
        var _dimSort = buildDimSort();
        console.log("[SOLAI Sort] dim:", _dimName || "(master)", "| chrono:", !!(suggestion.sortChrono || _isDateDim),
                    "| sortDesc:", sortDesc, "→", _dimSort ? JSON.stringify(_dimSort[0]) : "auto(Qlik)");
        var dimDef;
        if (dimLibId) {
          dimDef = {
            qLibraryId: dimLibId,
            qDef: { qFieldDefs: [] },
            qNullSuppression: true,
            qOtherTotalSpec: otherSpec
          };
          if (_dimSort) dimDef.qSortCriterias = _dimSort;
        } else {
          dimDef = {
            qDef: { qFieldDefs: [suggestion.dimension] },
            qNullSuppression: true,
            qOtherTotalSpec: otherSpec
          };
          if (_dimSort) dimDef.qSortCriterias = _dimSort;
        }

        // ── Главная мера с учётом мастер‑меры ───────────────────────────
        var measDef = measLibId
          ? { qLibraryId: measLibId, qDef: { qDef: "1" } }
          : { qDef: { qDef: meas, qLabel: suggestion.measureLabel || meas, qNumFormat: numFormat } };

        // ── Строим cols для visualization.create ──────────────────────────
        var colDefs;

        if (qlikType === "pivot-table") {
          // ── Сводная таблица — через visualization.create (сохраняет структуру свойств) ──
          var pvRowFields = suggestion.rowFields || suggestion.dimensions || [];
          if (!Array.isArray(pvRowFields)) pvRowFields = [pvRowFields];
          var pvColFields = suggestion.colFields || [];
          if (!Array.isArray(pvColFields)) pvColFields = [pvColFields];

          var pvMeasures = suggestion.measures || [];
          if (!Array.isArray(pvMeasures) && suggestion.measure) {
            pvMeasures = [{ expr: suggestion.measure, label: suggestion.measureLabel || suggestion.measure }];
          }

          colDefs = [];
          pvRowFields.forEach(function(f) {
            var n = normDimEntry(f);
            colDefs.push(buildDimCol(n.libraryId, n.name));
          });
          pvColFields.forEach(function(f) {
            var n = normDimEntry(f);
            colDefs.push(buildDimCol(n.libraryId, n.name));
          });
          pvMeasures.forEach(function(m) {
            var n = normMeasEntry(m);
            if (n.libraryId) {
              colDefs.push(buildMeasCol(n.libraryId));
            } else {
              var expr = safeMeasure(n.expr);
              var label = n.label || expr;
              colDefs.push(buildMeasCol("", expr, label, pickFmt(expr, label)));
            }
          });

          suggestion._pvRowCount = pvRowFields.length;
          suggestion._pvTotalDim = suggestion.totalDimension || null;
          console.log("[SOLAI Pivot] rows:", pvRowFields, "cols:", pvColFields, "meas:", pvMeasures.length);

        } else if (qlikType === "table") {
          // ── Таблица — через visualization.create ──
          var rawDims = suggestion.dimensions || suggestion.dimension || "";
          var dimList;
          if (Array.isArray(rawDims)) {
            dimList = rawDims;
          } else if (rawDims && typeof rawDims === "object") {
            dimList = [rawDims];
          } else {
            dimList = String(rawDims).split(",").map(function(f){ return f.trim(); }).filter(Boolean);
          }

          var rawMeasArr = suggestion.measures;
          var measList = [];
          if (Array.isArray(rawMeasArr) && rawMeasArr.length) {
            measList = rawMeasArr;
          } else if (suggestion.measure || measLibId) {
            measList = [{ libraryId: measLibId, expr: suggestion.measure, label: suggestion.measureLabel || suggestion.measure }];
          }

          colDefs = [];
          dimList.forEach(function(f) {
            var n = normDimEntry(f);
            colDefs.push(buildDimCol(n.libraryId, n.name));
          });
          measList.forEach(function(m) {
            var n = normMeasEntry(m);
            if (n.libraryId) {
              colDefs.push(buildMeasCol(n.libraryId));
            } else {
              var expr = safeMeasure(n.expr);
              var label = n.label || expr;
              colDefs.push(buildMeasCol("", expr, label, pickFmt(expr, label)));
            }
          });

          console.log("[SOLAI Table] dims:", JSON.stringify(dimList), "meas:", JSON.stringify(measList));

        } else if (qlikType === "scatterplot") {
          // Скаттер ожидает 2 разные меры (X и Y). При libraryId — одна и та же дважды.
          var scDim = dimLibId
            ? { qLibraryId: dimLibId, qDef: { qFieldDefs: [] }, qNullSuppression: true }
            : { qDef: { qFieldDefs: [suggestion.dimension] }, qNullSuppression: true };
          var scMeasX = measLibId
            ? { qLibraryId: measLibId, qDef: { qDef: "1" } }
            : { qDef: { qDef: meas, qLabel: "X", qNumFormat: NUM_FMT } };
          var scMeasY = measLibId2
            ? { qLibraryId: measLibId2, qDef: { qDef: "1" } }
            : (measLibId ? { qLibraryId: measLibId, qDef: { qDef: "1" } }
                         : { qDef: { qDef: meas, qLabel: "Y", qNumFormat: NUM_FMT } });
          colDefs = [scDim, scMeasX, scMeasY];
        } else if (qlikType === "gauge" || qlikType === "kpi") {
          var kpiLabel = suggestion.measureLabel || meas;
          colDefs = [ measLibId
            ? { qLibraryId: measLibId, qDef: { qDef: "1" } }
            : { qDef: { qDef: meas, qLabel: kpiLabel, qNumFormat: pickFmt(meas, kpiLabel) } }
          ];
          if (qlikType === "kpi" && (suggestion.measure2 || measLibId2)) {
            if (measLibId2) {
              colDefs.push({ qLibraryId: measLibId2, qDef: { qDef: "1" } });
            } else {
              var meas2 = safeMeasure(suggestion.measure2);
              var kpiLabel2 = suggestion.measureLabel2 || meas2;
              colDefs.push({ qDef: { qDef: meas2, qLabel: kpiLabel2, qNumFormat: pickFmt(meas2, kpiLabel2) } });
            }
          }
        } else if (qlikType === "combochart") {
          var comboDim;
          if (dimLibId) {
            comboDim = {
              qLibraryId: dimLibId,
              qDef: { qFieldDefs: [] },
              qNullSuppression: true,
              qOtherTotalSpec: otherSpec
            };
          } else {
            comboDim = {
              qDef: { qFieldDefs: [suggestion.dimension] },
              qNullSuppression: true,
              qOtherTotalSpec: otherSpec,
              qSortCriterias: (sortDesc && !measLibId)
                ? [{ qSortByExpression: -1, qExpression: { qv: meas } }]
                : [{ qSortByLoadOrder: 1 }]
            };
          }
          colDefs = [comboDim, measDef];
          if (suggestion.measure2 || measLibId2) {
            if (measLibId2) {
              colDefs.push({ qLibraryId: measLibId2, qDef: { qDef: "1" } });
            } else {
              var comboMeas2 = safeMeasure(suggestion.measure2);
              var comboLabel2 = suggestion.measureLabel2 || comboMeas2;
              colDefs.push({ qDef: { qDef: comboMeas2, qLabel: comboLabel2, qNumFormat: pickFmt(comboMeas2, comboLabel2) } });
            }
          }
        } else {
          colDefs = [dimDef, measDef];

          // ── Второе измерение для linechart/barchart (серии/группы) ─────
          // Используется для YoY тренда (Группа=Месяц, Линия=Год) или
          // сравнения категорий по периодам. Строим dim2 после основного dim.
          var dimLibId2 = suggestion.dimensionLibraryId2 || "";
          if (suggestion.dimension2 || dimLibId2) {
            var dim2Def;
            if (dimLibId2) {
              dim2Def = {
                qLibraryId: dimLibId2,
                qDef: { qFieldDefs: [] },
                qNullSuppression: true
              };
            } else {
              dim2Def = {
                qDef: { qFieldDefs: [suggestion.dimension2] },
                qNullSuppression: true,
                qSortCriterias: [{ qSortByLoadOrder: 1 }]
              };
            }
            // ВАЖНО: второе измерение ставим МЕЖДУ первым dim и мерой,
            // чтобы Qlik понял его как «вторая категория» (color/series),
            // а не как дополнительную меру.
            colDefs = [dimDef, dim2Def, measDef];
            console.log("[SOLAI] linechart 2-dim:", suggestion.dimension, "+", suggestion.dimension2 || dimLibId2);
          }
        }

        // ── Единый путь создания для всех типов ──────────────────────────
        app.visualization.create(
          qlikType,
          colDefs,
          { showTitles: true, title: suggestion.title || "" }
        ).then(function(vis) {
          enigmaApp.getObject(vis.id).then(function(sessionObj) {
            sessionObj.getProperties().then(function(sessionProps) {
              var pp = JSON.parse(JSON.stringify(sessionProps));
              delete pp.qInfo.qId;
              pp.qInfo.qType = qlikType;

              // ── Визуальные настройки ────────────────────────────────────
              // 1. Метки значений — всегда включены
              if (!pp.dataPoint) pp.dataPoint = {};
              pp.dataPoint.showLabels = true;
              // Для линейных и комбо-графиков — включаем сами точки на линии,
              // иначе метки негде рисовать (на самой линии Qlik их не показывает)
              if (qlikType === "linechart" || qlikType === "combochart") {
                pp.dataPoint.show = true;
              }

              // 2. Без сетки
              if (!pp.gridLine) pp.gridLine = {};
              pp.gridLine.auto = false;
              pp.gridLine.spacing = 0;

              // 3. Цвета — авто-режим (безопасно для всех типов)
              if (!pp.color) pp.color = {};
              pp.color.auto = true;

              // 3a. Цветовое выражение (по знаку меры, по году, etc.)
              // Если AI задал colorExpression — настраиваем ПОЛНЫЙ блок color.
              // ВАЖНО: проверяем что выражение реально валидное (содержит # или HEX),
              // иначе оставляем дефолтный цвет темы Qlik.
              var hasValidColorExpr = isColorExpr(suggestion.colorExpression);
              if (hasValidColorExpr) {
                pp.color = {
                  auto: false,
                  mode: "byExpression",
                  // Отключаем все конфликтующие режимы
                  useExpression: true,
                  expressionIsColor: true,           // ВЫРАЖЕНИЕ ВОЗВРАЩАЕТ ЦВЕТ
                  useBaseColors: "off",
                  useDimColVal: false,
                  useDimensionGradient: false,
                  useMeasureGradient: false,
                  persistent: false,
                  // Цвет-выражение (рендерится через qAttributeExpressions ниже)
                  colorExpression: suggestion.colorExpression,
                  expressionLabel: suggestion.colorLabel || "Цветовое выражение",
                  // measureScheme НЕ задаём: это строковый enum (sg/dg/…) для числового
                  // byMeasure, а не место для цвет-выражения — color-строка тут обнуляет блок.
                  // Палитра не используется при byExpression
                  paletteColor: { index: -1 }
                };
                console.log("[SOLAI] colorExpression configured:", suggestion.colorExpression);
              }

              // 3b. Ориентация barchart/combochart — вертикальная по умолчанию.
              // Разные версии Qlik используют разные ключи, поэтому
              // проставляем по всем известным путям + qHyperCubeDef.
              if (qlikType === "barchart" || qlikType === "combochart") {
                var requestedOrient = suggestion.orientation;
                var finalOrient;
                if (requestedOrient === "horizontal" || requestedOrient === "vertical") {
                  finalOrient = requestedOrient;
                } else {
                  finalOrient = "vertical"; // default — столбцы вверх
                }

                // Multi-path: разные версии Qlik читают из разных свойств
                pp.orientation = finalOrient;
                pp.barOrientation = finalOrient;
                if (!pp.appearance) pp.appearance = {};
                pp.appearance.orientation = finalOrient;
                if (!pp.style) pp.style = {};
                pp.style.orientation = finalOrient;
                // Direction для горизонтальных vs вертикальных у некоторых сборок
                pp.gridLine = pp.gridLine || {};
                pp.gridLine.auto = false;

                console.log("[SOLAI] orientation set (multi-path):", finalOrient,
                            "→ pp.orientation:", pp.orientation,
                            "| pp.barOrientation:", pp.barOrientation,
                            "| pp.appearance.orientation:", pp.appearance && pp.appearance.orientation);
              }

              // 4. Убедиться что cId есть + скрыть пустые значения по умолчанию
              if (pp.qHyperCubeDef) {
                pp.qHyperCubeDef.qSuppressMissing = true;
                pp.qHyperCubeDef.qSuppressZero = true;
                (pp.qHyperCubeDef.qDimensions || []).forEach(function(d) {
                  if (d.qDef && !d.qDef.cId) d.qDef.cId = qlikCid();
                  d.qNullSuppression = true;
                });
                (pp.qHyperCubeDef.qMeasures || []).forEach(function(m) {
                  if (m.qDef && !m.qDef.cId) m.qDef.cId = qlikCid();
                });

                // 4b. СТРАХОВКА: если suggestion указал libraryId, форсируем
                // ссылку на мастер‑элемент. visualization.create может проигнорировать
                // qLibraryId в colDefs — поэтому переписываем после получения свойств.
                var hcDims = pp.qHyperCubeDef.qDimensions || [];
                var hcMeas = pp.qHyperCubeDef.qMeasures || [];

                // Полностью переписываем qDef: оставляем только cId (как делает Qlik UI
                // при ручной привязке к мастеру). Если qNumFormat/qLabel/qDef.qDef остаются —
                // Qlik UI отображает «Добавить новый» в поле «Основной элемент», игнорируя qLibraryId.
                function forceDimLib(idx, libId) {
                  if (!libId || !hcDims[idx]) return;
                  var oldCid = (hcDims[idx].qDef && hcDims[idx].qDef.cId) || qlikCid();
                  hcDims[idx].qLibraryId = libId;
                  hcDims[idx].qDef = { qFieldDefs: [], qFieldLabels: [], cId: oldCid };
                  hcDims[idx].qNullSuppression = true;
                  // qOtherTotalSpec (TOP‑N) чистим — мастер сам его задаёт.
                  // qSortCriterias СОХРАНЯЕМ: это сортировка графика по мере/хронологии (_dimSort),
                  // она корректно переопределяет сортировку мастер‑измерения на уровне колонки.
                  delete hcDims[idx].qOtherTotalSpec;
                }
                function forceMeasLib(idx, libId) {
                  if (!libId || !hcMeas[idx]) return;
                  var oldCid = (hcMeas[idx].qDef && hcMeas[idx].qDef.cId) || qlikCid();
                  hcMeas[idx].qLibraryId = libId;
                  hcMeas[idx].qDef = { cId: oldCid };
                  // Чистим возможные локальные оверрайды
                  delete hcMeas[idx].qSortBy;
                }

                // Одно измерение (bar/line/pie/treemap/scatter/combo/gauge)
                if (suggestion.dimensionLibraryId) forceDimLib(0, suggestion.dimensionLibraryId);
                // Одна мера (всё кроме kpi/combo второй меры)
                if (suggestion.measureLibraryId) forceMeasLib(0, suggestion.measureLibraryId);
                // Вторая мера (kpi/combochart)
                if (suggestion.measureLibraryId2) forceMeasLib(1, suggestion.measureLibraryId2);

                // Table/pivot — мульти‑колонки. Раскладываем по индексам.
                if (qlikType === "table" || qlikType === "pivot-table") {
                  var tDims = (qlikType === "pivot-table")
                    ? [].concat(suggestion.rowFields || [], suggestion.colFields || [])
                    : (suggestion.dimensions || (suggestion.dimension ? [suggestion.dimension] : []));
                  var tMeas = suggestion.measures || (suggestion.measure ? [{ libraryId: suggestion.measureLibraryId, expr: suggestion.measure }] : []);
                  tDims.forEach(function(d, i) {
                    if (d && typeof d === "object" && (d.libraryId || d.qLibraryId)) {
                      forceDimLib(i, d.libraryId || d.qLibraryId);
                    }
                  });
                  tMeas.forEach(function(m, i) {
                    if (m && typeof m === "object" && (m.libraryId || m.qLibraryId)) {
                      forceMeasLib(i, m.libraryId || m.qLibraryId);
                    }
                  });
                }

                console.log("[SOLAI LibraryId] dimLib:", suggestion.dimensionLibraryId,
                            "measLib:", suggestion.measureLibraryId,
                            "measLib2:", suggestion.measureLibraryId2,
                            "→ hcDims:", hcDims.map(function(d){return d.qLibraryId||"-";}).join(","),
                            "hcMeas:", hcMeas.map(function(m){return m.qLibraryId||"-";}).join(","));
              }

              // 5. Для pivot-table: настройка строк/столбцов
              if (qlikType === "pivot-table" && pp.qHyperCubeDef) {
                pp.qHyperCubeDef.qNoOfLeftDims = suggestion._pvRowCount || 1;
                pp.qHyperCubeDef.qAlwaysFullyExpanded = true;
                pp.qHyperCubeDef.qIndentMode = false;

                if (suggestion._pvTotalDim) {
                  (pp.qHyperCubeDef.qDimensions || []).forEach(function(d) {
                    var fname = (d.qDef && d.qDef.qFieldDefs && d.qDef.qFieldDefs[0]) || "";
                    if (fname === suggestion._pvTotalDim) {
                      d.qOtherTotalSpec = { qOtherMode: "OTHER_OFF", qTotalMode: "TOTAL_EXPR" };
                      d.qShowTotal = true;
                      d.qTotalLabel = { qv: "Итого" };
                    }
                  });
                }
              }

              // 6. Для combochart: вторая мера как линия
              if (qlikType === "combochart" && suggestion.measure2) {
                // visualization.create уже добавила меры,
                // нужно настроить представление второй меры как линию
                var hcMeas = pp.qHyperCubeDef && pp.qHyperCubeDef.qMeasures;
                if (hcMeas && hcMeas.length >= 2) {
                  // Qlik combochart: each measure has barGrouping.grouping
                  // "stack"/"group" for bars, type "line" for line
                  if (!hcMeas[1].qDef) hcMeas[1].qDef = {};
                  // Set second measure rendering as line
                }
              }

              enigmaApp.createObject(pp).then(function(persistObj) {
                console.log("[SOLAI create] object created:", persistObj.id, "type:", qlikType);
                try { enigmaApp.destroyObject(vis.id); } catch(e) {}
                sheetProps.cells.push({ name: persistObj.id, type: qlikType, col: pos.col, row: pos.row, colspan: pos.colspan, rowspan: pos.rowspan });

                // Если был задан colorExpression — принудительно перепрогоняем
                // setProperties на свежесозданном объекте. Qlik кэширует начальный
                // color-стейт; без повторного setProperties галочка "expressionIsColor"
                // визуально не активируется и цвета не применяются.
                var finalize = function() {
                  sheetObj.setProperties(sheetProps).then(
                    function() { onSuccess(persistObj.id, pos); },
                    function(e) { console.error("[SOLAI create] setProperties FAILED:", e); onFail("setProperties: " + fmtErr(e)); }
                  );
                };

                // Двойной toggle нужен ТОЛЬКО когда реально был установлен colorExpression
                if (isColorExpr(suggestion.colorExpression)) {
                  // НАСТОЯЩИЙ TOGGLE — двухэтапная имитация клика галочки через API.
                  applyColorToggle(persistObj, suggestion.colorExpression, function() {
                    // Дополнительно: пытаемся кликнуть галочку в DOM (физический клик)
                    tryDomToggleColorCheckbox(persistObj.id);
                    finalize();
                  });
                } else {
                  finalize();
                }
              }, function(e) { console.error("[SOLAI create] createObject FAILED:", e); onFail("createObject: " + fmtErr(e)); });
            }, function(e) { console.error("[SOLAI create] getProps FAILED:", e); onFail("getProps: " + fmtErr(e)); });
          }, function(e) { console.error("[SOLAI create] getObject(vis) FAILED:", e); onFail("getObject: " + fmtErr(e)); });
        }, function(e) { console.error("[SOLAI create] vis.create FAILED:", e); onFail("vis.create: " + fmtErr(e)); });
      }).catch(function(e) { console.error("[SOLAI create] build/sheetProps FAILED:", e); onFail("build: " + fmtErr(e)); });
    }, function(e) { console.error("[SOLAI create] getSheet FAILED:", e); onFail("getSheet: " + fmtErr(e)); });
  }

  // ── DOM-СИМУЛЯЦИЯ КЛИКА ПО ГАЛОЧКЕ «Выражение является цветовым кодом» ──
  // Если API-подход не активирует цвета, ищем галочку в DOM и кликаем по ней
  // программно — точно как руками. Сработает, если панель свойств открыта.
  function tryDomToggleColorCheckbox(objectId) {
    setTimeout(function() {
      var keywords = [
        "цветовым кодом",
        "цветовым код",
        "выражение является цвет",
        "expression is a color",
        "expression is color"
      ];
      var allLabels = document.querySelectorAll(
        "label, .lui-switch__label, [class*='switch'] [class*='label'], " +
        "[class*='Switch'] [class*='label'], [tid*='color'], [data-testid*='color']"
      );
      var foundEl = null;
      var foundKey = "";

      for (var i = 0; i < allLabels.length && !foundEl; i++) {
        var text = ((allLabels[i].textContent || "") + "").toLowerCase().trim();
        if (!text) continue;
        for (var k = 0; k < keywords.length; k++) {
          if (text.indexOf(keywords[k]) !== -1) {
            foundEl = allLabels[i];
            foundKey = keywords[k];
            break;
          }
        }
      }

      if (!foundEl) {
        console.log("[SOLAI color DOM] checkbox not found — панель свойств закрыта или текст другой");
        return;
      }

      // Найти ассоциированный input checkbox / switch
      var switchContainer = foundEl.closest("[class*='switch'], [class*='Switch'], [class*='toggle'], [class*='Toggle']");
      var checkbox = (switchContainer && switchContainer.querySelector("input[type='checkbox']"))
                  || foundEl.querySelector("input[type='checkbox']")
                  || (foundEl.parentElement && foundEl.parentElement.querySelector("input[type='checkbox']"));

      // Кликабельный элемент = input или сам label
      var clickTarget = checkbox || foundEl;
      if (!clickTarget) {
        console.log("[SOLAI color DOM] target click element not found");
        return;
      }

      console.log("[SOLAI color DOM] found checkbox via keyword '" + foundKey + "', toggling...");
      try {
        clickTarget.click();
        setTimeout(function() {
          clickTarget.click();
          console.log("[SOLAI color DOM] toggled OFF→ON (mimicked manual user click)");
        }, 150);
      } catch(e) {
        console.warn("[SOLAI color DOM] click failed:", e);
      }
    }, 800); // ждём, пока Qlik отрендерит панель свойств после создания
  }

  // ── НАСТОЯЩИЙ TOGGLE галочки «Выражение является цветовым кодом» ─────────
  // Имитирует ручной клик пользователя — это единственный способ заставить
  // Qlik применить colorExpression без повторного клика в UI.
  //
  // Sequence:
  //   1. setProperties с expressionIsColor: FALSE + colorExpression
  //   2. getLayout — заставляет Qlik закоммитить промежуточное состояние
  //   3. setTimeout 250ms — пауза для обработки в Qlik
  //   4. setProperties с expressionIsColor: TRUE (полный блок color)
  //   5. getLayout — финальный рендер с применёнными цветами
  function applyColorToggle(obj, colorExpr, done) {
    function buildColorBlock(expressionIsColor) {
      return {
        auto: false,
        mode: "byExpression",
        paletteColor: { index: -1 },
        useDimColVal: false,
        useBaseColors: "off",
        useDimensionGradient: false,
        useMeasureGradient: false,
        expressionIsColor: expressionIsColor,
        expressionLabel: "",
        colorExpression: colorExpr
        // measureScheme НЕ задаём — enum для числового byMeasure, цвет-строка тут обнуляет блок.
      };
    }
    function buildMeasureColoring() {
      return {
        baseColor: null,
        gradient: null,
        byExpression: { expression: colorExpr, label: "" }
      };
    }
    // qAttributeExpressions — "старый" путь раскраски через атрибуты колонок.
    // Qlik рендерит цвета прямо из этого, БЕЗ галочки expressionIsColor.
    // Это самый надёжный способ — работает в любой версии Qlik.
    // Два атрибута цвета на КАЖДУЮ колонку:
    //  • colorByExpression  — цвет точек данных в графиках (бары/линии/пай);
    //  • cellBackgroundColor — ФОН ЯЧЕЙКИ в таблице (и для меры, и для измерения).
    // Одно и то же выражение рендерится и как цвет графика, и как заливка ячейки таблицы.
    function buildColorAttrExprs() {
      var fmt = { qType: "U", qnDec: 10, qUseThou: 0 };
      return [
        { qExpression: colorExpr, qLibraryId: "", qAttribute: true, qNumFormat: fmt, id: "colorByExpression" },
        { qExpression: colorExpr, qLibraryId: "", qAttribute: true, qNumFormat: fmt, id: "cellBackgroundColor" }
      ];
    }

    // Хелпер: применяет qAttributeExpressions ко ВСЕМ измерениям + мерам.
    // Это надёжный путь раскраски — Qlik рендерит цвета напрямую из атрибутов
    // колонок, без зависимости от галочки expressionIsColor.
    function applyAttrExprToAll(props) {
      if (!props.qHyperCubeDef) return;
      (props.qHyperCubeDef.qDimensions || []).forEach(function(d) {
        d.qAttributeExpressions = buildColorAttrExprs();
      });
      (props.qHyperCubeDef.qMeasures || []).forEach(function(m) {
        m.qAttributeExpressions = buildColorAttrExprs();
      });
    }

    // ── Фаза 1: expressionIsColor = false ──────────────────────────────────
    obj.getProperties().then(function(p1) {
      p1.color = buildColorBlock(false);
      if (p1.qHyperCubeDef && p1.qHyperCubeDef.qMeasures && p1.qHyperCubeDef.qMeasures[0]) {
        p1.qHyperCubeDef.qMeasures[0].coloring = buildMeasureColoring();
      }
      applyAttrExprToAll(p1);  // ← qAttributeExpressions на dimensions+measures
      obj.setProperties(p1).then(function() {
        // Заставляем Qlik зафиксировать состояние
        obj.getLayout().then(function() {
          console.log("[SOLAI color] phase 1: expressionIsColor=FALSE + attrExpr committed");

          // ── Пауза для Qlik ─────────────────────────────────────────────
          setTimeout(function() {

            // ── Фаза 2: expressionIsColor = true ───────────────────────────
            obj.getProperties().then(function(p2) {
              p2.color = buildColorBlock(true);
              if (p2.qHyperCubeDef && p2.qHyperCubeDef.qMeasures && p2.qHyperCubeDef.qMeasures[0]) {
                p2.qHyperCubeDef.qMeasures[0].coloring = buildMeasureColoring();
              }
              applyAttrExprToAll(p2);  // ← qAttributeExpressions заново
              obj.setProperties(p2).then(function() {
                obj.getLayout().then(function() {
                  console.log("[SOLAI color] phase 2: expressionIsColor=TRUE + attrExpr applied → DONE");
                  done();
                }, function() { done(); });
              }, function(e) {
                console.warn("[SOLAI color] phase 2 setProperties failed:", e);
                done();
              });
            }, function() { done(); });

          }, 250);
        }, function() {
          // Если getLayout упал — пробуем сразу фазу 2 без паузы
          console.warn("[SOLAI color] phase 1 getLayout failed, going to phase 2 immediately");
          setTimeout(function() {
            obj.getProperties().then(function(p2) {
              p2.color = buildColorBlock(true);
              obj.setProperties(p2).then(function() {
                obj.getLayout().then(done, done);
              }, done);
            }, done);
          }, 100);
        });
      }, function(e) {
        console.warn("[SOLAI color] phase 1 setProperties failed:", e);
        done();
      });
    }, function() { done(); });
  }

  // ── Модификация существующего объекта ────────────────────────────────────
  function doModify(enigmaApp, modSpec, onSuccess, onFail) {
    var objectId = modSpec.objectId;
    if (!objectId) { onFail("objectId не указан"); return; }

    enigmaApp.getObject(objectId).then(function(obj) {
      obj.getProperties().then(function(props) {
        var hc = props.qHyperCubeDef;
        if (!hc) { onFail("Объект не содержит HyperCube"); return; }

        var NUM_FMT      = { qType: "F", qnDec: 2, qUseThou: 1, qFmt: "# ##0,00",   qDec: ",", qThou: " " };
        // Целое число с разделителями тысяч (для Sum/Count сумм) — "1 234 567"
        var INT_FMT      = { qType: "F", qnDec: 0, qUseThou: 1, qFmt: "# ##0",      qDec: ",", qThou: " " };
        // Авто-формат — Qlik сам решает (млн/млрд/тыс при необходимости)
        var NUM_FMT_AUTO = { qType: "U", qnDec: 1, qUseThou: 1, qFmt: "",            qDec: ",", qThou: " " };
        // Процент: 12,3 % (с пробелом перед знаком)
        var PCT_FMT      = { qType: "F", qnDec: 1, qUseThou: 0, qFmt: "# ##0,0 %",  qDec: ",", qThou: " " };
        // Время: 08:34 (часы:минуты)
        var TIME_FMT     = { qType: "T",  qnDec: 0, qUseThou: 0, qFmt: "hh:mm",                qDec: ":", qThou: "" };
        // Время с секундами: 08:34:25
        var TIME_SEC_FMT = { qType: "T",  qnDec: 0, qUseThou: 0, qFmt: "hh:mm:ss",             qDec: ":", qThou: "" };
        // Дата: 03.11.2025
        var DATE_FMT     = { qType: "D",  qnDec: 0, qUseThou: 0, qFmt: "DD.MM.YYYY",           qDec: ".", qThou: "" };
        // Timestamp: 03.11.2025 08:34:25
        var TS_FMT       = { qType: "TS", qnDec: 0, qUseThou: 0, qFmt: "DD.MM.YYYY hh:mm:ss",  qDec: ":", qThou: "" };
        function pickFmt(expr, label) {
          var l = String(label || "");
          var e = String(expr || "").trim();
          var lL = l.toLowerCase();
          var eL = e.toLowerCase();
          var why = "INT-default"; var fmt = INT_FMT;

          // ─────────────────────────────────────────────────────────────────
          // 0. ВРЕМЯ / ДАТА / TIMESTAMP — приоритет (по выражению и label)
          // ─────────────────────────────────────────────────────────────────
          if (/^\s*timestamp\s*\(/i.test(e) || /\btimestamp\b|\bмомент\b|дата\s+и\s+время/.test(lL)) {
            why = "TS-format"; fmt = TS_FMT;
          }
          else if (/^\s*time\s*\(/i.test(e) || /\b(время|час[аыов]?|вход|выход|приход|уход|начал[оа]|конец)\b|hh:mm/.test(lL)) {
            if (/секунд|:ss/.test(lL + " " + eL)) { why = "TIME-sec"; fmt = TIME_SEC_FMT; }
            else                                  { why = "TIME-hhmm"; fmt = TIME_FMT; }
          }
          else if (/^\s*date\s*\(/i.test(e) || /\b(дата|day\b|date\b|число\s+месяц)\b/.test(lL)) {
            why = "DATE-format"; fmt = DATE_FMT;
          }
          // ─────────────────────────────────────────────────────────────────
          // 1. PCT_FMT — ТОЛЬКО при АБСОЛЮТНО ЯВНОМ проценте в label.
          // ─────────────────────────────────────────────────────────────────
          else if (/[,\s\(]\s*%\s*\)?\s*$/.test(l))                          { why = "PCT-suffix-%";   fmt = PCT_FMT; }
          else if (/^\s*%/.test(l))                                          { why = "PCT-prefix-%";   fmt = PCT_FMT; }
          else if (/\b(доля|процент|share|ratio|percent|удельн)\b/.test(lL)) { why = "PCT-keyword";    fmt = PCT_FMT; }

          // ─────────────────────────────────────────────────────────────────
          // 2. NUM_FMT — десятичные числа для per-unit, средних, аналитики.
          // ─────────────────────────────────────────────────────────────────
          else if (/^(avg|median|stdev|variance)\s*\(/i.test(e))         { why = "NUM-avg-func";   fmt = NUM_FMT; }
          else if (/средн|average|\bavg\b|чек|цен[аы]|per\s|на\s+(одного|клиента|транзакц|пользоват|сотрудн)/.test(lL)) {
            why = "NUM-per-unit-label"; fmt = NUM_FMT;
          }
          else if (/sum\s*\([^)]*\)\s*\/\s*count\s*\(/i.test(eL))        { why = "NUM-sum/count";  fmt = NUM_FMT; }

          // ─────────────────────────────────────────────────────────────────
          // 3. Иначе → INT_FMT (целое с пробелами: 1 234 567).
          // ─────────────────────────────────────────────────────────────────

          console.log("[SOLAI pickFmt]", why, "| expr:", e.substring(0, 80), "| label:", l, "→", fmt.qFmt || ("qType:" + fmt.qType));
          return fmt;
        }

        // Удаление измерений
        if (modSpec.removeDimensions && modSpec.removeDimensions.length) {
          modSpec.removeDimensions.forEach(function(fieldName) {
            var norm = fieldName.replace(/[\[\]]/g, "").toLowerCase();
            hc.qDimensions = (hc.qDimensions || []).filter(function(d) {
              var f = ((d.qDef && d.qDef.qFieldDefs && d.qDef.qFieldDefs[0]) || "").replace(/[\[\]]/g, "").toLowerCase();
              return f !== norm;
            });
          });
        }

        // Удаление мер
        if (modSpec.removeMeasures && modSpec.removeMeasures.length) {
          modSpec.removeMeasures.forEach(function(exprToRemove) {
            var norm = exprToRemove.replace(/\s+/g, "").toLowerCase();
            hc.qMeasures = (hc.qMeasures || []).filter(function(m) {
              var mExpr = ((m.qDef && m.qDef.qDef) || "").replace(/\s+/g, "").toLowerCase();
              return mExpr !== norm;
            });
          });
        }

        // Изменение мер (замена формулы)
        if (modSpec.changeMeasures && modSpec.changeMeasures.length) {
          modSpec.changeMeasures.forEach(function(change) {
            var oldNorm = (change.old || "").replace(/\s+/g, "").toLowerCase();
            (hc.qMeasures || []).forEach(function(m) {
              var mExpr = ((m.qDef && m.qDef.qDef) || "").replace(/\s+/g, "").toLowerCase();
              if (mExpr === oldNorm) {
                m.qDef.qDef = safeMeasure(change["new"] || change.old);
                if (change.label) m.qDef.qLabel = change.label;
                m.qDef.qNumFormat = pickFmt(change["new"] || "", change.label || "");
              }
            });
          });
        }

        // Добавление измерений
        if (modSpec.addDimensions && modSpec.addDimensions.length) {
          if (!hc.qDimensions) hc.qDimensions = [];
          modSpec.addDimensions.forEach(function(fieldName) {
            hc.qDimensions.push({
              qDef: {
                qFieldDefs: [fieldName],
                qFieldLabels: [fieldName],
                cId: qlikCid(),
                qSortCriterias: [{ qSortByLoadOrder: 1 }]
              },
              qNullSuppression: true
            });
          });
        }

        // Добавление мер
        if (modSpec.addMeasures && modSpec.addMeasures.length) {
          if (!hc.qMeasures) hc.qMeasures = [];
          modSpec.addMeasures.forEach(function(m) {
            var expr = safeMeasure(typeof m === "string" ? m : (m.expr || ""));
            var label = typeof m === "string" ? m : (m.label || expr);
            hc.qMeasures.push({
              qDef: {
                qDef: expr,
                qLabel: label,
                cId: qlikCid(),
                qNumFormat: pickFmt(expr, label)
              }
            });
          });
        }

        // Изменение заголовка
        if (modSpec.title) {
          props.title = modSpec.title;
        }

        // ── Изменение TOP-N (количество отображаемых элементов) ──────────
        // setTopN: число → выставить, null/0 → снять ограничение
        if (modSpec.setTopN !== undefined && modSpec.setTopN !== null) {
          var newTopN = parseInt(modSpec.setTopN, 10);
          // «СНИЗУ/наименьшие» — если этой же модификацией просят возрастающую сортировку,
          // либо явно topBottom:"bottom". Иначе «СВЕРХУ/наибольшие» (как раньше).
          var mTopAsc = (modSpec.setSortDesc === false || modSpec.setSortAutoDirection === "asc" || modSpec.topBottom === "bottom");
          (hc.qDimensions || []).forEach(function(d, i) {
            if (i !== 0) return; // топ-N применяется к ПЕРВОМУ измерению
            if (newTopN > 0) {
              d.qOtherTotalSpec = {
                qOtherMode: "OTHER_COUNTED",
                qOtherCounted: { qv: String(newTopN) },
                qOtherLabel: { qv: "Остальные" },
                qOtherSortMode: mTopAsc ? "OTHER_SORT_ASCENDING" : "OTHER_SORT_DESCENDING",
                qSuppressOther: true
              };
              console.log("[SOLAI Modify] setTopN:", newTopN, mTopAsc ? "(СНИЗУ/наименьшие)" : "(СВЕРХУ/наибольшие)");
            } else {
              // 0 или null → снять топ-N
              d.qOtherTotalSpec = { qOtherMode: "OTHER_OFF" };
              console.log("[SOLAI Modify] cleared topN");
            }
          });
        }

        // ── Изменение направления сортировки ─────────────────────────────
        // setSortDesc: true → по убыванию меры; false → по загрузке (хронологически)
        if (modSpec.setSortDesc !== undefined && modSpec.setSortDesc !== null) {
          var sortByMeas = (hc.qMeasures && hc.qMeasures[0] && hc.qMeasures[0].qDef && hc.qMeasures[0].qDef.qDef) || "";
          (hc.qDimensions || []).forEach(function(d, i) {
            if (i !== 0) return;
            if (modSpec.setSortDesc && sortByMeas) {
              d.qSortCriterias = [{ qSortByExpression: -1, qExpression: { qv: sortByMeas } }];
              console.log("[SOLAI Modify] sort desc by measure");
            } else {
              d.qSortCriterias = [{ qSortByLoadOrder: 1 }];
              console.log("[SOLAI Modify] sort by load order");
            }
          });
        }

        // ── УМНАЯ АВТО-СОРТИРОВКА: расширение само решает что логичнее ──────
        // setSortAuto: true — анализирует структуру объекта:
        //  • Временное измерение (Год/Месяц/Дата) → хронологически (load order asc)
        //  • Одна мера + категория → по мере (desc)
        //  • Несколько мер → по первой мере (desc)
        //  • Только измерения без мер → по алфавиту (ascii asc)
        if (modSpec.setSortAuto) {
          var firstDim = hc.qDimensions && hc.qDimensions[0];
          var firstMeas = hc.qMeasures && hc.qMeasures[0];

          if (firstDim) {
            var firstField = (firstDim.qDef && firstDim.qDef.qFieldDefs && firstDim.qDef.qFieldDefs[0]) || "";
            var firstFieldL = firstField.toLowerCase();
            var isTimeField = /\b(год|year|месяц|month|дата|date|период|день|day|week|неделя|quarter|квартал|месяцгод|yearmonth)\b/.test(firstFieldL);

            var direction = (modSpec.setSortAutoDirection === "asc") ? 1 : -1;

            if (isTimeField) {
              // Хронологически — по порядку загрузки, возрастающе
              firstDim.qSortCriterias = [{ qSortByLoadOrder: 1 }];
              console.log("[SOLAI Modify] setSortAuto → time → load order asc");
            } else if (firstMeas) {
              // Категория + мера → по мере
              var measExpr = (firstMeas.qDef && firstMeas.qDef.qDef) || "";
              if (measExpr) {
                firstDim.qSortCriterias = [{ qSortByExpression: direction, qExpression: { qv: measExpr } }];
                console.log("[SOLAI Modify] setSortAuto → measure", direction === -1 ? "desc" : "asc");
              } else {
                firstDim.qSortCriterias = [{ qSortByNumeric: direction }];
              }
            } else {
              // Только измерения без мер → по алфавиту
              firstDim.qSortCriterias = [{ qSortByAscii: 1 }];
              console.log("[SOLAI Modify] setSortAuto → ascii asc (no measure)");
            }
          }
        }

        // ── РАСШИРЕННАЯ СОРТИРОВКА: по полю, формуле, числу, алфавиту, выборке ──
        // setSort — массив критериев. Один dim может иметь НЕСКОЛЬКО критериев в
        // порядке приоритета (первый матчит первым).
        // Формат:
        // [
        //   {dim: 0, by: "measure", direction: "desc"},           // по 1-й мере убывая
        //   {dim: 0, by: "ascii",   direction: "asc"},             // tiebreaker по алфавиту
        //   {dim: 1, by: "numeric", direction: "asc"},             // второе измерение по числу возр.
        //   {dim: 0, by: "expression", expr: "Sum([X])", direction: "desc"},
        //   {dim: 0, by: "state"}                                   // выбранные сверху
        // ]
        if (modSpec.setSort && modSpec.setSort.length) {
          // Группируем по dim для построения qSortCriterias
          var byDim = {};
          modSpec.setSort.forEach(function(s) {
            var dimIdx = (s.dim !== undefined && s.dim !== null) ? parseInt(s.dim, 10) : 0;
            var dir = (s.direction === "asc" || s.direction === 1) ? 1 : -1;
            var by = String(s.by || "measure").toLowerCase();
            var crit = {};

            switch (by) {
              case "measure":
                // Сортировка по выбранной мере (по умолчанию первая)
                var measIdx = (s.measureIndex !== undefined) ? parseInt(s.measureIndex, 10) : 0;
                var mExpr = (hc.qMeasures && hc.qMeasures[measIdx] && hc.qMeasures[measIdx].qDef && hc.qMeasures[measIdx].qDef.qDef) || "";
                crit = { qSortByExpression: dir, qExpression: { qv: mExpr } };
                break;
              case "expression":
              case "formula":
                crit = { qSortByExpression: dir, qExpression: { qv: s.expr || "" } };
                break;
              case "numeric":
              case "number":
                crit = { qSortByNumeric: dir };
                break;
              case "ascii":
              case "alpha":
              case "alphabetic":
              case "text":
                crit = { qSortByAscii: dir };
                break;
              case "load":
              case "loadorder":
              case "chronological":
                crit = { qSortByLoadOrder: dir };
                break;
              case "state":
              case "selected":
                crit = { qSortByState: 1 }; // выбранные значения всегда сверху
                break;
              case "frequency":
                crit = { qSortByFrequency: dir };
                break;
              default:
                crit = { qSortByLoadOrder: dir };
            }

            if (!byDim[dimIdx]) byDim[dimIdx] = [];
            byDim[dimIdx].push(crit);
          });

          Object.keys(byDim).forEach(function(idxKey) {
            var idx = parseInt(idxKey, 10);
            if (hc.qDimensions && hc.qDimensions[idx]) {
              hc.qDimensions[idx].qSortCriterias = byDim[idxKey];
              console.log("[SOLAI Modify] setSort dim["+idx+"]:", JSON.stringify(byDim[idxKey]));
            }
          });
        }

        // ── Добавление/замена второго измерения (серии для linechart) ────
        // setDimension2: имя поля или null
        if (modSpec.setDimension2 !== undefined) {
          if (!hc.qDimensions) hc.qDimensions = [];
          // Сначала удаляем существующее второе измерение (если есть)
          if (hc.qDimensions.length >= 2) hc.qDimensions.splice(1, 1);
          // Добавляем новое если задано имя
          if (modSpec.setDimension2) {
            hc.qDimensions.splice(1, 0, {
              qDef: { qFieldDefs: [modSpec.setDimension2], qFieldLabels: [modSpec.setDimension2], cId: qlikCid() },
              qNullSuppression: true,
              qSortCriterias: [{ qSortByLoadOrder: 1 }]
            });
            console.log("[SOLAI Modify] setDimension2:", modSpec.setDimension2);
          } else {
            console.log("[SOLAI Modify] removed second dimension");
          }
        }

        // ── Изменение основного выражения меры (Set Analysis, агрегация) ─
        // setMeasureExpr: [{index, expr, label}] — заменить меру по индексу
        if (modSpec.setMeasureExpr && modSpec.setMeasureExpr.length) {
          modSpec.setMeasureExpr.forEach(function(item) {
            var idx = (item.index !== undefined) ? item.index : 0;
            if (!hc.qMeasures || !hc.qMeasures[idx]) return;
            var newExpr = safeMeasure(item.expr || "");
            var newLabel = item.label || newExpr;
            hc.qMeasures[idx].qDef.qDef = newExpr;
            if (item.label) hc.qMeasures[idx].qDef.qLabel = newLabel;
            hc.qMeasures[idx].qDef.qNumFormat = pickFmt(newExpr, newLabel);
            console.log("[SOLAI Modify] setMeasureExpr[" + idx + "]:", newExpr);
          });
        }

        // ── Установка цветового выражения ─────────────────────────────────
        // setColorExpression: строка с Qlik-выражением (HEX/ARGB) или null/"" для сброса
        if (modSpec.setColorExpression !== undefined) {
          if (!props.color) props.color = {};
          if (!modSpec.setColorExpression) {
            // Сброс на авто-режим
            props.color.auto = true;
            props.color.mode = "primary";
            props.color.useExpression = false;
            delete props.color.colorExpression;
            delete props.color.measureScheme;
            console.log("[SOLAI Modify] reset color to auto");
          } else {
            // НЕ пишем полный color-блок здесь. Одиночный setProperties с byExpression,
            // но БЕЗ qAttributeExpressions, при невалидном выражении заставляет Qlik
            // сбросить старую раскраску (тот самый «сброс цвета»). Поэтому чистим цвет
            // в auto, а реальный byExpression-блок ставит applyColorToggle ниже — он
            // ЕДИНСТВЕННЫЙ писатель цвета (фаза1+фаза2+qAttributeExpressions).
            props.color = { auto: true };
            console.log("[SOLAI Modify] setColorExpression → применит applyColorToggle:", modSpec.setColorExpression);
          }
        }

        // ── Изменение ориентации (barchart/combochart) ───────────────────
        // setOrientation: "vertical" (столбцы вверх) | "horizontal" (бары вправо)
        if (modSpec.setOrientation === "vertical" || modSpec.setOrientation === "horizontal") {
          // Multi-path для совместимости с разными версиями Qlik
          props.orientation = modSpec.setOrientation;
          props.barOrientation = modSpec.setOrientation;
          if (!props.appearance) props.appearance = {};
          props.appearance.orientation = modSpec.setOrientation;
          if (!props.style) props.style = {};
          props.style.orientation = modSpec.setOrientation;
          console.log("[SOLAI Modify] setOrientation (multi-path):", modSpec.setOrientation);
        }

        // ── Изменение основного измерения (замена первого dim) ───────────
        // setDimension: имя нового поля
        if (modSpec.setDimension) {
          if (!hc.qDimensions || !hc.qDimensions.length) {
            hc.qDimensions = [];
            hc.qDimensions.push({
              qDef: { qFieldDefs: [modSpec.setDimension], cId: qlikCid() },
              qNullSuppression: true
            });
          } else {
            hc.qDimensions[0].qDef.qFieldDefs = [modSpec.setDimension];
            hc.qDimensions[0].qDef.qFieldLabels = [modSpec.setDimension];
          }
          console.log("[SOLAI Modify] setDimension:", modSpec.setDimension);
        }

        // Если меняем colorExpression — настоящий toggle через applyColorToggle + DOM
        if (modSpec.setColorExpression !== undefined && isColorExpr(modSpec.setColorExpression)) {
          var newColorExpr = String(modSpec.setColorExpression);
          // Сначала сохраняем все ДРУГИЕ изменения (без color)
          obj.setProperties(props).then(function() {
            // Затем настоящий toggle через API + DOM-клик
            applyColorToggle(obj, newColorExpr, function() {
              console.log("[SOLAI Modify] color toggle complete");
              tryDomToggleColorCheckbox(objectId);
              onSuccess(objectId);
            });
          }, function(e) { onFail("setProperties (pre-color): " + (e.message || e)); });
        } else {
          obj.setProperties(props).then(
            function() { onSuccess(objectId); },
            function(e) { onFail("setProperties: " + (e.message || e)); }
          );
        }
      }).catch(function(e) { onFail("getProperties: " + (e.message || e)); });
    }).catch(function(e) {
      // Если objectId выглядит как маленькое число — почти наверняка AI взял
      // его из нумерации списка, а не из objectId="...". Подсказываем.
      var hint = "";
      if (/^\d{1,3}$/.test(String(objectId))) {
        hint = " (похоже на номер из списка, а не UUID — нужен полный id из objectId=\"...\")";
      }
      onFail("Объект не найден (objectId: " + objectId + ")" + hint);
    });
  }

  // ─────────────────────────────────────────────────────────────────────────
  return {
    template: template,
    initialProperties: {},
    definition: {
      type: "items",
      component: "accordion",
      items: { settings: { uses: "settings" } }
    },
    support: {
      snapshot: false,
      export: false,
      exportData: false
    },

    controller: ["$scope", "$interval", "$timeout", "$sce", "$compile", function($scope, $interval, $timeout, $sce, $compile) {
      var app = qlik.currApp(), enigmaApp = app.model.enigmaModel;

      // ── API KEY (локальный LLM Halyk Bank) ───────────────────────────────
      var API_KEY = "sk-9Ntd1gpBwTFekZOgvlriWQ";

      // ── Форматирование текста: \n → <br> для отображения ─────────────────
      $scope.formatMsg = function(text) {
        if (!text) return $sce.trustAsHtml("");
        // Логические блоки — КАЖДЫЙ с нового абзаца (модель иногда склеивает их в одну строку):
        // «Реализация в Qlik», «Результат» и предупреждение ⚠ отделяем ПУСТОЙ СТРОКОЙ.
        text = String(text)
          .replace(/[ \t]*\n?[ \t]*(\*\*\s*Реализация в Qlik)/g, "\n\n$1")
          .replace(/[ \t]*\n?[ \t]*(\*\*\s*Результат)/g, "\n\n$1")
          .replace(/[ \t]*\n?[ \t]*(⚠️?)/g, "\n\n$1")   // предупреждение — отдельным абзацем; сам ⚠ ОБЯЗАТЕЛЕН (на пробелы не сработает), опционален лишь ️ (variation selector ⚠️)
          .replace(/\n{2,}(?=[ \t]*[•\-]\s)/g, "\n")           // списки-перечисления: пустые строки перед пунктами •/– → один перенос (компактный список)
          .replace(/\n{3,}/g, "\n\n")                          // не больше одной пустой строки подряд
          .replace(/^\n+/, "");                                // без пустых строк в начале
        var safe = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        // лёгкий markdown → HTML (читаемые абзацы/акценты)
        safe = safe.replace(/`([^`]+)`/g, '<code style="background:#f1f5f9;border:1px solid #e2e8f0;border-radius:4px;padding:1px 4px;font-size:11px;font-family:monospace">$1</code>'); // `код`
        safe = safe.replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>");                 // **жирный**
        safe = safe.replace(/^\s*[•\-]\s+(.+)$/gm, '<div style="margin:1px 0 1px 8px">• $1</div>'); // строки-списки
        safe = safe.replace(/(<\/div>)\n(?=<div style="margin:1px 0 1px 8px">)/g, "$1"); // соседние пункты списка — вплотную (без лишнего <br> между ними)
        safe = safe.replace(/\n{2,}/g, '<div style="height:6px"></div>');     // пустая строка = абзац
        safe = safe.replace(/\n/g, "<br>");                                    // одиночный перенос
        return $sce.trustAsHtml(safe);
      };
      $scope.trustHtml = function(html) {
        return $sce.trustAsHtml(html || "");
      };

      // ── State ────────────────────────────────────────────────────────────
      $scope.prompt = "";
      $scope.loading = false;
      $scope.status = "";
      $scope.messages = [];
      $scope.panelOpen = false;
      $scope.createdObjects = []; // Объекты созданные через чат — можно модифицировать
      // Контекстная преемственность диалога (сессионная, в памяти):
      $scope._glossaryMatches    = {};  // termGid/name -> {name, description, gid} — термины Ataccama, найденные в этом диалоге
      $scope._lastGlossaryTermName = ""; // имя термина, подмешанного на текущем ходу (для связи с создаваемым объектом)
      $scope._lastCreatedObjectId  = ""; // id последнего созданного объекта
      $scope._lastModifiedObjectId = ""; // id последнего изменённого объекта
      $scope._signFlipFields       = {}; // поля, для которых *-1 узаконен в этой сессии (определение/просьба) — чтобы сохранять знак при добавлении в существующий объект

      // Настройки SOLAI берутся из констант SOLAI_COMPANY/SOLAI_SECTOR в начале файла
      var _solaiCtx = SECTOR_CONTEXTS[SOLAI_SECTOR] || SECTOR_CONTEXTS.general;
      $scope.solai = {
        sector:       SOLAI_SECTOR,
        sectorLabel:  _solaiCtx.label,
        sheetTitle:   "",
        companyName:  (SOLAI_COMPANY || "").trim(),
        userName:     (SOLAI_USER_NAME || "").trim(),
        welcomeChips: _solaiCtx.welcomeChips || [],
        version:      SOLAI_VERSION
      };
      console.log("[SOLAI] version " + SOLAI_VERSION + " loaded");

      function refreshSheetTitle() {
        loadSheetTitle(app, function(title) {
          $scope.$applyAsync(function() { $scope.solai.sheetTitle = title; });
        });
      }
      refreshSheetTitle();
      $scope.chatIcon = '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><circle cx="8" cy="10" r="1" fill="#fff" stroke="none"/><circle cx="12" cy="10" r="1" fill="#fff" stroke="none"/><circle cx="16" cy="10" r="1" fill="#fff" stroke="none"/></svg>';
      $scope.closeIcon = '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';

      // ── Загрузка истории из localStorage ─────────────────────────────────
      try {
        var saved = localStorage.getItem(STORAGE_KEY);
        if (saved) $scope.messages = JSON.parse(saved);
      } catch(e) {}

      function saveHistory() {
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify($scope.messages)); } catch(e) {}
      }

      function scrollToBottom() {
        $timeout(function() {
          var el = document.getElementById("solai-messages-container");
          if (el) el.scrollTop = el.scrollHeight;
        }, 50);
      }

      // ══════════════════════════════════════════════════════════════════════
      // ── SIDEBAR PANEL ─────────────────────────────────────────────────────
      // ══════════════════════════════════════════════════════════════════════
      var PANEL_WIDTH = 456;
      var panelEl = null;

      // Находим скроллируемый контейнер листа
      function getSheetContainer() {
        return document.querySelector(".qvt-sheet")
            || document.querySelector(".qv-panel-sheet")
            || document.querySelector("#grid")
            || document.querySelector(".qv-stage-container .qv-panel-content")
            || document.querySelector(".qv-panel-content");
      }

      // Определяем границы листа (ниже тулбара, выше футера)
      function getSheetBounds() {
        var sheetEl = getSheetContainer();
        if (sheetEl) {
          var r = sheetEl.getBoundingClientRect();
          return { top: Math.round(r.top), height: Math.round(r.height) };
        }
        // Fallback: ищем тулбар Qlik и начинаем ниже него
        var toolbar = document.querySelector(".qv-toolbar-container")
                   || document.querySelector(".qs-toolbar")
                   || document.querySelector('[tid="toolbar"]');
        var topOffset = toolbar ? Math.round(toolbar.getBoundingClientRect().bottom) : 0;
        return { top: topOffset, height: window.innerHeight - topOffset };
      }

      function buildPanel() {
        if (document.getElementById("solai-side-panel")) {
          panelEl = document.getElementById("solai-side-panel");
          return;
        }

        panelEl = document.createElement("div");
        panelEl.id = "solai-side-panel";

        // Панель фиксирована к правому краю, привязана к области листа
        var bounds = getSheetBounds();
        panelEl.style.cssText = [
          "position:fixed",
          "top:" + bounds.top + "px",
          "right:0",
          "width:0", "overflow:hidden",
          "height:" + bounds.height + "px",
          "z-index:100000",
          "transform:none",
          "transition:width .3s cubic-bezier(.4,0,.2,1)",
          "display:flex", "flex-direction:column",
          "background:#ffffff",
          "border-left:1px solid #e0e2e6",
          "box-shadow:-2px 0 12px rgba(0,0,0,.06)",
          "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
          "color:#1a1a2e", "font-size:13px"
        ].join(";");

        // Все стили inline — CSS файл не гарантирован для элементов вне расширения
        var S = {
          hdr: "display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:#fff;flex-shrink:0",
          hdrL: "display:flex;align-items:center;gap:10px",
          ava: "width:34px;height:34px;background:#1a1a2e;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:#fff;letter-spacing:.5px",
          title: "font-size:14px;font-weight:600;color:#1a1a2e",
          sub: "font-size:11px;color:#9ca3af;margin-top:1px",
          acts: "display:flex;align-items:center;gap:4px",
          ibtn: "background:none;border:none;cursor:pointer;width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#9ca3af",
          msgs: "flex:1;overflow-y:auto;padding:14px 12px;display:flex;flex-direction:column;gap:10px;scroll-behavior:smooth;background:#fff",
          inp: "display:flex;align-items:flex-end;gap:7px;padding:10px 12px;background:#fff;flex-shrink:0",
          ta: "flex:1;background:#f9fafb;border:1px solid #e5e7eb;border-radius:12px;color:#1a1a2e;font-size:13px;padding:9px 12px;resize:none;outline:none;font-family:inherit;line-height:1.5;max-height:100px",
          sbtn: "width:36px;height:36px;flex-shrink:0;background:#1a1a2e;border:none;border-radius:10px;color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center",
          ubub: "background:#1a1a2e;color:#fff;padding:9px 13px;border-radius:16px 16px 4px 16px;max-width:80%;font-size:13px;line-height:1.5;cursor:pointer",
          bbub: "background:#fff;color:#374151;padding:9px 13px;border-radius:4px 16px 16px 16px;font-size:13px;line-height:1.55;border:1px solid #e8eaed;box-shadow:0 1px 3px rgba(0,0,0,.04);cursor:pointer",
          bava: "width:26px;height:26px;flex-shrink:0;background:#1a1a2e;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:700;color:#fff;margin-top:2px",
          chip: "display:inline-block;background:#f3f4f6;color:#374151;padding:4px 10px;border-radius:20px;margin:3px 3px 0 0;font-size:11px;cursor:pointer;border:1px solid #e5e7eb",

          // ── Welcome-экран ────────────────────────────────────────────────
          wWrap:  "display:flex;flex-direction:column;align-items:center;justify-content:flex-start;padding:122px 22px 18px;text-align:center;height:100%;overflow-y:auto",
          wLogo:  "width:64px;height:64px;background:#1a1a2e;border-radius:18px;display:flex;align-items:center;justify-content:center;margin-bottom:22px;box-shadow:0 4px 14px rgba(26,26,46,.18);font-size:18px;font-weight:700;color:#fff;letter-spacing:.8px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
          wHi:    "font-size:18px;color:#6b7280;font-weight:400;margin-bottom:2px;letter-spacing:-.2px",
          wH1:    "font-size:21px;color:#1a1a2e;font-weight:600;margin-bottom:12px;letter-spacing:-.3px;line-height:1.3",
          wSub:   "font-size:13px;color:#9ca3af;line-height:1.55;margin-bottom:24px;max-width:300px",
          wGrid:  "display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-bottom:18px;max-width:380px",
          wChip:  "display:inline-flex;align-items:center;gap:8px;background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:9px 13px;font-size:13px;font-weight:500;color:#1f2937;cursor:pointer;transition:all .15s;font-family:inherit",
          wIco:   "width:18px;height:18px;flex-shrink:0;display:flex;align-items:center;justify-content:center",
          wHint:  "font-size:11px;color:#9ca3af;margin:14px 0 6px;text-transform:uppercase;letter-spacing:.5px;font-weight:600",
          wSChip: "display:inline-block;background:#f3f4f6;color:#4b5563;padding:5px 11px;border-radius:14px;margin:3px 3px 0 0;font-size:11px;cursor:pointer;border:1px solid #e5e7eb;font-family:inherit"
        };

        panelEl.innerHTML = [
          '<div style="' + S.hdr + '">',
          '  <div style="' + S.hdrL + '">',
          '    <div style="' + S.ava + '">AI</div>',
          '    <div>',
          '      <div style="' + S.title + '" ng-if="solai.companyName">{{solai.companyName}}</div>',
          '      <div style="' + S.sub + '">{{solai.sheetTitle || solai.sectorLabel || \'Готов к анализу\'}} · v{{solai.version}}</div>',
          '    </div>',
          '  </div>',
          '  <div style="' + S.acts + '">',
          '    <button style="' + S.ibtn + '" ng-click="clearChat()" title="Очистить">',
          '      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
          '    </button>',
          '    <button style="' + S.ibtn + '" ng-click="togglePanel()" title="Закрыть">',
          '      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
          '    </button>',
          '  </div>',
          '</div>',
          '<div style="' + S.msgs + '" id="solai-messages-container">',
          // ── WELCOME-ЭКРАН (когда нет сообщений) ──────────────────────────
          '  <div ng-if="messages.length === 0" style="' + S.wWrap + ';background:#fff">',
          '    <div style="' + S.wHi + '">Привет, {{solai.userName || \'друг\'}}!</div>',
          '    <div style="' + S.wH1 + '">С возвращением! Чем я могу помочь?</div>',
          '    <div style="' + S.wSub + '">Я здесь, чтобы помочь тебе с задачами. Выбери действие ниже или просто напиши, что тебе нужно.</div>',

          // ── Сетка из 6 банковских чипов с цветными иконками ──────────────
          '    <div style="' + S.wGrid + '">',
          // 1. Портфель — зелёный
          '      <button style="' + S.wChip + '" ng-click="setPrompt(\'покажи портфель по продуктам\')">',
          '        <span style="' + S.wIco + '"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/></svg></span>',
          '        Портфель',
          '      </button>',
          // 2. NPL — красный
          '      <button style="' + S.wChip + '" ng-click="setPrompt(\'NPL по сегментам\')">',
          '        <span style="' + S.wIco + '"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></span>',
          '        NPL',
          '      </button>',
          // 3. Топ клиентов — жёлтый
          '      <button style="' + S.wChip + '" ng-click="setPrompt(\'топ 10 клиентов\')">',
          '        <span style="' + S.wIco + '"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/></svg></span>',
          '        Топ клиентов',
          '      </button>',
          // 4. Динамика — синий
          '      <button style="' + S.wChip + '" ng-click="setPrompt(\'динамика остатков по месяцам\')">',
          '        <span style="' + S.wIco + '"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg></span>',
          '        Динамика',
          '      </button>',
          // 5. Каналы — фиолетовый
          '      <button style="' + S.wChip + '" ng-click="setPrompt(\'доход по каналам\')">',
          '        <span style="' + S.wIco + '"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#a855f7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg></span>',
          '        Каналы',
          '      </button>',
          // 6. Фильтры — оранжевый (иконка воронки)
          '      <button style="' + S.wChip + '" ng-click="setPrompt(\'покажи фильтры\')">',
          '        <span style="' + S.wIco + '"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#f97316" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg></span>',
          '        Фильтры',
          '      </button>',
          '    </div>',

          // ── Отраслевые подсказки из welcomeChips (вторичные) ─────────────
          '    <div ng-if="solai.welcomeChips.length" style="margin-top:6px">',
          '      <div style="' + S.wHint + '">Ещё идеи</div>',
          '      <span style="' + S.wSChip + '" ng-repeat="chip in solai.welcomeChips track by $index" ng-click="setPrompt(chip)">{{chip}}</span>',
          '    </div>',
          '  </div>',
          '  <div ng-repeat="msg in messages track by $index" style="display:flex;flex-direction:column;gap:4px">',
          '    <div ng-if="msg.role===\'user\'" style="display:flex;justify-content:flex-end"><div style="' + S.ubub + '" ng-click="copyText(msg.content)">{{msg.content}}</div></div>',
          '    <div ng-if="msg.role===\'assistant\'" style="display:flex;align-items:flex-start;gap:7px">',
          '      <div style="' + S.bava + '">AI</div>',
          '      <div style="display:flex;flex-direction:column;gap:5px;max-width:86%">',
          '        <div style="' + S.bbub + '" ng-click="copyText(msg.content)" ng-bind-html="formatMsg(msg.content)"></div>',
          '        <div ng-if="msg.fieldChips.length" style="display:flex;flex-wrap:wrap;gap:4px;margin-top:3px">',
          '          <span style="' + S.chip + ';font-size:11px;padding:3px 9px" ng-repeat="chip in msg.fieldChips track by $index" ng-click="setPrompt(chip)">{{chip}}</span>',
          '        </div>',
          '        <div ng-if="msg.actionChips.length" style="display:flex;flex-wrap:wrap;gap:6px;margin-top:5px">',
          '          <span ng-repeat="a in msg.actionChips track by $index" ng-click="runAction(a)" style="cursor:pointer;font-size:11px;font-weight:500;padding:5px 11px;border-radius:8px;background:#eef2ff;color:#3730a3;border:1px solid #c7d2fe">{{a.label}}</span>',
          '        </div>',
          '        <div ng-if="msg.suggestions.length" style="display:flex;flex-direction:column;gap:5px">',
          '          <div ng-repeat="s in msg.suggestions track by $index" style="display:flex;align-items:center;justify-content:space-between;background:#f9fafb;border:1px solid #e5e7eb;border-radius:10px;padding:7px 9px">',
          '            <div style="display:flex;align-items:center;gap:7px;flex:1;min-width:0">',
          '              <span style="width:22px;height:22px;flex-shrink:0;display:flex;align-items:center;justify-content:center" ng-bind-html="trustHtml(s.icon)"></span>',
          '              <div style="min-width:0"><div style="font-size:12px;font-weight:500;color:#1f2937;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{{s.title}}</div><div style="font-size:10px;color:#9ca3af;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{{s.reason}}</div></div>',
          '            </div>',
          '            <button ng-if="!s.creating && !s.done && !s.completed" ng-click="createChart(msg,s)" class="solai-cb solai-cb-idle" title="Создать">',
          '              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
          '            </button>',
          '            <button ng-if="s.creating" class="solai-cb solai-cb-loading" disabled>',
          '              <svg class="solai-spin" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>',
          '            </button>',
          '            <button ng-if="s.done" class="solai-cb solai-cb-done" disabled>',
          '              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
          '            </button>',
          '            <button ng-if="s.completed" ng-click="createChart(msg,s)" class="solai-cb solai-cb-redo" title="Создать ещё раз">',
          '              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/></svg>',
          '            </button>',
          '          </div>',
          '        </div>',
          '        <div ng-if="msg.content" class="solai-actions">',
          '          <button class="solai-act-btn" ng-click="copyMessage(msg)" title="Скопировать">',
          '            <svg ng-if="!msg.copied" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>',
          '            <svg ng-if="msg.copied" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
          '          </button>',
          '          <button class="solai-act-btn" ng-class="{\'solai-act-up\': msg.rating===\'up\'}" ng-click="rateMessage(msg, \'up\')" title="Хороший ответ">',
          '            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 10v12"/><path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H7V10l4-9c1.66 0 3 1.34 3 3v2.88Z"/></svg>',
          '          </button>',
          '          <button class="solai-act-btn" ng-class="{\'solai-act-down\': msg.rating===\'down\'}" ng-click="rateMessage(msg, \'down\')" title="Плохой ответ">',
          '            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 14V2"/><path d="M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H17v12l-4 9c-1.66 0-3-1.34-3-3v-2.88Z"/></svg>',
          '          </button>',
          '          <button class="solai-act-btn" ng-click="regenerateMessage(msg)" ng-disabled="loading" title="Сгенерировать заново">',
          '            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/></svg>',
          '          </button>',
          '        </div>',
          '      </div>',
          '    </div>',
          '    <div ng-if="msg.role===\'error\'" style="display:flex;justify-content:center"><div style="background:#fff5f5;color:#e53e3e;padding:6px 12px;border-radius:8px;font-size:12px;border:1px solid #fed7d7">⚠ {{msg.content}}</div></div>',
          '  </div>',
          '  <div ng-if="loading" style="display:flex;align-items:center;gap:7px">',
          '    <div style="' + S.bava + '">AI</div>',
          '    <span class="solai-thinking">{{status || \'Думает…\'}}</span>',
          '  </div>',
          '</div>',
          '<div style="' + S.inp + '">',
          '  <textarea style="' + S.ta + '" ng-model="prompt" placeholder="Задай вопрос…" ng-keydown="onKeydown($event)" rows="1"></textarea>',
          '  <button ng-if="!loading" style="' + S.sbtn + '" ng-click="sendMessage()" ng-disabled="!prompt.trim()" title="Отправить">',
          '    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M22 2L11 13M22 2L15 22L11 13M22 2L2 9L11 13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
          '  </button>',
          '  <button ng-if="loading" style="' + S.sbtn + '" ng-click="stopGeneration()" title="Остановить">',
          '    <svg width="16" height="16" viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/></svg>',
          '  </button>',
          '</div>'
        ].join("\n");

        document.body.appendChild(panelEl);
        $compile(panelEl)($scope);
        console.log("[SOLAI] Sidebar panel injected, aligned to sheet bounds");
      }

      // ── Открыть / закрыть ──────────────────────────────────────────────
      $scope.togglePanel = function() {
        if (!panelEl) buildPanel();

        $scope.panelOpen = !$scope.panelOpen;
        var sheetEl = getSheetContainer();

        // На каждое открытие — обновляем название листа (пользователь мог переключить лист)
        if ($scope.panelOpen) refreshSheetTitle();

        console.log("[SOLAI Toggle] panelOpen:", $scope.panelOpen, "panelEl:", !!panelEl,
          "inDOM:", !!(panelEl && panelEl.parentNode), "sheetEl:", !!sheetEl);

        if ($scope.panelOpen) {
          // Гарантируем что панель в DOM
          if (panelEl && !panelEl.parentNode) {
            document.body.appendChild(panelEl);
          }
          // Привязываем к границам листа
          var bounds = getSheetBounds();
          panelEl.style.top = bounds.top + "px";
          panelEl.style.height = bounds.height + "px";
          panelEl.style.width = PANEL_WIDTH + "px";
          panelEl.style.overflow = "visible";

          if (sheetEl) {
            sheetEl.style.transition = "padding-right .3s cubic-bezier(.4,0,.2,1)";
            sheetEl.style.paddingRight = PANEL_WIDTH + "px";
          }
        } else {
          panelEl.style.width = "0";
          panelEl.style.overflow = "hidden";
          if (sheetEl) {
            sheetEl.style.paddingRight = "";
          }
        }

        scrollToBottom();
      };

      // Создаём панель при загрузке (скрытую)
      $timeout(function() { buildPanel(); }, 400);

      // ── ДЕЛАЕМ ЯЧЕЙКУ РАСШИРЕНИЯ ПРОЗРАЧНОЙ И КЛИКОПРОНИЦАЕМОЙ ──────────
      // Видимый триггер больше не нужен — открытие чата идёт через кнопку в
      // toolbar. Сама ячейка SOLAI на листе должна быть «прозрачной»:
      // не показывать чрома, не ловить клики, чтобы соседние/наложенные
      // объекты работали без помех.
      $timeout(function() {
        var hosts = document.getElementsByClassName("solai-viz-host");
        for (var i = 0; i < hosts.length; i++) {
          var host = hosts[i];
          // Идём вверх по DOM, обнуляя фон/тень/обводку у каждого Qlik-контейнера
          var node = host;
          for (var depth = 0; depth < 6 && node; depth++) {
            node.style.background = "transparent";
            node.style.boxShadow = "none";
            node.style.border = "none";
            // pointer-events:none → клики проходят сквозь нашу ячейку
            node.style.pointerEvents = "none";
            node = node.parentElement;
            // Останавливаемся, когда вышли за пределы Qlik object-обёртки
            if (node && (node.classList.contains("qv-panel-sheet") || node.tagName === "BODY")) break;
          }
        }
        console.log("[SOLAI] Cell made transparent + click-through, hosts:", hosts.length);
      }, 600);

      // ── ИНЪЕКЦИЯ КНОПКИ SOLAI В ВЕРХНЮЮ ПАНЕЛЬ QLIK ───────────────────────
      // Qlik не даёт API для добавления кнопок в action-bar, поэтому вставляем
      // нашу кнопку напрямую в DOM. Целевая позиция — ПЕРЕД иконкой
      // «Инструмент выборок» (selection tool). Fallback — перед «Изменить лист».
      // Используем периодическую проверку, чтобы переинъекировать кнопку,
      // если Qlik перерисует панель (переключение лист↔редактирование).
      var SOLAI_TOPBAR_ID = "solai-topbar-trigger";
      var SOLAI_TOPBAR_AI_ID = "solai-topbar-ai-text";

      // Поиск кнопки в action-bar по нескольким атрибутам и локализациям
      function findToolbarBtn(titles) {
        var sel = titles.map(function(t) {
          return '[title*="' + t + '"],[aria-label*="' + t + '"]';
        }).join(",");
        var candidates = document.querySelectorAll(sel);
        for (var i = 0; i < candidates.length; i++) {
          var el = candidates[i];
          if (el.tagName === "BUTTON") return el;
          var inBtn = el.closest && el.closest("button");
          if (inBtn) return inBtn;
          if (el.tagName === "A" || el.getAttribute("role") === "button") return el;
        }
        // Fallback по текстовому содержимому (для "Изменить лист", у иконок текста нет)
        var allBtns = document.querySelectorAll("button, [role='button']");
        for (var j = 0; j < allBtns.length; j++) {
          var t = (allBtns[j].textContent || "").trim().toLowerCase();
          for (var k = 0; k < titles.length; k++) {
            if (t === titles[k].toLowerCase()) return allBtns[j];
          }
        }
        return null;
      }

      // Кнопка «Отменить» (Undo) — появляется в edit-mode как левая стрелка
      // в паре undo/redo (↶ ↷). Самый стабильный левый якорь в edit-mode.
      function findUndoButton() {
        return findToolbarBtn([
          "Отменить", "Undo",
          "Отменить действие", "Undo action"
        ]);
      }
      function findSelectionToolButton() {
        return findToolbarBtn([
          "Инструмент выборок",
          "Открыть инструмент выборок",
          "Selection tool",
          "Selections tool",
          "Open selection tool"
        ]);
      }
      // Edit-mode контролы (вырезать/копировать/вставить/удалить).
      // Они находятся в той же области toolbar, где «Инструмент выборок»
      // в view-mode. Ставим SOLAI перед ними, чтобы кнопка не уезжала вправо.
      function findEditControlButton() {
        return findToolbarBtn([
          "Вырезать", "Cut",
          "Копировать", "Copy",
          "Вставить", "Paste",
          "Удалить", "Delete",
          "Дублировать", "Duplicate"
        ]);
      }
      function findEditSheetButton() {
        // View mode → «Изменить лист», edit mode → «Изменение завершено»
        return findToolbarBtn([
          "Изменить лист", "Edit sheet", "Editar hoja",
          "Изменение завершено", "Завершить редактирование",
          "Done editing", "Finish editing", "Done"
        ]);
      }

      // Подкраска "AI" — зелёный при ховере или когда панель открыта
      function refreshAIColor() {
        var ai = document.getElementById(SOLAI_TOPBAR_AI_ID);
        if (!ai) return;
        var btn = document.getElementById(SOLAI_TOPBAR_ID);
        var isHover = btn && btn.dataset.hover === "1";
        var isActive = !!$scope.panelOpen;
        ai.style.color = (isHover || isActive) ? "#1ab66a" : "#ffffff";
      }

      function injectTopbarButton() {
        if (document.getElementById(SOLAI_TOPBAR_ID)) return true;

        // Приоритет якоря (сверху вниз):
        // 1. «Инструмент выборок» — стабильный якорь в view-mode
        // 2. «Отменить» (Undo) — самый левый стабильный якорь в edit-mode,
        //    SOLAI встаёт перед стрелками undo/redo (↶ ↷)
        // 3. Edit-контролы (Вырезать/Копировать) — fallback для edit-mode
        // 4. «Изменить лист» / «Изменение завершено» — последний fallback
        var anchorBtn = findSelectionToolButton()
                     || findUndoButton()
                     || findEditControlButton()
                     || findEditSheetButton();
        if (!anchorBtn) return false;

        var parent = anchorBtn.parentElement;
        if (!parent) return false;

        var btn = document.createElement("button");
        btn.id = SOLAI_TOPBAR_ID;
        btn.type = "button";
        btn.title = "Открыть SOLAI чат";
        btn.style.cssText = [
          "display:inline-flex",
          "align-items:center",
          "justify-content:center",
          "padding:0 14px",
          "margin-right:8px",
          "background:#1a1a2e",
          "border:1px solid #1a1a2e",
          "border-radius:6px",
          "cursor:pointer",
          "height:32px",
          "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
          "font-size:13px",
          "font-weight:700",
          "letter-spacing:.5px",
          "line-height:1",
          "white-space:nowrap",
          "outline:none",
          "opacity:1",
          "box-shadow:0 1px 2px rgba(26,26,46,.15)"
        ].join(";");

        // SOLAI как HTML-спаны: первые буквы "SOL" белые, последние "AI"
        // меняют цвет на #1ab66a при ховере или активном чате.
        // HTML-спаны (а не SVG) — для естественной ширины по тексту, без пустоты справа.
        btn.innerHTML =
          '<span style="color:#fff">SOL</span>' +
          '<span id="' + SOLAI_TOPBAR_AI_ID + '" style="color:#fff;transition:color .15s">AI</span>';

        // Hover: только цвет "AI", без смены фона/тени (чтобы не было «пелены»)
        btn.addEventListener("mouseenter", function() {
          btn.dataset.hover = "1";
          refreshAIColor();
        });
        btn.addEventListener("mouseleave", function() {
          btn.dataset.hover = "0";
          refreshAIColor();
        });
        btn.addEventListener("click", function(e) {
          e.preventDefault();
          e.stopPropagation();
          $scope.$applyAsync(function() { $scope.togglePanel(); });
        });

        parent.insertBefore(btn, anchorBtn);
        console.log("[SOLAI Topbar] button injected before:", anchorBtn);
        refreshAIColor();
        return true;
      }

      // Следим за активным состоянием — когда панель открывается/закрывается,
      // подсвечиваем "AI" зелёным / возвращаем белый.
      $scope.$watch("panelOpen", function() { refreshAIColor(); });

      // ── ДЕТЕКТИРОВАНИЕ РЕЖИМА VIEW ↔ EDIT ──────────────────────────────
      // При входе в edit-mode (нажата «Изменить лист») закрываем чат, чтобы
      // не перекрывал меню редактирования. При выходе обратно — если чат
      // был открыт до входа, восстанавливаем; если был закрыт — оставляем
      // закрытым.
      var solaiCurrentMode = null; // "view" | "edit"
      var solaiPanelOpenBeforeEdit = false;

      function checkModeTransition() {
        // Edit-mode опознаём по наличию кнопки «Отменить» (Undo) —
        // она есть только в режиме редактирования.
        var inEditMode = !!findUndoButton();
        var newMode = inEditMode ? "edit" : "view";

        // Первая инициализация — просто запомнить, без действий
        if (solaiCurrentMode === null) {
          solaiCurrentMode = newMode;
          return;
        }
        if (newMode === solaiCurrentMode) return;

        if (newMode === "edit") {
          // VIEW → EDIT: запоминаем состояние и закрываем чат если открыт
          solaiPanelOpenBeforeEdit = !!$scope.panelOpen;
          if ($scope.panelOpen) {
            $scope.$applyAsync(function() {
              if ($scope.panelOpen) $scope.togglePanel();
            });
          }
          console.log("[SOLAI Mode] view → edit, panel was open:", solaiPanelOpenBeforeEdit);
        } else {
          // EDIT → VIEW: если чат был открыт до edit-mode, восстанавливаем
          if (solaiPanelOpenBeforeEdit && !$scope.panelOpen) {
            $scope.$applyAsync(function() {
              if (!$scope.panelOpen) $scope.togglePanel();
            });
          }
          console.log("[SOLAI Mode] edit → view, restored:", solaiPanelOpenBeforeEdit);
          solaiPanelOpenBeforeEdit = false;
        }
        solaiCurrentMode = newMode;
      }

      // Первая попытка — сразу.
      $timeout(function() { injectTopbarButton(); checkModeTransition(); }, 800);

      // Подстраховка: периодическая проверка каждые 800 мс.
      // На случай если MutationObserver пропустит изменение или его сбросят.
      var topbarInterval = setInterval(function() {
        if (!document.getElementById(SOLAI_TOPBAR_ID)) {
          injectTopbarButton();
        }
        checkModeTransition();
      }, 800);

      // MutationObserver — мгновенная реакция на перерисовку toolbar.
      // Когда Qlik переключается между view/edit-mode, action-bar полностью
      // перерисовывается. Наблюдаем за body и переинъекируем кнопку сразу,
      // как только она исчезает (а не через 2 секунды).
      var topbarObserver = new MutationObserver(function(mutations) {
        // Дешёвая проверка: если наша кнопка отсутствует — пробуем вставить
        if (!document.getElementById(SOLAI_TOPBAR_ID)) {
          injectTopbarButton();
        }
        // Параллельно проверяем переход между view ↔ edit
        checkModeTransition();
      });
      try {
        topbarObserver.observe(document.body, {
          childList: true,
          subtree:   true
        });
      } catch(e) {
        console.warn("[SOLAI Topbar] MutationObserver failed:", e);
      }

      // Чистим при разрушении контроллера
      $scope.$on("$destroy", function() {
        clearInterval(topbarInterval);
        try { topbarObserver.disconnect(); } catch(e) {}
        var b = document.getElementById(SOLAI_TOPBAR_ID);
        if (b && b.parentNode) b.parentNode.removeChild(b);
      });

      // ── Text selection в sidebar ──────────────────────────────────────────
      $timeout(function() {
        var container = document.getElementById("solai-messages-container");
        if (!container) return;
        function allowInContainer(e) {
          if (container.contains(e.target)) e.stopPropagation();
        }
        document.addEventListener("selectstart", allowInContainer, true);
        document.addEventListener("mousedown", allowInContainer, true);
        document.addEventListener("mouseup", allowInContainer, true);
        console.log("[SOLAI] Text selection enabled in sidebar");
      }, 600);

      // ── Cleanup ──────────────────────────────────────────────────────────
      $scope.$on("$destroy", function() {
        if (panelEl && panelEl.parentNode) panelEl.parentNode.removeChild(panelEl);
        var sheetEl = getSheetContainer();
        if (sheetEl) sheetEl.style.paddingRight = "";
      });

      // ── Копировать текст по клику ─────────────────────────────────────────
      $scope.copyText = function(text) {
        if (!text) return;
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).catch(function() { fallbackCopy(text); });
        } else {
          fallbackCopy(text);
        }
      };
      function fallbackCopy(text) {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.style.cssText = "position:fixed;left:-9999px;top:-9999px;opacity:0";
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand("copy"); } catch(e) {}
        document.body.removeChild(ta);
      }

      $scope.clearChat = function() {
        $scope.messages = [];
        try { localStorage.removeItem(STORAGE_KEY); } catch(e) {}
      };

      $scope.copyMessage = function(msg) {
        if (!msg || !msg.content) return;
        $scope.copyText(msg.content);
        msg.copied = true;
        $timeout(function() { msg.copied = false; }, 1500);
      };

      $scope.regenerateMessage = function(msg) {
        if (!msg || $scope.loading) return;

        // Найти ближайший user-вопрос ДО этого ответа
        var idx = $scope.messages.indexOf(msg);
        if (idx < 0) return;
        var userIdx = -1;
        var question = "";
        for (var i = idx - 1; i >= 0; i--) {
          if ($scope.messages[i].role === "user") {
            userIdx = i;
            question = $scope.messages[i].content;
            break;
          }
        }
        if (userIdx < 0 || !question) return;

        // Срезаем всё начиная с того user-вопроса — sendMessage добавит его заново
        $scope.messages.splice(userIdx);
        saveHistory();

        $scope.prompt = question;
        $scope.sendMessage();
      };

      $scope.rateMessage = function(msg, rating) {
        if (!msg) return;

        var prevRating = msg.rating || null;
        var newRating = (prevRating === rating) ? null : rating;
        msg.rating = newRating;

        // Найти вопрос пользователя, на который отвечал ассистент
        var idx = $scope.messages.indexOf(msg);
        var question = "";
        for (var i = idx - 1; i >= 0; i--) {
          if ($scope.messages[i].role === "user") { question = $scope.messages[i].content; break; }
        }

        if (question) {
          var key = normalizeQuestion(question);
          if (key) {
            try {
              var counts = JSON.parse(localStorage.getItem(RULE_COUNTS_KEY) || "{}");
              var rule = counts[key] || { upvotes: 0, downvotes: 0, lastAnswer: "", lastTs: "" };

              // Снимаем предыдущий голос (для toggle / переключения up↔down)
              if (prevRating === "up")   rule.upvotes   = Math.max(0, rule.upvotes - 1);
              if (prevRating === "down") rule.downvotes = Math.max(0, rule.downvotes - 1);

              // Применяем новый голос
              if (newRating === "up") {
                rule.upvotes++;
                rule.lastAnswer = msg.content;
                rule.lastTs = new Date().toISOString();
              }
              if (newRating === "down") rule.downvotes++;

              counts[key] = rule;
              localStorage.setItem(RULE_COUNTS_KEY, JSON.stringify(counts));

              // Промоут в список «истин» — только при достижении порога
              // и если правило ещё не зафиксировано (раз попав — не перезаписываем)
              if (rule.upvotes >= TRUST_THRESHOLD) {
                var trusted = getTrustedExamples();
                var alreadyTrusted = trusted.some(function(t) { return t.key === key; });
                if (!alreadyTrusted) {
                  trusted.push({
                    key: key,
                    question: question,
                    answer: rule.lastAnswer || msg.content,
                    upvotes: rule.upvotes,
                    lockedAt: new Date().toISOString(),
                    sector: SOLAI_SECTOR
                  });
                  localStorage.setItem(TRUSTED_KEY, JSON.stringify(trusted));
                  console.log("[SOLAI] Правило зафиксировано в trusted:", question);
                }
              }
            } catch(e) {}
          }
        }

        // Лог отдельных кликов (только новые установки, не toggle-off)
        if (newRating) {
          try {
            var log = JSON.parse(localStorage.getItem(FEEDBACK_KEY) || "[]");
            log.push({
              ts: new Date().toISOString(),
              rating: newRating,
              question: question,
              answer: msg.content,
              sector: SOLAI_SECTOR,
              company: ($scope.solai && $scope.solai.companyName) || ""
            });
            if (log.length > 200) log = log.slice(-200);
            localStorage.setItem(FEEDBACK_KEY, JSON.stringify(log));
          } catch(e) {}
        }

        saveHistory();
      };

      // Кнопка-действие: в отличие от setPrompt (добавляет в инпут) — СРАЗУ отправляет.
      // a может быть строкой или {label, send}.
      $scope.runAction = function(a) {
        var text = (a && (a.send || a.label)) || a;
        if (!text || $scope.loading) return;
        $scope.prompt = String(text);
        $scope.sendMessage();
      };

      $scope.setPrompt = function(text) {
        var cur = ($scope.prompt || "").replace(/\s+$/, "");
        if (cur) {
          // Append comma-separated if prompt already has text
          $scope.prompt = cur.replace(/,\s*$/, "") + ", " + text;
        } else {
          $scope.prompt = text;
        }
      };

      $scope.onKeydown = function(e) {
        if (e.keyCode === 13 && !e.shiftKey) {
          e.preventDefault();
          $scope.sendMessage();
        }
      };

      // ── Диагностика Ataccama в чат (без F12) ───────────────────────────────
      // Печатает копируемый отчёт прямо сообщением в чат: статус токена, число
      // терминов, найденный термин и его описание — или ошибку с подсказкой.
      // Пользователь копирует это сообщение (клик по нему) и присылает на разбор.
      function pushDiag(lines) {
        $scope.$applyAsync(function() {
          $scope.loading = false;
          $scope.status = "";
          $scope.messages.push({ role: "assistant", content: lines.join("\n"), suggestions: [], fieldChips: [] });
          saveHistory();
          scrollToBottom();
        });
      }

      // Ответы на 3 открытых вопроса админам — по ФАКТУ прогона в Qlik.
      // outcome: "ok" | "glossary_fail" | "token_fail"; errMsg — текст ошибки (если была).
      function appendAdminAnswers(L, outcome, errMsg) {
        var method  = ataccama.authMethodUsed();
        var le      = ataccama.lastError() || {};
        var tokenOk = (outcome === "ok" || outcome === "glossary_fail"); // токен есть в обоих
        var cors    = (le.kind === "network")
                   || /failed to fetch|networkerror|load failed/i.test(errMsg || "");

        L.push("");
        L.push("─── ОТВЕТЫ ДЛЯ АДМИНОВ (по факту прогона) ───");

        // 1) Service Accounts
        if (tokenOk)
          L.push("1) Service Accounts: ВКЛЮЧЕНЫ — токен по client_credentials выдан.");
        else if (le.kind === "auth")
          L.push("1) Service Accounts: НЕ включены ИЛИ неверный client_secret (сервер ответил invalid_client/401).");
        else if (cors)
          L.push("1) Service Accounts: проверить не удалось — запрос не дошёл до сервера (см. п.3).");
        else
          L.push("1) Service Accounts: токен не получен (" + (errMsg || "ошибка") + ").");

        // 2) Метод аутентификации (basic / body)
        if (tokenOk && method) {
          var label = (method === "basic") ? "Basic Auth header" : "учётка в теле (body)";
          L.push("2) Метод аутентификации: РАБОТАЕТ «" + label + "» (CLIENT_AUTH=\"" + method + "\").");
          if (method !== ataccama.config.CLIENT_AUTH)
            L.push("   ⚠ Сработал НЕ тот метод, что в конфиге — поставь CONFIG.CLIENT_AUTH=\"" + method + "\".");
        } else if (le.kind === "auth") {
          L.push("2) Метод аутентификации: оба варианта (basic и body) отклонены — дело не в методе, а в client_id/secret или Service Accounts.");
        } else {
          L.push("2) Метод аутентификации: проверить не удалось (токен не получен).");
        }

        // 3) CORS / Web Origins
        if (cors)
          L.push("3) CORS/Web Origins: ЗАБЛОКИРОВАНО браузером — разрешить origin Qlik у клиента "
                 + ataccama.config.CLIENT_ID + " (детали в F12 → Network).");
        else if (tokenOk)
          L.push("3) CORS/Web Origins: OK — запросы дошли до сервера (раз токен/данные получены).");
        else
          L.push("3) CORS/Web Origins: запрос дошёл до сервера (ошибка пришла от него) — CORS не мешает.");
      }

      function runAtaccamaDiag(text) {
        var L = [];
        L.push("SOLAI · ДИАГНОСТИКА ATACCAMA (v" + SOLAI_VERSION + ")");
        L.push("Token URL: " + ataccama.config.TOKEN_URL);
        L.push("GraphQL URL: " + ataccama.config.GRAPHQL_URL);
        L.push("Client ID: " + ataccama.config.CLIENT_ID);
        L.push("");
        if (!ataccama.config.ENABLED) {
          L.push("⚠ ATACCAMA_ENABLED = false — интеграция выключена в конфиге.");
          pushDiag(L); return;
        }
        $scope.$applyAsync(function() { $scope.status = "Проверяю Ataccama…"; });
        ataccama.getToken(function(tok) {
          L.push("1) ТОКЕН: OK (длина " + (tok || "").length + ")");
          ataccama.fetchGlossary(function(terms) {
            L.push("2) ГЛОССАРИЙ: получено терминов — " + terms.length);
            if (terms.length) {
              L.push("   Примеры (до 15):");
              terms.slice(0, 15).forEach(function(t) {
                L.push("   • " + t.name + (t.description ? "" : "  [без описания]"));
              });
            }
            L.push("");
            var term = ataccama.findTermInText(terms, text);
            if (term) {
              L.push("3) ТЕРМИН ИЗ ЗАПРОСА: НАЙДЕН «" + term.name + "»");
              L.push("   Описание: " + (term.description
                ? term.description
                : "(пусто — проверить имя поля описания в схеме GraphQL)"));
            } else {
              L.push("3) ТЕРМИН ИЗ ЗАПРОСА: не распознан.");
              L.push("   Укажите точное название после команды, напр.: /ataccama активный клиент");
            }
            L.push("");
            L.push("✅ ПОДКЛЮЧЕНИЕ К ATACCAMA РАБОТАЕТ.");
            appendAdminAnswers(L, "ok", "");
            pushDiag(L);
          }, function(err) {
            L.push("2) ГЛОССАРИЙ: ОШИБКА — " + err);
            var h1 = ataccama.errorHint(err); if (h1) L.push("   " + h1);
            L.push("");
            L.push("❌ Токен получен, но глоссарий не прочитан.");
            appendAdminAnswers(L, "glossary_fail", err);
            pushDiag(L);
          });
        }, function(err) {
          L.push("1) ТОКЕН: ОШИБКА — " + err);
          var h0 = ataccama.errorHint(err); if (h0) L.push("   " + h0);
          L.push("");
          L.push("❌ Не удалось авторизоваться в Ataccama.");
          appendAdminAnswers(L, "token_fail", err);
          pushDiag(L);
        });
      }

      // Собирает блок определения Ataccama для промпта: человеческое ОПРЕДЕЛЕНИЕ (логика) +
      // ТЕХ.ОПИСАНИЕ (SQL — источник имён полей) + СТРОГОЕ правило: поля в формуле брать
      // ДОСЛОВНО из модели данных, сопоставляя поле из Ataccama с реальным именем.
      // Похоже ли значение поля на SQL (стюард иногда кладёт SQL прямо в поле описания).
      function _looksLikeSql(t) {
        var s = String(t || "");
        return /\bselect\b[\s\S]{0,5000}\bfrom\b/i.test(s) || /^\s*(select|with|на\s+dds)\b/i.test(s);
      }
      function glossaryDefBlock(name, description, technical, recall) {
        var tech = String(technical || "").trim();
        if (tech.length > 4000) tech = tech.slice(0, 4000) + "\n…(SQL обрезан)";
        var desc = description || "";
        var hasSql = tech.length > 0;
        var head = recall
          ? "ОПРЕДЕЛЕНИЕ ИЗ ATACCAMA (использовано ранее в этом диалоге — ПРИМЕНЯЙ ПОВТОРНО):"
          : "ОПРЕДЕЛЕНИЕ ИЗ БИЗНЕС-ГЛОССАРИЯ ATACCAMA (единый справочник Банка):";
        var s = "\n\n═══════════════════════════════════════════════════\n"
          + head + "\n"
          + "ТЕРМИН: " + name + "\n"
          + "БИЗНЕС-ОПИСАНИЕ (КОНТЕКСТ — смысл показателя и выбор визуализации; НЕ источник полей/фильтров):\n"
          + (desc || "(описание в справочнике отсутствует)") + "\n"
          + (hasSql
              ? ("ТЕХ. ОПИСАНИЕ (SQL — ИСТОЧНИК ИСТИНЫ для ПОЛЕЙ и ФИЛЬТРОВ):\n" + tech + "\n")
              : "ТЕХ. ОПИСАНИЕ (SQL): отсутствует — в этом случае поля/фильтры бери из бизнес-описания, как там названо.\n")
          + "═══════════════════════════════════════════════════\n"
          + "ИНСТРУКЦИЯ (СТРОГО):\n"
          + "ФОРМАТ ОТВЕТА: НЕ пиши блок «Определение» сам — система подставит его ДОСЛОВНО из Ataccama ПЕРЕД твоим текстом.\n"
          + "Ты выводишь ДВА ОСНОВНЫХ блока, в этом порядке (и ТОЛЬКО при отсутствии поля из SQL в модели — третий абзац-предупреждение ПОСЛЕ «Результат», см. п.7):\n"
          + "   **Реализация в Qlik (Set Analysis):**\\n`<формула>`\\n\\n"
          + "   **Результат:**\\n<точное число из движка> ₸\n"
          + "Не повторяй и не пересказывай определение — оно уже будет показано дословно выше.\n"
          + "ФОРМАТ (ВАЖНО): КАЖДЫЙ блок («Реализация в Qlik», «Результат», предупреждение) — с НОВОГО АБЗАЦА, раздели ПУСТОЙ СТРОКОЙ (\\n\\n). НЕ склеивай блоки в одну строку.\n"
          + "1) ПОЛЯ и ФИЛЬТРЫ Set Analysis бери ТОЛЬКО из SQL (ТЕХ. ОПИСАНИЕ). Бизнес-описание — лишь контекст (смысл, выбор визуализации), НЕ источник полей/фильтров.\n"
          + (recall ? "   Используй ТУ ЖЕ формулу/логику показателя, что и ранее в диалоге.\n" : "")
          + "2) ПЕРЕВОД SQL → Set Analysis: WHERE col='X' → col={'X'}; col IN (a,b) → col={'a','b'}; col NOT IN (a,b) → col-={'a','b'}; SUM(field) → Sum([field]); COUNT(DISTINCT k) → Count(distinct [k]).\n"
          + "3) ДАТА: любые условия по дате/периоду (sysdate-1, последняя дата, диапазоны дат) в Set Analysis НЕ включай — просто пропусти их.\n"
          + "4) ЗНАК: если в SQL есть умножение на -1 (напр. SUM(...)*(-1)) или показатель хранится отрицательным и разворачивается — ПОВТОРИ знак: -Sum({<…>} [field]). Иначе знак НЕ меняй. -1 внутри дат (sysdate-1) — это период, НЕ знак.\n"
          + "5) СЛОЖНЫЙ SQL: (а) UNION / UNION ALL — КАЖДЫЙ SELECT собери в ОТДЕЛЬНОЕ выражение Count/Sum({<…>} …) и сложи их через «+»; условия WHERE каждого SELECT → модификаторы ИМЕННО ЕГО слагаемого, РАЗЛИЧИЯ между SELECT'ами сохраняй (напр. LOAN_SOLD_FL={0} vs LOAN_SOLD_FL={1}, разные коды продуктов -={…} vs ={…}). (б) JOIN/CASE/подзапросы — части, не сводимые к фильтру, ИГНОРИРУЙ, но собери ВСЕ поля-фильтры из WHERE; поле бери по модели (напр. код продукта из JOIN hh.dwh_code → CONTRACT_PRODUCT_CODE).\n"
          + "6) Поля бери ДОСЛОВНО как в 'МОДЕЛЬ ДАННЫХ QLIK' (сопоставь имя из SQL с реальным полем модели, с суффиксами вроде _END; НЕ сокращай, НЕ выдумывай).\n"
          + "7) ПОЛЕ ИЗ SQL ОТСУТСТВУЕТ В МОДЕЛИ QLIK: НЕ выдумывай и НЕ подменяй. Определи по SQL (FROM/JOIN), из какой таблицы оно грузится, и предупреди пользователя ОТДЕЛЬНЫМ АБЗАЦЕМ — с ПУСТОЙ СТРОКОЙ (\\n\\n) перед ним, ПОСЛЕ блока «Результат», НЕ в одной строке с числом: «⚠️ Поле <X> берётся из таблицы <Y>, но в модель Qlik не загружено — фильтр по нему не применится, добавьте поле в загрузку». Set Analysis собери по доступным полям. ИСКЛЮЧЕНИЕ: поля ДАТЫ/периода НЕ проверяй и о них НЕ предупреждай (дату мы не учитываем вообще — см. п.3).\n"
          + "8) Для точного числа верни queries[]/rankQueries[]. Отметь, что показатель собран по SQL-определению из Ataccama.\n";
        return s;
      }

      // ── Навигатор по терминам Ataccama (длинные названия не надо помнить) ────
      // Сообщение с кнопками выбора: клик отправляет точное название (см. runAction).
      function pushTermPicker(picker) {
        $scope.$applyAsync(function() {
          $scope.loading = false;
          $scope.status = "";
          $scope.messages.push({
            role: "assistant",
            content: picker.title || "Выбери термин:",
            suggestions: [], fieldChips: [],
            actionChips: picker.chips || []
          });
          saveHistory();
          scrollToBottom();
        });
      }
      // Запрос на ОБЗОР терминов/категорий (а не расчёт показателя).
      function isTermBrowse(text) {
        var t = (text || "").toLowerCase();
        if (/^\/ataccama\s+(список|термины|категори)/.test(t)) return true;
        if (/термины\s+ataccama\s*:/.test(t)) return true; // переход из чипа категории
        return /(термин\w*|категори\w*|список\s+термин)/.test(t) && /(ataccama|атакам|справочник|глоссар)/.test(t);
      }
      // Показывает категории терминов, либо термины внутри выбранной категории — кнопками.
      function runTermBrowser(text) {
        $scope.$applyAsync(function() { $scope.status = "Загружаю термины Ataccama…"; });
        ataccama.fetchGlossary(function(terms) {
          var cats = ataccama.categorize(terms);
          var m = /:\s*(.+)$/.exec(text); // «термины ataccama: <категория>»
          if (m) {
            var want = m[1].trim().toLowerCase();
            var key = Object.keys(cats).filter(function(k){ return k.toLowerCase().indexOf(want) !== -1 || want.indexOf(k.toLowerCase()) !== -1; })[0];
            var list = key ? cats[key] : [];
            if (!list.length) { pushTermPicker({ title: "В категории «" + m[1].trim() + "» терминов не нашёл.", chips: [] }); return; }
            pushTermPicker({
              title: "Категория «" + (key || m[1].trim()) + "» — " + list.length + " терминов. Нажми нужный:",
              chips: list.slice(0, 24).map(function(t){ return { label: t.name, send: t.name + " (из Ataccama)" }; })
            });
            return;
          }
          var keys = Object.keys(cats).sort(function(a,b){ return cats[b].length - cats[a].length; });
          pushTermPicker({
            title: "Термины Ataccama по категориям (" + terms.length + " всего). Нажми категорию:",
            chips: keys.map(function(k){ return { label: k + " (" + cats[k].length + ")", send: "термины ataccama: " + k }; })
          });
        }, function(err) {
          pushTermPicker({ title: "Не удалось загрузить термины Ataccama: " + err, chips: [] });
        });
      }

      // Текст определения ТЕКУЩЕГО подмешанного термина Ataccama (description + technical) —
      // чтобы SignGuard знал, требует ли определение ×(-1) явно (тогда *-1 не срезаем).
      function currentGlossaryDefText() {
        var nm = $scope._lastGlossaryTermName, gm = $scope._glossaryMatches || {}, key;
        if (!nm) return "";
        var useTech = !!ataccama.config.USE_TECHNICAL;
        for (key in gm) { if (gm[key] && gm[key].name === nm) return (gm[key].description || "") + (useTech ? ("\n" + (gm[key].technical || "")) : ""); }
        return "";
      }
      // ТОЛЬКО человеческое описание (Business definition) текущего термина — для дословной
      // подстановки в ответ кодом (модель его сокращает, поэтому берём из данных как есть).
      function currentGlossaryDescription() {
        var nm = $scope._lastGlossaryTermName, gm = $scope._glossaryMatches || {}, key;
        if (!nm) return "";
        for (key in gm) { if (gm[key] && gm[key].name === nm) return gm[key].description || ""; }
        return "";
      }
      // Поля, для которых *-1 узаконен (определением/просьбой) — запоминаем, чтобы при
      // ДОБАВЛЕНИИ той же меры в существующий объект знак не срезался (контекст определения там теряется).
      function _recordSignFlipFields(expr) {
        (String(expr || "").match(/\[([^\]]+)\]/g) || []).forEach(function(b){ $scope._signFlipFields[b.slice(1, -1).toLowerCase()] = true; });
      }
      function _exprUsesSignFlipField(expr) {
        var fs = String(expr || "").match(/\[([^\]]+)\]/g) || [];
        for (var i = 0; i < fs.length; i++) { if ($scope._signFlipFields[fs[i].slice(1, -1).toLowerCase()]) return true; }
        return false;
      }
      // Детект отрицательных значений у мер СОЗДАВАЕМОГО объекта (таблица/график) → предложить
      // кнопки «Умножить на −1 / Оставить как есть». На пути queries[]/rankQueries[] это уже есть;
      // здесь — для случая, когда ответ строит таблицу, а не считает число.
      function checkSuggestionNegatives(msgRef, suggestions) {
        if (!msgRef || (msgRef.actionChips && msgRef.actionChips.length) || !enigmaApp) return;
        var exprs = [];
        (suggestions || []).forEach(function(s){
          if (!s || s.measureLibraryId) return;                 // мастер-меры пропускаем
          if (s.measure) exprs.push(s.measure);
          (s.measures || []).forEach(function(m){ var e = (typeof m === "string") ? m : (m && m.expr); if (e) exprs.push(e); });
        });
        exprs = exprs.filter(function(e,i){ return e && exprs.indexOf(e) === i; }).slice(0, 3);
        if (!exprs.length) return;
        executeSetQueries(enigmaApp, exprs.map(function(e,i){ return { label: "neg_check_"+i, expr: e }; }), function(res){
          if (!res.some(function(r){ return typeof r.num === "number" && r.num < 0; })) return;
          $scope.$applyAsync(function(){
            if (msgRef.actionChips && msgRef.actionChips.length) return;
            msgRef.actionChips = [
              { label: "Умножить на −1", send: "Умножь этот показатель на -1 и покажи положительным" },
              { label: "Оставить как есть", send: "Оставь как есть, знак не меняй" }
            ];
            msgRef.content = (msgRef.content || "") + "\n\n⚠ Значения отрицательные — это нормально для CR/пассивных счетов (знак зависит от типа счёта). Показать положительными?";
            saveHistory(); scrollToBottom();
          });
        });
      }

      // ── Отправить сообщение ───────────────────────────────────────────────
      // Шаг 0: справочник Ataccama. Если пользователь просит использовать
      // глоссарий/справочник — тянем утверждённое определение показателя и
      // возвращаем текстовый блок для подмешивания в prompt. Иначе — пустая строка
      // (поведение без изменений, SOLAI работает по модели данных).
      function prefetchGlossary(userText, cb) {
        $scope._lastGlossaryTermName = "";
        if (!ataccama.config.ENABLED) { cb(""); return; }
        // Follow-up без слов-триггеров: если в диалоге УЖЕ находили термин с тем же названием —
        // подмешиваем то же определение повторно, чтобы модель не переизобретала формулу.
        if (!ataccama.shouldUse(userText)) {
          var prev = Object.keys($scope._glossaryMatches).map(function(k){ return $scope._glossaryMatches[k]; });
          var recalled = prev.length ? ataccama.findTermInText(prev, userText) : null;
          if (recalled) {
            $scope._lastGlossaryTermName = recalled.name;
            console.log("[SOLAI Ataccama] повторное определение термина (из контекста диалога):", recalled.name);
            cb(glossaryDefBlock(recalled.name, recalled.description, recalled.technical, true));
            return;
          }
          cb(""); return;
        }
        $scope.$applyAsync(function() { $scope.status = "Обращаюсь к справочнику Ataccama…"; });
        ataccama.fetchGlossary(function(terms) {
          var term = ataccama.findTermInText(terms, userText);
          if (!term) {
            // Нет точного совпадения → предлагаем КНОПКИ-кандидаты (длинные названия не надо помнить).
            var cands = ataccama.findTermCandidates(terms, userText, 7);
            if (cands.length) {
              console.log("[SOLAI Ataccama] точного нет, предлагаю кандидатов:", cands.length);
              cb("", { title: "Не нашёл точный термин в Ataccama. Возможно, ты про один из этих — нажми нужный:",
                       chips: cands.map(function(t){ return { label: t.name, send: t.name + " (из Ataccama)" }; }) });
              return;
            }
            var names = (terms || []).slice(0, 50).map(function(t) { return t.name; }).join(", ");
            console.warn("[SOLAI Ataccama] точное совпадение термина не найдено в вопросе");
            cb("\n\nСПРАВОЧНИК ATACCAMA: точное совпадение термина из вопроса не найдено."
               + (names ? (" Доступные термины: " + names + ".") : "")
               + " Если показатель не найден в справочнике — собери по модели данных и предупреди пользователя.\n");
            return;
          }
          console.log("[SOLAI Ataccama] подмешано определение термина:", term.name);
          // Запоминаем термин (с тех.описанием) на сессию — для follow-up без слов-триггеров.
          $scope._glossaryMatches[term.gid || term.name] = { name: term.name, description: term.description, technical: term.technical, gid: term.gid };
          $scope._lastGlossaryTermName = term.name;
          cb(glossaryDefBlock(term.name, term.description, term.technical, false));
        }, function(err) {
          console.warn("[SOLAI Ataccama] ошибка:", err);
          // Не валим запрос — продолжаем без справочника, но честно сообщаем модели.
          cb("\n\nСПРАВОЧНИК ATACCAMA: не удалось получить определение (" + err + "). "
             + "Действуй по модели данных и предупреди пользователя, что определение из справочника недоступно.\n");
        });
      }

      // Остановка текущего запроса: прерывает fetch к LLM и возвращает кнопку-стрелку.
      $scope.stopGeneration = function() {
        $scope._stopped = true;
        if ($scope._abortCtl) { try { $scope._abortCtl.abort(); } catch(e) {} $scope._abortCtl = null; }
        $scope.loading = false;
        $scope.status = "";
      };

      $scope.sendMessage = function() {
        var p = ($scope.prompt || "").trim();
        if (!p || $scope.loading) return;

        // Добавляем сообщение пользователя
        $scope.messages.push({ role: "user", content: p });
        $scope.prompt = "";
        $scope.loading = true;
        $scope._stopped = false;
        $scope._abortCtl = null;
        $scope.status = "Читаю схему…";
        saveHistory();
        scrollToBottom();

        // Обзор терминов/категорий Ataccama — показываем кнопки выбора и выходим (без LLM).
        if (isTermBrowse(p)) { runTermBrowser(p); return; }

        // Команда диагностики Ataccama — печатаем лог в чат и выходим (без LLM).
        if (ataccama.isDiagCommand(p)) { runAtaccamaDiag(p); return; }

        // Шаг 0 → затем основной конвейер. glossaryText подмешивается в dataText
        // перед первым вызовом LLM (см. ниже). Если термин неоднозначен — picker с кнопками.
        prefetchGlossary(p, function(glossaryText, picker) {
          if (picker) { pushTermPicker(picker); return; }

        // Шаг 1: схема
        loadAppSchema(app, function(schema) {
          var schemaText = formatSchemaForLLM(schema);
          $scope.$applyAsync(function() { $scope.status = "Загружаю данные…"; });

          // Шаг 2: данные через умные агрегации Qlik Engine
          loadQlikData(app, schema, function(cubeResults, mainMeas, secMeas) {
            var dataText = schemaText + "\n\n" + formatDataForLLM(cubeResults, mainMeas, secMeas);

            // Шаг 2.5: автоматические базовые запросы — Count(Distinct) для всех измерений
            // и Sum() для всех мер. Это даёт модели гарантированные числа без угадывания.
            $scope.$applyAsync(function() { $scope.status = "Считаю метрики в движке…"; });
            var autoQueries = [];
            // Только Count(Distinct) для измерений и Sum для мер — без Avg
            // Максимум 6 запросов чтобы экономить токены
            (schema.fields || []).forEach(function(f) {
              if (autoQueries.length >= 6) return;
              if (f.role === "dimension") {
                autoQueries.push({ label: "Кол-во уникальных " + f.name, expr: "Count(Distinct [" + f.name + "])" });
              } else if (f.role === "measure") {
                autoQueries.push({ label: "Итого " + f.name, expr: "Sum([" + f.name + "])" });
              }
            });

            executeSetQueries(enigmaApp, autoQueries, function(autoResults) {
              if (autoResults.length) {
                dataText += "\n\nБАЗОВЫЕ МЕТРИКИ (посчитано автоматически из Qlik Engine):\n";
                autoResults.forEach(function(r) {
                  if (r.value !== "нет данных" && String(r.value).indexOf("ошибка") === -1) {
                    dataText += "• " + r.label + " = " + r.value + "\n";
                  }
                });
              }
              $scope.$applyAsync(function() { $scope.status = "Читаю выборки…"; });

            // Шаг 3: выборки через enigma SelectionObject (одноразовый, не реактивный)
            loadSelections(enigmaApp, function(selText) {
              if (selText) dataText += selText;

              $scope.$applyAsync(function() { $scope.status = "Читаю лист…"; });

              // Шаг 4: объекты листа
              var sheetId = getSheetId();
              loadSheetObjects(app, sheetId, function(sheetObjects) {
                if (sheetObjects.length) {
                  dataText += formatSheetForLLM(sheetObjects);
                }
                // Список объектов созданных через чат — модель может их модифицировать
                if ($scope.createdObjects.length) {
                  dataText += "\n\nСОЗДАННЫЕ ЧЕРЕЗ ЧАТ ОБЪЕКТЫ (МОДИФИЦИРУЙ их, не создавай заново тот же показатель):";
                  $scope.createdObjects.forEach(function(o) {
                    var dims = (o.dimensions || []).filter(Boolean);
                    var meas = o.measureLabel || (o.measures || []).filter(Boolean).join("; ");
                    dataText += "\n• objectId=\"" + o.id + "\" type=" + (o.type || o.chartType || "") + " title=\"" + (o.title || "") + "\""
                      + (dims.length ? (" | измерения=[" + dims.join(", ") + "]") : "")
                      + (meas ? (" | мера=\"" + meas + "\"") : "")
                      + (o.measureLibraryId ? (" libraryId=" + o.measureLibraryId) : "")
                      + (o.topN ? (" | topN=" + o.topN) : "")
                      + (o.glossaryTerm ? (" | из Ataccama: " + o.glossaryTerm) : "");
                  });
                  var lastId = $scope._lastModifiedObjectId || $scope._lastCreatedObjectId;
                  if (lastId) dataText += "\nПОСЛЕДНИЙ созданный/изменённый объект: " + lastId;
                }
                // Защита от превышения лимита токенов: ~40000 токенов ≈ 150000 символов.
                // Локальная модель имеет большое окно контекста, поэтому даём щедрый запас на схему,
                // историю диалога (30 сообщений) и агрегаты.
                var MAX_CONTEXT_CHARS = 150000;
                if (dataText.length > MAX_CONTEXT_CHARS) {
                  dataText = dataText.substring(0, MAX_CONTEXT_CHARS) + "\n\n[контекст обрезан до лимита токенов]";
                  console.warn("[SOLAI] Context truncated to", MAX_CONTEXT_CHARS, "chars");
                }
                console.log("[SOLAI Context] size:", dataText.length, "chars, ~" + Math.round(dataText.length/4) + " tokens, sheet objects:", sheetObjects.length);
                $scope.$applyAsync(function() { $scope.status = "Думает…"; });

                // Шаг 5: вызов модели с историей
                // Авто‑привязка к мастер‑элементам: пробегает suggestions и подставляет
                // libraryId, если имя или выражение совпадает с мастером.
                // Страховка от случая, когда AI вернул инлайн вместо libraryId.
                function autoLinkMasters(s) {
                  var mm = (schema && schema.masterMeasures) || [];
                  var md = (schema && schema.masterDimensions) || [];
                  if (!mm.length && !md.length) return s;

                  function norm(v) { return String(v || "").trim().toLowerCase(); }
                  // Чистит "Sum([X])" / "[X]" / "X" → "x" для сравнения с title мастера
                  function rootName(expr) {
                    var e = String(expr || "").trim();
                    // снять обёртку Sum(...), Count(...), Avg(...)
                    var inner = e.replace(/^\s*(sum|count|avg|min|max)\s*\(\s*(.+)\s*\)\s*$/i, "$2");
                    // снять [ ]
                    inner = inner.replace(/^\[(.+)\]$/, "$1");
                    return norm(inner);
                  }

                  function findMasterMeasure(expr, label) {
                    // 1. По label (как пишет AI: "Продажи", "Маржа")
                    var l = norm(label);
                    if (l) {
                      for (var i = 0; i < mm.length; i++) if (norm(mm[i].title) === l) return mm[i].id;
                      // По "корню" label — снимаем суффиксы вроде ", %", " (KZT)"
                      var lRoot = l.replace(/[\s,]*\(?(%|kzt|млн|тыс|usd|eur|факт|план)[)]?\s*$/i, "").trim();
                      if (lRoot && lRoot !== l) {
                        for (var i = 0; i < mm.length; i++) if (norm(mm[i].title) === lRoot) return mm[i].id;
                      }
                    }
                    // 2. По точному совпадению выражения с master.expr
                    var en = String(expr || "").replace(/\s+/g, "").toLowerCase();
                    if (en) {
                      for (var i = 0; i < mm.length; i++) {
                        var me = String(mm[i].expr || "").replace(/\s+/g, "").toLowerCase();
                        if (me && me === en) return mm[i].id;
                      }
                    }
                    // 3. По «корню» формулы (Sum([Продажи]) → "продажи" → master "Продажи")
                    var r = rootName(expr);
                    if (r) {
                      for (var i = 0; i < mm.length; i++) if (norm(mm[i].title) === r) return mm[i].id;
                    }
                    return "";
                  }
                  function findMasterDim(name) {
                    var n = norm(name);
                    if (!n) return "";
                    for (var i = 0; i < md.length; i++) {
                      if (norm(md[i].title) === n) return md[i].id;
                      var fs = md[i].fields || [];
                      for (var j = 0; j < fs.length; j++) if (norm(fs[j]) === n) return md[i].id;
                    }
                    return "";
                  }

                  // Одиночные
                  if (!s.dimensionLibraryId && s.dimension) {
                    var did = findMasterDim(s.dimension);
                    if (did) { s.dimensionLibraryId = did; console.log("[SOLAI Auto-link] dim '" + s.dimension + "' → " + did); }
                  }
                  if (!s.measureLibraryId && (s.measure || s.measureLabel)) {
                    var mid = findMasterMeasure(s.measure, s.measureLabel);
                    if (mid) { s.measureLibraryId = mid; console.log("[SOLAI Auto-link] meas '" + (s.measureLabel || s.measure) + "' → " + mid); }
                  }
                  if (!s.measureLibraryId2 && (s.measure2 || s.measureLabel2)) {
                    var mid2 = findMasterMeasure(s.measure2, s.measureLabel2);
                    if (mid2) { s.measureLibraryId2 = mid2; console.log("[SOLAI Auto-link] meas2 '" + (s.measureLabel2 || s.measure2) + "' → " + mid2); }
                  }
                  // Метка меры графика. Для МАСТЕР‑меры measure пустой (запрещён промптом),
                  // поэтому подтягиваем её title из схемы по libraryId — он нужен doCreate,
                  // чтобы сортировать измерение по мере через ссылку [Метка].
                  function masterTitleById(id) {
                    for (var i = 0; i < mm.length; i++) if (mm[i].id === id) return mm[i].title || "";
                    return "";
                  }
                  if (s.measureLibraryId && !s.measureLabel) {
                    var _mt = masterTitleById(s.measureLibraryId);
                    if (_mt) { s.measureLabel = _mt; console.log("[SOLAI Auto-link] measureLabel ← master title '" + _mt + "'"); }
                  }
                  // Массивы для table/pivot
                  function autoLinkDimArr(arr) {
                    if (!Array.isArray(arr)) return;
                    arr.forEach(function(d, i) {
                      if (typeof d === "string") {
                        var id = findMasterDim(d);
                        if (id) { arr[i] = { libraryId: id, name: d }; console.log("[SOLAI Auto-link] dim[" + i + "] '" + d + "' → " + id); }
                      } else if (d && typeof d === "object" && !(d.libraryId || d.qLibraryId)) {
                        var id = findMasterDim(d.name || d.field);
                        if (id) { d.libraryId = id; console.log("[SOLAI Auto-link] dim[" + i + "] '" + (d.name || d.field) + "' → " + id); }
                      }
                    });
                  }
                  function autoLinkMeasArr(arr) {
                    if (!Array.isArray(arr)) return;
                    arr.forEach(function(m, i) {
                      if (typeof m === "string") {
                        var id = findMasterMeasure(m, m);
                        if (id) { arr[i] = { libraryId: id }; console.log("[SOLAI Auto-link] meas[" + i + "] '" + m + "' → " + id); }
                      } else if (m && typeof m === "object" && !(m.libraryId || m.qLibraryId)) {
                        var id = findMasterMeasure(m.expr || m.measure, m.label || m.measureLabel);
                        if (id) { m.libraryId = id; console.log("[SOLAI Auto-link] meas[" + i + "] '" + (m.label || m.expr) + "' → " + id); }
                      }
                    });
                  }
                  autoLinkDimArr(s.dimensions);
                  autoLinkDimArr(s.rowFields);
                  autoLinkDimArr(s.colFields);
                  autoLinkMeasArr(s.measures);
                  return s;
                }

                function applyLLMResult(result, rawJson) {
                  $scope.$applyAsync(function() {
                    $scope.loading = false;
                    $scope.status = "";

                    console.log("[SOLAI LLM raw suggestions]:", JSON.stringify(result.suggestions));

                    // ── ВАЛИДАЦИЯ ПОЛЕЙ в suggestions/modify (авто-фикс однозначных) ──
                    // Чтобы созданные графики/таблицы тоже не ссылались на несуществующее поле.
                    (function() {
                      var idx = buildFieldIndex(schema);
                      if (!idx.names.length) return;
                      function fix(s) {
                        if (!s) return s;
                        var v = validateExprFields(s, idx);
                        if (v.corrections.length) console.log("[SOLAI FieldFix] suggestion/modify:", JSON.stringify(v.corrections));
                        return v.expr;
                      }
                      function fixArr(a) { return (a || []).map(function(x){ return (typeof x === "string") ? fix(x) : x; }); }
                      (result.suggestions || []).forEach(function(s) {
                        if (!s) return;
                        if (s.measure)    s.measure    = fix(s.measure);
                        if (s.measure2)   s.measure2   = fix(s.measure2);
                        if (s.dimension)  s.dimension  = fix(s.dimension);
                        if (s.dimension2) s.dimension2 = fix(s.dimension2);
                        if (s.dimensions) s.dimensions = fixArr(s.dimensions);
                        if (s.rowFields)  s.rowFields  = fixArr(s.rowFields);
                        if (s.colFields)  s.colFields  = fixArr(s.colFields);
                        if (s.measures)   s.measures   = (s.measures || []).map(function(m){
                          if (typeof m === "string") return fix(m);
                          if (m && m.expr) m.expr = fix(m.expr);
                          return m;
                        });
                        if (s.colorExpression) s.colorExpression = fix(s.colorExpression);
                      });
                      if (result.modify) {
                        var md = result.modify;
                        if (md.addMeasures)    md.addMeasures    = (md.addMeasures || []).map(function(m){ if (m && m.expr) m.expr = fix(m.expr); return m; });
                        if (md.addDimensions)  md.addDimensions  = fixArr(md.addDimensions);
                        if (md.changeMeasures) md.changeMeasures = (md.changeMeasures || []).map(function(c){ if (c && c["new"]) c["new"] = fix(c["new"]); return c; });
                        if (md.setColorExpression) md.setColorExpression = fix(md.setColorExpression);
                      }
                    })();

                    // ── ЗАЩИТА ОТ САМОПОКРАШИВАНИЯ ─────────────────────────
                    // Если в последнем сообщении пользователя НЕТ слов про цвет —
                    // выкидываем colorExpression из всех suggestions, даже если AI его добавил.
                    var lastUserMsg = "";
                    for (var ii = $scope.messages.length - 1; ii >= 0; ii--) {
                      if ($scope.messages[ii].role === "user") {
                        lastUserMsg = String($scope.messages[ii].content || "").toLowerCase();
                        break;
                      }
                    }
                    var colorIntent = /покрас|раскрас|закрас|крась|красит|выдели\s*цвет|подсвети|отмечай\s*цвет|зелён|зелен|красн|син[еи]|жёлт|жолт|оранж|фиолет|цвет|расцветк|градиент|gradient|залей|залить|залив|заливк|тепл\w*\s*карт|heatmap|фон\s*ячее?к|цвет\s*фона|разные\s+цвета|разными\s+цвета|по\s+знаку|отрицательн.+красн|положительн.+зелен/i.test(lastUserMsg);
                    console.log("[SOLAI ColorGuard] scan last user msg:",
                                "\"" + lastUserMsg.substring(0, 100) + "\"",
                                "→ colorIntent:", colorIntent);
                    if (!colorIntent) {
                      (result.suggestions || []).forEach(function(s) {
                        if (s && s.colorExpression) {
                          console.log("[SOLAI ColorGuard] stripped colorExpression — user did NOT request colors:", String(s.colorExpression).substring(0, 60));
                          delete s.colorExpression;
                          delete s.colorLabel;
                        }
                      });
                      // Также для modify
                      if (result.modify && result.modify.setColorExpression !== undefined) {
                        console.log("[SOLAI ColorGuard] stripped setColorExpression from modify — user did NOT request colors");
                        delete result.modify.setColorExpression;
                        delete result.modify.setColorLabel;
                      }
                    } else {
                      console.log("[SOLAI ColorGuard] user requested colors — colorExpression allowed");
                    }

                    // ── SignGuard: *-1 оставляем, если просили / определение требует / поле уже узаконено ──
                    var _turnAllowSign = userWantsSignFlip(lastUserMsg) || definitionWantsSignFlip(currentGlossaryDefText());
                    var _keptAnySign = false;
                    var _procMeas = function(expr){
                      if (!expr) return expr;
                      var r = stripSignMul(expr);
                      if (!r.stripped) return expr;                                   // нет *-1 — не трогаем
                      if (_turnAllowSign || _exprUsesSignFlipField(expr)) {           // знак узаконен
                        _recordSignFlipFields(expr); _keptAnySign = true; return expr;
                      }
                      console.warn("[SOLAI SignGuard] срезан самовольный *-1:", String(expr).slice(0,80));
                      return r.expr;
                    };
                    (result.suggestions || []).forEach(function(s){
                      if (!s) return;
                      if (s.measure)  s.measure  = _procMeas(s.measure);
                      if (s.measure2) s.measure2 = _procMeas(s.measure2);
                      if (s.measures) s.measures = (s.measures||[]).map(function(m){ if (typeof m==="string") return _procMeas(m); if (m && m.expr) m.expr = _procMeas(m.expr); return m; });
                    });
                    if (result.modify) {
                      var _md = result.modify;
                      if (_md.addMeasures)    _md.addMeasures    = (_md.addMeasures||[]).map(function(m){ if (m && m.expr) m.expr = _procMeas(m.expr); return m; });
                      if (_md.changeMeasures) _md.changeMeasures = (_md.changeMeasures||[]).map(function(c){ if (c && c["new"]) c["new"] = _procMeas(c["new"]); return c; });
                    }
                    // текст: чистим упоминание -1 только если в этом ходу мы НИЧЕГО не оставили со знаком
                    if (!_turnAllowSign && !_keptAnySign) {
                      var _cleanA = scrubSignText(result.analysis);
                      if (_cleanA !== result.analysis) { console.warn("[SOLAI SignGuard] вычищено упоминание *-1 из текста ответа"); result.analysis = _cleanA; }
                    }

                    // ── AddGuard: «добавь поле» = НОВАЯ колонка (add*), а не замена (change*) ──
                    if (result.modify && userWantsAddField(lastUserMsg)) {
                      var _am = result.modify;
                      if (_am.changeMeasures && _am.changeMeasures.length && (!_am.addMeasures || !_am.addMeasures.length)) {
                        _am.addMeasures = _am.changeMeasures.map(function(c){ return { expr: c["new"] || c.expr || "", label: c.label || "" }; });
                        delete _am.changeMeasures;
                        console.warn("[SOLAI AddGuard] changeMeasures → addMeasures (пользователь просил ДОБАВИТЬ поле, не заменять)");
                      }
                      if (_am.changeDimensions && _am.changeDimensions.length && (!_am.addDimensions || !_am.addDimensions.length)) {
                        _am.addDimensions = _am.changeDimensions.map(function(c){ return c["new"] || c; });
                        delete _am.changeDimensions;
                        console.warn("[SOLAI AddGuard] changeDimensions → addDimensions");
                      }
                    }

                    (result.suggestions || []).forEach(autoLinkMasters);
                    var suggestions = (result.suggestions || []).map(function(s) {
                      var ct = CHART_TYPES[s.chartType] || { icon: "", title: s.chartType };
                      console.log("[SOLAI] suggestion:", s.chartType, "topN:", s.topN, "title:", s.title);
                      return {
                        chartType:     s.chartType,
                        dimension:     s.dimension || "",
                        dimension2:    s.dimension2 || "",  // второе измерение для linechart (серии/группы)
                        dimensions:    s.dimensions || [],
                        measure:       s.measure || "",
                        measure2:      s.measure2 || "",
                        measures:      s.measures || [],
                        measureLabel:  s.measureLabel || s.measure || "",
                        measureLabel2: s.measureLabel2 || s.measure2 || "",
                        // Ссылки на мастер‑элементы библиотеки (приоритет над инлайн‑формулами)
                        dimensionLibraryId:  s.dimensionLibraryId  || "",
                        dimensionLibraryId2: s.dimensionLibraryId2 || "",
                        measureLibraryId:    s.measureLibraryId    || "",
                        measureLibraryId2:   s.measureLibraryId2   || "",
                        title:         s.title || s.dimension || "",
                        reason:        s.reason || "",
                        icon:          ct.icon,
                        sortDesc:      s.sortDesc !== false,
                        topN:          s.topN || 0,
                        rowFields:       s.rowFields || [],
                        colFields:       s.colFields || [],
                        totalDimension:  s.totalDimension || null,
                        orientation:     s.orientation || "",  // "vertical" | "horizontal" — для barchart/combochart
                        colorExpression: s.colorExpression || "",  // Qlik цветовое выражение (HEX/ARGB)
                        colorLabel:      s.colorLabel || "",
                        creating:      false,
                        done:          false
                      };
                    });

                    // Дословная подстановка определения Ataccama КОДОМ (модель его сокращает):
                    // если на этом ходу подмешан термин — ставим Business definition как есть ПЕРЕД ответом.
                    (function() {
                      var defTxt = currentGlossaryDescription();
                      if (!defTxt || !defTxt.trim()) return;
                      var a = String(result.analysis || "");
                      // убрать блок «Определение…», если модель его всё же добавила (до «Реализация»/«Результат»)
                      a = a.replace(/^\s*\*{0,2}\s*определени[ея][\s\S]*?(?=\*{0,2}\s*(реализаци|результат))/i, "").trim();
                      result.analysis = "**Определение (из Ataccama):**\n" + defTxt.trim() + "\n\n" + a;
                    })();

                    $scope.messages.push({
                      role:        "assistant",
                      content:     result.analysis || "",
                      rawJson:     rawJson,
                      suggestions: suggestions,
                      fieldChips:  result.fieldChips || [],
                      actionChips: result.actionChips || []   // кнопки-действия (напр. умножить на -1)
                    });

                    saveHistory();
                    scrollToBottom();

                    // Если ответ строит таблицу/график — проверить меры на отрицательные и предложить кнопки.
                    checkSuggestionNegatives($scope.messages[$scope.messages.length - 1], suggestions);

                    // Обработка модификации объекта
                    if (result.modify && result.modify.objectId) {
                      console.log("[SOLAI Modify] objectId:", result.modify.objectId, JSON.stringify(result.modify));
                      doModify(enigmaApp, result.modify,
                        function(objId) {
                          $scope.$applyAsync(function() {
                            // Реестр не должен устаревать: помечаем последний изменённый объект и
                            // освежаем его спеку (topN/добавленные меры) — чтобы следующий follow-up видел актуальное.
                            $scope._lastModifiedObjectId = result.modify.objectId;
                            var rec = ($scope.createdObjects || []).filter(function(o){ return o.id === result.modify.objectId; })[0];
                            if (rec) {
                              if (typeof result.modify.setTopN === "number") rec.topN = result.modify.setTopN;
                              if (result.modify.addMeasures && result.modify.addMeasures.length) {
                                rec.measures = (rec.measures || []).concat(result.modify.addMeasures.map(function(m){ return m.expr || m; }));
                              }
                              if (result.modify.addDimensions && result.modify.addDimensions.length) {
                                rec.dimensions = (rec.dimensions || []).concat(result.modify.addDimensions);
                              }
                            }
                            var lastMsg = $scope.messages[$scope.messages.length - 1];
                            if (lastMsg && lastMsg.role === "assistant") {
                              lastMsg.content = (lastMsg.content || "") + "\n\n[Объект обновлён]";
                            }
                            saveHistory();
                            scrollToBottom();
                          });
                        },
                        function(err) {
                          $scope.$applyAsync(function() {
                            $scope.messages.push({ role: "error", content: "Ошибка модификации: " + err, suggestions: [], fieldChips: [] });
                            saveHistory();
                            scrollToBottom();
                          });
                        }
                      );
                    }

                    // Обработка снятия выборок (после согласия пользователя в диалоге)
                    if (result.clearSelections && (result.clearSelections.all || (result.clearSelections.fields && result.clearSelections.fields.length))) {
                      console.log("[SOLAI ClearSelections]", JSON.stringify(result.clearSelections));
                      clearQlikSelections(enigmaApp, result.clearSelections,
                        function(clearedList) {
                          $scope.$applyAsync(function() {
                            var lastMsg = $scope.messages[$scope.messages.length - 1];
                            if (lastMsg && lastMsg.role === "assistant") {
                              lastMsg.content = (lastMsg.content || "") + "\n\n[Снято: " + clearedList.join(", ") + "]";
                            }
                            saveHistory();
                            scrollToBottom();
                            // Авто-перезапуск анализа с актуальными данными
                            $scope.prompt = "Выборки сняты. Проведи полный анализ с актуальными данными и дай заключение по новой картине.";
                            $scope.sendMessage();
                          });
                        },
                        function(err) {
                          $scope.$applyAsync(function() {
                            $scope.messages.push({ role: "error", content: "Не удалось снять выборки: " + err, suggestions: [], fieldChips: [] });
                            saveHistory();
                            scrollToBottom();
                          });
                        }
                      );
                    }
                  });
                }

                function onLLMError(err) {
                  $scope.$applyAsync(function() {
                    $scope.loading = false;
                    $scope.status = "";
                    $scope.messages.push({ role: "error", content: err });
                    saveHistory();
                    scrollToBottom();
                  });
                }

                var solaiSector  = $scope.solai.sector || "general";
                var solaiCompany = $scope.solai.companyName || "";

                // Подмешиваем определение из справочника Ataccama (если получено в шаге 0).
                // Добавляем ПОСЛЕ обрезки по лимиту — определение короткое и должно дойти целиком.
                if (glossaryText) dataText += glossaryText;

                $scope._abortCtl = callLLM(API_KEY, $scope.messages, dataText, solaiSector, solaiCompany,
                  function(result, rawJson) {
                    if ($scope._stopped) return;   // пользователь нажал «Стоп» — не рендерим поздний ответ
                    var hasSet  = result.queries && result.queries.length;
                    var hasRank = result.rankQueries && result.rankQueries.length;
                    // Если модель вернула queries[] и/или rankQueries[] — считаем в движке
                    if (hasSet || hasRank) {
                      console.log("[SOLAI] Уточнение в движке — queries:", (result.queries || []).length, "| rankQueries:", (result.rankQueries || []).length);
                      $scope.$applyAsync(function() { $scope.status = "Уточняю данные в движке…"; });

                      // ВАЛИДАЦИЯ ПОЛЕЙ ПО МОДЕЛИ: авто-исправляем однозначные опечатки/обрезки имён
                      // полей в формулах (saldo_out_sum_nat → saldo_out_sum_nat_end); неизвестные
                      // собираем, чтобы НЕ выдать неверное число (честно скажем «поле не найдено»).
                      var fieldIdx = buildFieldIndex(schema);
                      var unknownFields = [];
                      // Знак не просили в этом сообщении → срезаем самовольный *-1.
                      var _luSign = "";
                      for (var _si = $scope.messages.length - 1; _si >= 0; _si--) { if ($scope.messages[_si].role === "user") { _luSign = String($scope.messages[_si].content || ""); break; } }
                      // Знак разрешён, если просили в сообщении ИЛИ определение Ataccama явно требует ×(-1).
                      var allowSign = userWantsSignFlip(_luSign) || definitionWantsSignFlip(currentGlossaryDefText());
                      if (allowSign) console.log("[SOLAI SignGuard] *-1 РАЗРЕШЁН (просьба или определение Ataccama)");
                      function fixExpr(expr, label, kind) {
                        var v = validateExprFields(expr, fieldIdx);
                        if (v.corrections.length) console.log("[SOLAI FieldFix] " + kind + " «" + (label||"") + "»:", JSON.stringify(v.corrections));
                        if (v.unknown.length) unknownFields = unknownFields.concat(v.unknown);
                        var e = v.expr;
                        var sg = stripSignMul(e);
                        if (sg.stripped) {
                          if (allowSign || _exprUsesSignFlipField(e)) { _recordSignFlipFields(e); } // знак узаконен — оставляем + запоминаем поле
                          else { console.warn("[SOLAI SignGuard] срезан самовольный *-1 в " + kind + " «" + (label||"") + "»"); e = sg.expr; }
                        }
                        return e;
                      }
                      (result.queries || []).forEach(function(q) { q.expr = fixExpr(q.expr, q.label, "query"); });
                      (result.rankQueries || []).forEach(function(q) {
                        q.measure = fixExpr(q.measure, q.label, "rankQuery");
                        var vd = validateExprFields(q.dim, fieldIdx); if (vd.unknown.length) unknownFields = unknownFields.concat(vd.unknown); q.dim = vd.expr;
                      });
                      unknownFields = unknownFields.filter(function(x,i){ return x && unknownFields.indexOf(x) === i; });

                      executeSetQueries(enigmaApp, result.queries || [], function(queryResults) {
                       executeRankQueries(enigmaApp, result.rankQueries || [], function(rankResults) {
                        var queryText = "";
                        if (queryResults.length) {
                          queryText += "\n\n═══════════════════════════════════════════════════\n";
                          queryText += "ТОЧНЫЕ РЕЗУЛЬТАТЫ ИЗ QLIK ENGINE (только что посчитано):\n";
                          queryText += "═══════════════════════════════════════════════════\n";
                          queryResults.forEach(function(r) {
                            queryText += "• " + r.label + " = " + r.value + "\n";
                          });
                          queryText += "═══════════════════════════════════════════════════\n";
                          queryText += "ИНСТРУКЦИЯ: используй эти числа в analysis. Дай прямой ответ с конкретным числом.\n";
                        }
                        if (rankResults.length) {
                          queryText += "\n\n═══════════════════════════════════════════════════\n";
                          queryText += "РАНЖИРОВАННЫЕ РЕЗУЛЬТАТЫ — ДВИЖОК ОТСОРТИРОВАЛ (это ИСТИНА, НЕ снапшот листа):\n";
                          queryText += "═══════════════════════════════════════════════════\n";
                          rankResults.forEach(function(r) {
                            var dir = (r.order === "asc") ? "по возрастанию (меньше всего сверху)" : "по убыванию (больше всего сверху)";
                            queryText += "▸ " + (r.label || "Рейтинг") + " — " + dir + ", топ " + r.n + ":\n";
                            if (r.error) { queryText += "   (ошибка движка: " + r.error + ")\n"; }
                            else if (!r.rows.length) { queryText += "   (нет данных — проверь измерение/меру или выборку)\n"; }
                            else {
                              r.rows.forEach(function(row, i) {
                                queryText += "   " + (i + 1) + ". " + row.entity + " — " + (row.valueText || row.value) + "\n";
                              });
                            }
                          });
                          queryText += "═══════════════════════════════════════════════════\n";
                          queryText += "ИНСТРУКЦИЯ: ответь СТРОГО из этого рейтинга — явно назови №1 и приведи топ-5. " +
                                       "Имена/цифры бери ТОЛЬКО отсюда, НЕ из снапшота листа. ОБЯЗАТЕЛЬНО добавь barchart " +
                                       "с тем же измерением и мерой, sortDesc по этому порядку, topN — как в рейтинге.\n";
                        }
                        if (unknownFields.length) {
                          queryText += "\n\n⚠ ПОЛЯ НЕ НАЙДЕНЫ В МОДЕЛИ ДАННЫХ: " + unknownFields.map(function(f){ return "[" + f + "]"; }).join(", ") + "\n";
                          queryText += "ИНСТРУКЦИЯ: таких полей в модели НЕТ — НЕ выдавай по ним число и НЕ выдумывай формулу. " +
                                       "Честно скажи пользователю, что поле не найдено, перечисли похожие поля из модели данных и попроси уточнить. " +
                                       "Лучше честный ответ «поле не найдено», чем неверный показатель.\n";
                        }

                        // ── ДЕТЕКТ ОТРИЦАТЕЛЬНЫХ ЗНАЧЕНИЙ (после применённой выборки) ──
                        // Знак зависит от выбранного аналитического счёта (CR/пассив → остатки бывают
                        // минусовыми). НЕ переворачиваем сами — предупреждаем и предлагаем *-1 по подтверждению.
                        var nums = [];
                        (queryResults || []).forEach(function(r){ if (typeof r.num === "number" && !isNaN(r.num)) nums.push(r.num); });
                        (rankResults || []).forEach(function(r){ (r.rows || []).forEach(function(row){ if (typeof row.value === "number" && !isNaN(row.value)) nums.push(row.value); }); });
                        var hasNeg = nums.some(function(n){ return n < 0; });
                        var hasPos = nums.some(function(n){ return n > 0; });
                        if (hasNeg) {
                          queryText += "\n\n⚠ В РЕЗУЛЬТАТЕ ЕСТЬ ОТРИЦАТЕЛЬНЫЕ ЗНАЧЕНИЯ" + (hasPos ? " (и положительные — знаки смешаны)" : "") + ".\n";
                          queryText += "ИНСТРУКЦИЯ: показывай число КАК ЕСТЬ (НЕ умножай на -1 сам — знак из определения/счёта верен). "
                                     + "КОРОТКО предупреди, что значения отрицательные, т.к. знак зависит от типа аналитического счёта "
                                     + "(для CR/пассивных остатки часто минусовые). Выбор действия пользователь сделает кнопками внизу — НЕ дублируй их текстом.\n";
                        }
                        console.log("[SOLAI Engine results]:", queryText);

                        $scope.$applyAsync(function() { $scope.status = "Финализирует ответ…"; });
                        if ($scope._stopped) return;   // остановлено во время расчёта в движке
                        // Второй вызов модели с точными данными из движка
                        $scope._abortCtl = callLLM(API_KEY, $scope.messages, dataText + queryText, solaiSector, solaiCompany,
                          function(result2, rawJson2) {
                            if ($scope._stopped) return;   // не рендерим поздний ответ после «Стоп»
                            // Если в фактических данных есть минус — снизу даём кнопки выбора знака.
                            if (hasNeg && (!result2.actionChips || !result2.actionChips.length)) {
                              result2.actionChips = [
                                { label: "Умножить на −1", send: "Умножь этот показатель на -1 и покажи положительным" },
                                { label: "Оставить как есть", send: "Оставь как есть, знак не меняй" }
                              ];
                            }
                            applyLLMResult(result2, rawJson2);
                          },
                          onLLMError
                        );
                       }); // executeRankQueries
                      }); // executeSetQueries
                    } else {
                      applyLLMResult(result, rawJson);
                    }
                  },
                  onLLMError
                );
              }); // loadSheetObjects
            }); // loadSelections
            }); // executeSetQueries (шаг 2.5)
          },
          function(err) {
            $scope.$applyAsync(function() {
              $scope.loading = false;
              $scope.status = "";
              $scope.messages.push({ role: "error", content: "Данные: " + err });
              saveHistory();
            });
          });
        },
        function(err) {
          $scope.$applyAsync(function() {
            $scope.loading = false;
            $scope.status = "";
            $scope.messages.push({ role: "error", content: "Схема: " + err });
            saveHistory();
          });
        });
        }); // prefetchGlossary (шаг 0)
      };

      // ── Создать график ────────────────────────────────────────────────────
      $scope.createChart = function(msg, suggestion) {
        var sheetId = getSheetId();
        if (!sheetId) {
          $scope.messages.push({ role: "error", content: "ID листа не найден" });
          saveHistory(); return;
        }

        // Сброс флагов — для повторного клика из состояния "completed"
        suggestion.done = false;
        suggestion.completed = false;
        suggestion.creating = true;

        doCreate(app, enigmaApp, sheetId, suggestion,
          function(newId, pos) {
            $scope.$applyAsync(function() {
              suggestion.creating = false;
              suggestion.done = true;
              $scope.createdObjects.push({
                id: newId,
                title: suggestion.title || "",
                type: suggestion.chartType || "",
                chartType: suggestion.chartType || "",
                dimensions: (suggestion.dimensions && suggestion.dimensions.length) ? suggestion.dimensions : [suggestion.dimension].filter(Boolean),
                measures: (suggestion.measures && suggestion.measures.length) ? suggestion.measures : [suggestion.measure].filter(Boolean),
                measureLabel: suggestion.measureLabel || "",
                measureLibraryId: suggestion.measureLibraryId || "",
                topN: suggestion.topN || 0,
                glossaryTerm: $scope._lastGlossaryTermName || ""   // связь с термином Ataccama (если был)
              });
              suggestion.createdObjectId = newId;       // связь suggestion → объект (видно в prior_built истории)
              $scope._lastCreatedObjectId = newId;
              saveHistory();
              // Через 2.5 сек: зелёный квадрат → белый с иконкой повтора
              $timeout(function() {
                suggestion.done = false;
                suggestion.completed = true;
                saveHistory();
              }, 2500);
            });
          },
          function(e) {
            $scope.$applyAsync(function() {
              suggestion.creating = false;
              $scope.messages.push({ role: "error", content: "Ошибка: " + e });
              saveHistory();
            });
          }
        );
      };

      scrollToBottom();
    }],

    paint: function($element, layout) {
      var scope = angular.element($element[0]).scope();
      if (scope) scope.layout = layout;

      // Убираем границы/фон контейнера Qlik (.qv-object) — кнопка AI без рамок
      var el = $element[0];
      while (el && el !== document.body) {
        el = el.parentElement;
        if (el && el.classList && (el.classList.contains("qv-object") || el.classList.contains("qv-inner-object"))) {
          el.style.border = "none";
          el.style.boxShadow = "none";
          el.style.background = "transparent";
        }
      }

      return qlik.Promise.resolve();
    }
  };
});