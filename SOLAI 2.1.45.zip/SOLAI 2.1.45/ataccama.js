/* 
 * Что делает модуль:
 *   1) OAuth2 client_credentials в Keycloak (realm ataccamaone) → Bearer-токен
 *   2) GraphQL-запрос терминов бизнес-глоссария
 *   3) маппинг ответа в [{gid, name, description}] и поиск термина в тексте вопроса
 *
 * Двойной запуск (UMD):
 *   • в Qlik Sense — грузится через RequireJS как define(["./ataccama"], ...)
 *   • для проверки админами без Qlik — открыть страницу того же origin, F12 →
 *     Console, вставить этот файл, затем:
 *         Ataccama.test();                  // токен + список терминов
 *         Ataccama.test("активный клиент"); // + поиск конкретного термина
 *     (то же самое доступно как window.solaiTestAtaccama(...) — для обратной совместимости)
*/
(function (root, factory) {
  "use strict";
  if (typeof define === "function" && define.amd) {
    define([], factory);                 // Qlik Sense / RequireJS
  } else {
    var mod = factory();
    root.Ataccama = mod;                 // браузерная консоль / standalone
    if (typeof module !== "undefined" && module.exports) module.exports = mod; // Node/CommonJS
  }
}(typeof window !== "undefined" ? window : this, function () {
  "use strict";

  // ── Конфигурация подключения ───────────────────────────────────────────────
  // Это всё, что нужно согласовать с админами Ataccama/Keycloak.
  var CONFIG = {
    ENABLED:       true,
    TOKEN_URL:     "https://one.dcp.halykbank.nb/auth/realms/ataccamaone/protocol/openid-connect/token",
    GRAPHQL_URL:   "https://one.dcp.halykbank.nb/graphql",
    CLIENT_ID:     "ataccama-qlik-client",
    CLIENT_SECRET: "dQvhcbfMLV1WsidbNkE2CZ5fDoh42B5o",
    // Метод передачи учётки клиента в Keycloak (см. Postman у админов — там стоит
    // "Send as Basic Auth header"):
    //   "basic" — Authorization: Basic base64(client_id:client_secret)  ← как в Postman
    //   "body"  — client_id/client_secret в теле запроса (старый вариант)
    // Если получишь 401 invalid_client — переключи на другой режим.
    CLIENT_AUTH:   "basic",
    // Источник ПОЛЕЙ и ФИЛЬТРОВ для Set Analysis.
    //   true (с v2.1.41) — SQL technicalDescription = ИСТОЧНИК ИСТИНЫ для полей/фильтров;
    //     Business-описание идёт в КОНТЕКСТ (смысл показателя, выбор визуализации).
    //     См. спек «Логика построения Set Analysis из SQL (Ataccama).md».
    //   false — старое поведение: поля/фильтры из человеческого Business-описания.
    USE_TECHNICAL: true,
    GLOSSARY_TTL:  10 * 60 * 1000 // кэш списка терминов — 10 минут
  };

  // base64 (для Basic-заголовка): браузер → btoa, Node → Buffer.
  function _b64(s) {
    if (typeof btoa === "function") return btoa(s);
    if (typeof Buffer !== "undefined") return Buffer.from(s, "utf8").toString("base64");
    return s;
  }

  // GraphQL-запросы глоссария — именно их SOLAI шлёт на /graphql.
  // Тянем ДВА поля определения:
  //   • description          — человеческое объяснение (какое поле/условия для выборок).
  //     ПРИОРИТЕТНОЕ: его обычно достаточно, чтобы собрать Set-анализ в Qlik.
  //   • technicalDescription — технический фильтр (warehouse-SQL), запасной вариант.
  // Оба могут приходить как rich-text JSON → чистятся через richTextToPlain.
  // versionSelector = draftVersion:true — СУПЕРМНОЖЕСТВО всех рабочих терминов (включая
  // ещё не опубликованные). publishedVersion возвращает ТОЛЬКО опубликованные → новые/
  // черновые термины (как «Остаток ОД по ФЛ») терялись, и SOLAI цеплял общий «Кредит».
  // Поле-аксессор draftVersion{...} — проверенная комбинация.
  // FULL запрашивает оба поля; если description в инсталляции отсутствует и запрос
  // упадёт — FALLBACK тянет подтверждённо рабочий набор name+technicalDescription.
  // BIZ — приоритетная попытка: «Business definition» — это ОТДЕЛЬНОЕ поле (как и
  // technicalDescription). В UI под «Description» два поля: Business definition (человеческий
  // текст) и Technical description (SQL). Пробуем поле businessDefinition; если его нет в схеме —
  // GraphQL вернёт errors, и мы откатимся на FULL (description) → NAMES.
  var GQL_TERMS_BIZ =
    "query SolaiGlossaryBiz { terms(versionSelector:{draftVersion:true}) " +
    "{ edges { node { gid draftVersion { name businessDefinition description technicalDescription } } } } }";
  var GQL_TERMS_FULL =
    "query SolaiGlossary { terms(versionSelector:{draftVersion:true}) " +
    "{ edges { node { gid draftVersion { name description technicalDescription } } } } }";
  var GQL_TERMS_NAMES =
    "query SolaiGlossaryFallback { terms(versionSelector:{draftVersion:true}) " +
    "{ edges { node { gid draftVersion { name technicalDescription } } } } }";

  // ── Состояние (кэш токена и глоссария + диагностика) ────────────────────────
  var _token          = null; // { value, expiresAt(ms) }
  var _glossary       = null; // { terms:[{gid,name,description}], fetchedAt(ms) }
  var _authMethodUsed = null; // "basic"|"body" — метод, которым РЕАЛЬНО получен токен
  var _lastTokenError = null; // { kind:"network"|"auth"|"http"|"other", status, message }
  var _descFields     = null; // имена полей описания, найденные интроспекцией схемы (порядок приоритета)

  // Похоже ли значение на SQL (чтобы НЕ показывать SQL как человеческое описание).
  function _looksLikeSql(t) {
    var s = String(t || "");
    return /\bselect\b[\s\S]{0,6000}\bfrom\b/i.test(s) || /^\s*(select|with|на\s+dds)\b/i.test(s);
  }

  // Классификация ошибки запроса — чтобы отчёт мог ответить на вопросы админов:
  //   network → браузер не пустил (CORS/сеть);  auth → 401/invalid_client;
  //   http → иной HTTP-ответ сервера;            other → прочее.
  function _classifyError(message, status) {
    var e = (message || "").toLowerCase();
    if (e.indexOf("failed to fetch") !== -1 || e.indexOf("networkerror") !== -1 || e.indexOf("load failed") !== -1)
      return "network";
    if (status === 401 || e.indexOf("invalid_client") !== -1 || e.indexOf("unauthorized") !== -1 || e.indexOf("401") !== -1)
      return "auth";
    if (status) return "http";
    return "other";
  }

  // ── Нормализация текста (для поиска термина в вопросе) ──────────────────────
  function normalizeQuestion(q) {
    return (q || "")
      .toLowerCase()
      .replace(/[^\wа-яё\s]/gi, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  // ── Триггер: пользователь явно просит использовать справочник/глоссарий ──────
  function shouldUse(text) {
    return /ataccama|атакам|глоссари|справочник|словар|methodolog|методолог/i.test(text || "");
  }

  // ── Команда диагностики прямо из чата (чтобы видеть лог без консоли F12) ──────
  //   /ataccama                 — проверить токен + список терминов
  //   /ataccama активный клиент — + найти конкретный термин
  //   "проверь ataccama" / "тест справочника" — тоже сработает.
  function isDiagCommand(text) {
    var t = (text || "").toLowerCase().trim();
    if (/^\/ataccama\b/.test(t)) return true;
    return /(тест|проверь|проверк|диагност|diag|debug|лог|log)/.test(t)
        && /(ataccama|атакам|справочник|глоссар)/.test(t);
  }

  // ── Подсказка по тексту ошибки (CORS / неверный клиент / схема GraphQL) ──────
  function errorHint(err) {
    var e = (err || "").toLowerCase();
    if (e.indexOf("failed to fetch") !== -1 || e.indexOf("networkerror") !== -1 || e.indexOf("load failed") !== -1)
      return "ⓘ Похоже на CORS/сеть: браузер не пустил запрос (детали CORS видны только в F12). " +
             "Нужно разрешить origin Qlik Sense на стороне Ataccama/Keycloak (Web Origins у клиента " +
             CONFIG.CLIENT_ID + "), либо проверить доступность хоста и сертификат.";
    if (e.indexOf("401") !== -1 || e.indexOf("invalid_client") !== -1 || e.indexOf("unauthorized") !== -1)
      return "ⓘ Неверные client_id/secret, либо в Keycloak у клиента не включены Service Accounts.";
    if (e.indexOf("description") !== -1 || e.indexOf("graphql") !== -1)
      return "ⓘ GraphQL принял токен, но поле/запрос не совпали со схемой. Выверить имена полей в плейграунде " +
             "one.dcp.halykbank.nb/playground.";
    return "";
  }

  // ── 1) OAuth2 client_credentials → Bearer-токен ─────────────────────────────
  // Внутр.: один запрос токена выбранным методом аутентификации.
  //   onOk(token, method);  onFail(message, kind, status, method)
  function _requestToken(method, onOk, onFail) {
    var headers = { "Content-Type": "application/x-www-form-urlencoded" };
    var body = "grant_type=client_credentials";
    if (method === "basic") {
      // client_secret_basic — как в проверенном админами Postman (Basic Auth header).
      headers["Authorization"] = "Basic " + _b64(CONFIG.CLIENT_ID + ":" + CONFIG.CLIENT_SECRET);
    } else {
      // client_secret_post — учётка в теле запроса.
      body += "&client_id=" + encodeURIComponent(CONFIG.CLIENT_ID) +
              "&client_secret=" + encodeURIComponent(CONFIG.CLIENT_SECRET);
    }
    fetch(CONFIG.TOKEN_URL, { method: "POST", headers: headers, body: body })
      .then(function (resp) {
        return resp.json().then(function (data) {
          if (!resp.ok || !data.access_token) {
            var msg = "токен " + resp.status + ": " + (data.error_description || data.error || "нет access_token");
            onFail(msg, _classifyError(msg, resp.status), resp.status, method);
            return;
          }
          var ttl = (parseInt(data.expires_in, 10) || 300) * 1000;
          _token = { value: data.access_token, expiresAt: Date.now() + ttl };
          _authMethodUsed = method; _lastTokenError = null;
          console.log("[SOLAI Ataccama] токен получен методом", method, "| TTL(сек):", parseInt(data.expires_in, 10) || 300);
          onOk(data.access_token, method);
        });
      })
      .catch(function (e) {
        var msg = "токен: " + (e.message || e);
        onFail(msg, _classifyError(msg, 0), 0, method);
      });
  }

  // Публичный: токен с кэшем (по expires_in) и АВТО-ФОЛБЭКОМ метода аутентификации.
  // Если основной метод (CONFIG.CLIENT_AUTH) отклонён по авторизации (401/invalid_client)
  // — пробуем второй и запоминаем рабочий (см. authMethodUsed()). На сетевой ошибке
  // (CORS) фолбэка нет: второй метод тоже не пройдёт, дело не в методе.
  function getToken(onSuccess, onError) {
    var now = Date.now();
    if (_token && _token.expiresAt > now + 5000) {
      onSuccess(_token.value, _authMethodUsed); return;
    }
    var primary = CONFIG.CLIENT_AUTH === "body" ? "body" : "basic";
    _requestToken(primary, onSuccess, function (msg, kind, status) {
      if (kind === "auth") {
        var alt = primary === "basic" ? "body" : "basic";
        console.warn("[SOLAI Ataccama] метод", primary, "отклонён по авторизации — пробую", alt);
        _requestToken(alt, onSuccess, function (msg2, kind2, status2) {
          _lastTokenError = { kind: kind2, status: status2, message: msg2 };
          onError(msg2);
        });
        return;
      }
      _lastTokenError = { kind: kind, status: status, message: msg };
      onError(msg);
    });
  }

  // ── 2) Низкоуровневый GraphQL-запрос с Bearer-токеном ───────────────────────
  function graphQL(token, query, onSuccess, onError) {
    fetch(CONFIG.GRAPHQL_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + token },
      body: JSON.stringify({ query: query })
    }).then(function (resp) {
      return resp.json().then(function (data) { onSuccess(data, resp); });
    }).catch(function (e) { onError("GraphQL: " + (e.message || e)); });
  }

  // ── Rich-text → плоский текст ───────────────────────────────────────────────
  // technicalDescription в инсталляции Halyk приходит НЕ строкой, а rich-text JSON
  // редактора (Slate-формат: [{type:"paragraph",children:[{text:"строка SQL"}]}, …]).
  // Вытаскиваем чистый текст (по абзацам), чтобы в промпт LLM ушёл нормальный SQL,
  // а не JSON. Если значение — обычная строка (другая инсталляция), вернём как есть.
  function _nodeText(node) {
    if (node == null) return "";
    if (typeof node === "string") return node;
    if (Array.isArray(node)) return node.map(_nodeText).join("");
    var t = (typeof node.text === "string") ? node.text : "";
    if (Array.isArray(node.children)) t += node.children.map(_nodeText).join("");
    return t;
  }
  function richTextToPlain(val) {
    if (val == null) return "";
    var parsed = val;
    if (typeof val === "string") {
      var s = val.trim();
      if (!s || (s.charAt(0) !== "[" && s.charAt(0) !== "{")) return val; // обычный текст
      try { parsed = JSON.parse(s); } catch (e) { return val; }            // не JSON — как есть
    }
    var blocks = Array.isArray(parsed) ? parsed : [parsed];                 // абзацы → строки
    var text = blocks.map(_nodeText).join("\n").replace(/\n{3,}/g, "\n\n").trim();
    return text || (typeof val === "string" ? val : "");
  }

  // ── Маппинг edges → [{gid, name, description, technical}] ────────────────────
  // description — ПРИОРИТЕТНО человеческий «Business definition» (dv.businessDefinition),
  // затем стандартное dv.description, в крайнем случае technicalDescription. technical —
  // отдельно SQL. Всё чистим из rich-text в плоский текст. Имя: name → _displayName, .trim().
  function mapTermEdges(data) {
    var edges = (((data.data || {}).terms || {}).edges) || [];
    var fields = (_descFields && _descFields.length) ? _descFields : ["description"];
    return edges.map(function (e) {
      var n = e.node || {};
      var dv = n.draftVersion || n.publishedVersion || {};
      var human = "", sqlish = "";
      for (var i = 0; i < fields.length; i++) {
        var v = richTextToPlain(dv[fields[i]] || "");
        if (!v || !v.trim()) continue;
        if (_looksLikeSql(v)) { if (!sqlish) sqlish = v; }   // это SQL — НЕ человеческое описание
        else { human = v; break; }                            // первое НЕ-SQL значение = человеческое описание
      }
      var tech = richTextToPlain(dv.technicalDescription || "") || sqlish;
      return {
        gid: n.gid,
        name: (dv.name || dv._displayName || "").trim(),
        description: human,   // ТОЛЬКО человеческое описание (SQL сюда не попадает); пусто → «отсутствует»
        technical: tech       // технический фильтр / SQL (про запас, в промпт не идёт)
      };
    }).filter(function (t) { return t.name; });
  }

  // Интроспекция схемы: находим тип версии термина (есть name + technicalDescription) и его
  // СКАЛЯРНЫЕ поля; кандидаты на человеческое описание — поля вида business/definition/описание
  // + стандартное description. Так не нужно угадывать точное имя поля Halyk («Business definition»).
  function discoverDescFields(token, cb) {
    var q = "query SolaiIntrospect { __schema { types { name fields { name type { kind name ofType { kind name } } } } } }";
    graphQL(token, q, function (data) {
      try {
        var types = (((data || {}).data || {}).__schema || {}).types || [];
        var tv = null;
        types.forEach(function (ty) {
          var fs = (ty.fields || []).map(function (f) { return f.name; });
          if (fs.indexOf("technicalDescription") !== -1 && fs.indexOf("name") !== -1) tv = ty;
        });
        if (!tv) { cb(null); return; }
        var scalars = (tv.fields || []).filter(function (f) {
          var t = f.type || {}, of = t.ofType || {};
          return t.kind === "SCALAR" || (t.kind === "NON_NULL" && of.kind === "SCALAR");
        }).map(function (f) { return f.name; });
        var excl = { gid:1, id:1, name:1, _displayName:1, technicalDescription:1, type:1, abbreviation:1 };
        var prefer = scalars.filter(function (n) { return !excl[n] && /business|definition|бизнес|опредл|описан|determ/i.test(n); });
        if (scalars.indexOf("description") !== -1 && prefer.indexOf("description") === -1) prefer.push("description");
        console.log("[SOLAI Ataccama] скалярные поля версии термина:", scalars.join(", "), "| кандидаты описания:", prefer.join(", ") || "(нет)");
        cb(prefer.length ? prefer : (scalars.indexOf("description") !== -1 ? ["description"] : null));
      } catch (e) { cb(null); }
    }, function () { cb(null); }); // интроспекция недоступна → null (откат на description)
  }

  // ── 3) Список терминов глоссария: интроспекция полей описания + кэш + откат ──
  function fetchGlossary(onSuccess, onError) {
    var now = Date.now();
    if (_glossary && (now - _glossary.fetchedAt) < CONFIG.GLOSSARY_TTL) {
      onSuccess(_glossary.terms); return;
    }
    getToken(function (token) {
      var proceed = function (fields) {
        _descFields = fields || [];
        var sel = _descFields.length ? _descFields.join(" ") : "description";
        var q = "query SolaiGloss { terms(versionSelector:{draftVersion:true}) { edges { node { gid draftVersion { name " + sel + " technicalDescription } } } } }";
        graphQL(token, q, function (data) {
          if (data.errors && data.errors.length) {
            console.warn("[SOLAI Ataccama] errors с полями [" + sel + "], откат на technicalDescription:", JSON.stringify(data.errors).slice(0, 200));
            graphQL(token, GQL_TERMS_NAMES, function (d2) {
              if (d2.errors && d2.errors.length) { onError("GraphQL: " + JSON.stringify(d2.errors)); return; }
              _descFields = [];
              var t2 = mapTermEdges(d2); _glossary = { terms: t2, fetchedAt: Date.now() };
              console.log("[SOLAI Ataccama] загружено (fallback, technicalDescription):", t2.length);
              onSuccess(t2);
            }, onError);
            return;
          }
          var terms = mapTermEdges(data);
          _glossary = { terms: terms, fetchedAt: Date.now() };
          console.log("[SOLAI Ataccama] загружено терминов:", terms.length, "| поля описания:", _descFields.join(",") || "description");
          onSuccess(terms);
        }, onError);
      };
      if (_descFields === null) discoverDescFields(token, proceed);
      else proceed(_descFields);
    }, onError);
  }

  // ── Поиск термина из глоссария в тексте вопроса (самое длинное совпадение) ───
  function findTermInText(terms, text) {
    var norm = " " + normalizeQuestion(text) + " ";
    var best = null, bestLen = 0;
    (terms || []).forEach(function (t) {
      var tn = normalizeQuestion(t.name);
      // Совпадение ПО ГРАНИЦАМ СЛОВ (а не подстрокой): чтобы «кредит» не цеплялся
      // внутри «кредитам», и короткий общий термин не перебивал конкретный.
      if (tn && tn.length >= 3 && norm.indexOf(" " + tn + " ") !== -1 && tn.length > bestLen) {
        best = t; bestLen = tn.length;
      }
    });
    return best;
  }

  // ── Нечёткий поиск КАНДИДАТОВ (длинные названия трудно набрать целиком) ──────
  // Ранжируем термины по совпадению слов с запросом; возвращаем top-N для выбора кнопками.
  function findTermCandidates(terms, text, limit) {
    var norm = normalizeQuestion(text);
    if (!norm) return [];
    var qTokens = norm.split(" ").filter(function (w) { return w.length >= 3; });
    var scored = (terms || []).map(function (t) {
      var tn = normalizeQuestion(t.name);
      if (!tn) return null;
      var score = 0;
      if (tn.indexOf(norm) !== -1 || norm.indexOf(tn) !== -1) score += 10;     // вхождение целиком
      qTokens.forEach(function (w) { if (tn.indexOf(w) !== -1) score += 2; });  // покрытие слов запроса
      tn.split(" ").forEach(function (w) { if (w.length >= 3 && norm.indexOf(w) !== -1) score += 1; });
      return score > 0 ? { term: t, score: score } : null;
    }).filter(Boolean);
    scored.sort(function (a, b) { return b.score - a.score; });
    return scored.slice(0, limit || 8).map(function (x) { return x.term; });
  }

  // ── Категории терминов по ключевым словам в названии (для навигации) ────────
  // (Под родные Ataccama `type` подстроимся, когда увидим их значения.)
  var CATEGORY_RULES = [
    { key: "Кредиты",            re: /кредит|ссуд|заёмщик|заемщик|заём|заем/i },
    { key: "Депозиты/Вклады",    re: /депозит|вклад/i },
    { key: "Остатки/Сальдо",     re: /остат|сальдо|saldo|баланс/i },
    { key: "Долг/Задолженность", re: /задолженн|долг(?!осроч)/i },
    { key: "Просрочка/NPL",      re: /просроч|\bnpl\b|overdue|овердью/i },
    { key: "Обязательства",      re: /обязательств|пассив/i },
    { key: "Доходы/Прибыль",     re: /доход|прибыл|выруч|маржа/i },
    { key: "Клиенты",            re: /клиент|субъект|физ.?лиц|\bфл\b|\bюл\b/i },
    { key: "Счета/Операции",     re: /счёт|счет|транзакц|оборот|платеж|перевод|операц/i }
  ];
  function categorize(terms) {
    var cats = {};
    (terms || []).forEach(function (t) {
      var matched = [];
      CATEGORY_RULES.forEach(function (r) { if (r.re.test(t.name || "")) matched.push(r.key); });
      if (!matched.length) matched = ["Прочее"];
      matched.forEach(function (k) { (cats[k] = cats[k] || []).push(t); });
    });
    return cats;
  }

  // ── Диагностика: токен + список терминов (+ поиск конкретного термина) ───────
  function test(termName) {
    console.log("[SOLAI Ataccama TEST] token:", CONFIG.TOKEN_URL, "| graphql:", CONFIG.GRAPHQL_URL, "| client:", CONFIG.CLIENT_ID);
    if (!CONFIG.ENABLED) { console.warn("[SOLAI Ataccama TEST] ENABLED=false — интеграция выключена в конфиге."); return; }
    getToken(function (tok) {
      console.log("[SOLAI Ataccama TEST] OK токен, длина:", (tok || "").length);
      fetchGlossary(function (terms) {
        console.log("[SOLAI Ataccama TEST] терминов:", terms.length, "| первые 20:", terms.slice(0, 20));
        if (termName) {
          var t = findTermInText(terms, termName) ||
            terms.filter(function (x) { return normalizeQuestion(x.name) === normalizeQuestion(termName); })[0];
          console.log("[SOLAI Ataccama TEST] найден термин:", t || "(не найден)");
        }
        console.log("[SOLAI Ataccama TEST] ✅ ПОДКЛЮЧЕНИЕ К ATACCAMA РАБОТАЕТ.");
      }, function (e) {
        console.error("[SOLAI Ataccama TEST] glossary error:", e);
        var h = errorHint(e); if (h) console.error("  " + h);
      });
    }, function (e) {
      console.error("[SOLAI Ataccama TEST] token error:", e);
      var h = errorHint(e); if (h) console.error("  " + h);
    });
  }

  // Обратная совместимость: window.solaiTestAtaccama(...) как раньше.
  try { if (typeof window !== "undefined") window.solaiTestAtaccama = test; } catch (e) {}

  // ── Публичный интерфейс модуля (его вызывает SOLAI.js) ──────────────────────
  return {
    config:         CONFIG,
    shouldUse:      shouldUse,       // (text) → bool — нужен ли справочник
    isDiagCommand:  isDiagCommand,   // (text) → bool — это команда диагностики
    errorHint:      errorHint,       // (errMsg) → подсказка для админа
    getToken:       getToken,        // (onSuccess(token,method), onError(msg))
    graphQL:        graphQL,         // (token, query, onSuccess(data,resp), onError(msg))
    fetchGlossary:  fetchGlossary,   // (onSuccess(terms[]), onError(msg))
    findTermInText: findTermInText,  // (terms[], text) → term | null (точное вхождение)
    findTermCandidates: findTermCandidates, // (terms[], text, limit) → term[] (нечёткие кандидаты)
    categorize:     categorize,      // (terms[]) → { категория: term[] }
    authMethodUsed: function () { return _authMethodUsed; }, // "basic"|"body"|null — чем получен токен
    lastError:      function () { return _lastTokenError; }, // {kind,status,message}|null — последняя ошибка токена
    test:           test             // (termName?) — диагностика в консоль
  };
}));
